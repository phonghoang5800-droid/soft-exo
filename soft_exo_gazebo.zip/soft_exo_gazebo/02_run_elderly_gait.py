#!/usr/bin/env python3
"""
02_run_elderly_gait.py
Gazebo Soft-Exo lower-body demo:
- short steps
- slow cadence
- low foot clearance
- mild knee flexion
- small ankle motion
- slight vertical pelvis bob

No ROS is required. The script sends ONE gz.msgs.JointTrajectory
to Gazebo Transport, so it is much lighter than spawning a command
for every joint on every frame.
"""

import math
import subprocess
import sys

TOPIC = "/soft_exo/joint_trajectory"

# ---- ELDERLY GAIT DEMO PARAMETERS ----
STEP_TIME = 1.20       # seconds per step ~= 50 steps/min
STEP_LENGTH = 0.22     # metres, deliberately short
NUM_STEPS = 10
DT = 0.15              # trajectory point spacing
START_DELAY = 0.50

# Joint order MUST match the SDF trajectory controller order.
JOINT_NAMES = [
    "pelvis_x_joint",
    "pelvis_z_joint",
    "left_hip_joint",
    "left_knee_joint",
    "left_ankle_joint",
    "right_hip_joint",
    "right_knee_joint",
    "right_ankle_joint",
]

def clamp(x, lo, hi):
    return max(lo, min(hi, x))

def gait_at(t):
    """
    Conceptual elderly gait, not a clinical biomechanics model.
    Positive X is forward.
    Knee flexion uses negative angle for this model.
    """

    # Walking starts after a short settling pause.
    wt = max(0.0, t - START_DELAY)

    # Continuous forward motion of the support carriage.
    speed = STEP_LENGTH / STEP_TIME
    pelvis_x = min(NUM_STEPS * STEP_LENGTH, speed * wt)

    # Small vertical motion, deliberately reduced for an older-adult gait.
    pelvis_z = 0.010 * math.sin(2.0 * math.pi * wt / STEP_TIME)

    # One full left-right gait cycle = 2 steps.
    cycle = 2.0 * STEP_TIME
    phase = (wt % cycle) / cycle * 2.0 * math.pi

    # Hip motion: short stride, low amplitude.
    hip_amp = 0.19
    left_hip = hip_amp * math.sin(phase)
    right_hip = hip_amp * math.sin(phase + math.pi)

    # Swing indicators. Positive half-wave means that leg is in swing.
    left_swing = max(0.0, math.sin(phase))
    right_swing = max(0.0, math.sin(phase + math.pi))

    # Mild flexion in stance + more flexion in swing.
    # Less extreme than a healthy exaggerated animation.
    left_knee = -0.10 - 0.44 * (left_swing ** 1.35)
    right_knee = -0.10 - 0.44 * (right_swing ** 1.35)

    # Small ankle motion. Older-adult demo intentionally uses
    # reduced push-off / toe clearance.
    left_ankle = 0.05 * math.sin(phase - 0.55) - 0.055 * left_swing
    right_ankle = 0.05 * math.sin(phase + math.pi - 0.55) - 0.055 * right_swing

    return [
        pelvis_x,
        pelvis_z,
        clamp(left_hip, -0.30, 0.30),
        clamp(left_knee, -0.65, 0.05),
        clamp(left_ankle, -0.18, 0.18),
        clamp(right_hip, -0.30, 0.30),
        clamp(right_knee, -0.65, 0.05),
        clamp(right_ankle, -0.18, 0.18),
    ]

def sec_nsec(t):
    sec = int(t)
    nsec = int(round((t - sec) * 1_000_000_000))
    if nsec >= 1_000_000_000:
        sec += 1
        nsec -= 1_000_000_000
    return sec, nsec

def build_message():
    lines = []

    for name in JOINT_NAMES:
        lines.append(f'joint_names: "{name}"')

    # Initial settling point.
    total_time = START_DELAY + NUM_STEPS * STEP_TIME
    count = int(math.ceil(total_time / DT))

    for i in range(count + 1):
        t = min(total_time, i * DT)
        q = gait_at(t)
        sec, nsec = sec_nsec(max(0.05, t + 0.05))

        lines.append("points {")
        for value in q:
            lines.append(f"  positions: {value:.6f}")
        lines.append("  time_from_start {")
        lines.append(f"    sec: {sec}")
        lines.append(f"    nsec: {nsec}")
        lines.append("  }")
        lines.append("}")

    return "\n".join(lines)

def main():
    msg = build_message()

    cmd = [
        "gz", "topic",
        "-t", TOPIC,
        "-m", "gz.msgs.JointTrajectory",
        "-p", msg,
    ]

    print("SOFT-EXO ELDERLY GAIT")
    print("----------------------")
    print(f"Steps       : {NUM_STEPS}")
    print(f"Step length : {STEP_LENGTH:.2f} m")
    print(f"Step time   : {STEP_TIME:.2f} s")
    print(f"Cadence     : {60.0 / STEP_TIME:.1f} steps/min")
    print(f"Distance    : {NUM_STEPS * STEP_LENGTH:.2f} m")
    print("")
    print("Sending JointTrajectory to Gazebo...")

    try:
        result = subprocess.run(cmd, check=False)
    except FileNotFoundError:
        print("ERROR: Không tìm thấy lệnh 'gz'.")
        print("Hãy kiểm tra Gazebo đã được cài và Terminal nhận lệnh gz.")
        sys.exit(1)

    if result.returncode != 0:
        print("")
        print("Gazebo không nhận trajectory.")
        print("Kiểm tra Terminal 1 đang chạy:")
        print("  gz sim -r 02_soft_exo_elderly_gait.sdf")
        sys.exit(result.returncode)

    print("Trajectory sent.")
    print("Quan sát Gazebo: hai chân sẽ đi chậm về phía +X.")

if __name__ == "__main__":
    main()
