#!/bin/bash
set -e
cd "$(dirname "$0")"
echo "======================================================"
echo " SOFT-EXO Family Care • FINAL FULL"
echo " Web :3012 • Sensor UDP :5005 • OTP • 3D • SOS"
echo "======================================================"
if ! command -v npm >/dev/null 2>&1; then
  echo "[LỖI] Chưa có Node.js/npm. Cài Node.js rồi chạy lại."
  read -r -p "Nhấn Enter để đóng..."
  exit 1
fi
if [ ! -d node_modules ]; then
  echo "Lần chạy đầu: đang cài thư viện npm..."
  npm install
fi
( sleep 2; open "http://localhost:3012" >/dev/null 2>&1 || true ) &
npm run dev
