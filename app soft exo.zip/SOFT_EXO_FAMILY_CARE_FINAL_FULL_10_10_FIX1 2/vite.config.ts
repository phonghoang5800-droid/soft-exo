import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig, loadEnv } from 'vite';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const publicHost = (env.SOFT_EXO_PUBLIC_HOST || '').trim();

  const allowedHosts = [
    'localhost',
    '127.0.0.1',
    // Quick Tunnel hostnames. Development/demo only.
    '.trycloudflare.com',
    // Planned stable production hostname.
    'app.softexo.vn',
    ...(publicHost ? [publicHost] : []),
  ];

  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(process.cwd(), '.'),
      },
    },
    server: {
      host: '0.0.0.0',
      port: 3012,
      allowedHosts,
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
