# Cập nhật Intro SOFT-EXO

Luồng mở ứng dụng mới:

1. Mở website trên Mac hoặc điện thoại.
2. Hiện màn chào SOFT-EXO Family Care với animation nhẹ.
3. Sau khoảng 2,5 giây, nút **Trang chủ** xuất hiện ở phía dưới.
4. Người dùng bấm **Trang chủ** để đi tiếp tới màn hình Đăng nhập / Đăng ký.

Màn intro chỉ sử dụng nội dung thương hiệu dễ hiểu, không hiển thị các thuật ngữ ESP32, IMU, Digital Twin hay tần số cảm biến.

Các chức năng còn lại của ứng dụng được giữ nguyên.
