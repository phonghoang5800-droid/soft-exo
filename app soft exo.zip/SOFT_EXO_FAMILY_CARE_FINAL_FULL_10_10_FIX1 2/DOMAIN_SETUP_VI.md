# SOFT-EXO: Tên miền cố định qua Cloudflare Named Tunnel

Bản này đã sửa Vite để cho phép:
- localhost / 127.0.0.1
- các Quick Tunnel `*.trycloudflare.com` dùng lúc test
- `app.softexo.vn`
- hostname đặt trong biến `SOFT_EXO_PUBLIC_HOST`

## Mục tiêu
Người dùng truy cập bằng địa chỉ ổn định như:

`https://app.softexo.vn`

thay vì hostname ngẫu nhiên của Quick Tunnel.

## Điều kiện bắt buộc
Bạn phải sở hữu một tên miền và tên miền đó phải được thêm vào Cloudflare DNS.

## Cấu hình Cloudflare Dashboard
1. Cloudflare Dashboard → Networking → Tunnels → Create Tunnel.
2. Đặt tên tunnel: `soft-exo-family-care`.
3. Chọn macOS và chạy lệnh Cloudflare cung cấp để kết nối Mac với tunnel.
4. Trong tunnel → Routes → Add route → Published application.
5. Hostname: `app` + domain của bạn, ví dụ `app.softexo.vn`.
6. Service URL: `http://localhost:3012`.
7. Lưu route.

Sau đó giữ app chạy bằng:

```bash
npm run dev
```

Named Tunnel có hostname cố định nên không cần tạo QR mới mỗi lần khởi động lại.

## Nếu domain không phải softexo.vn
Tạo file `.env` trong thư mục project:

```bash
SOFT_EXO_PUBLIC_HOST=app.tenmiencuaban.vn
```

sau đó khởi động lại `npm run dev`.
