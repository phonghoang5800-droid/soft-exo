# FINAL FULL — Những thay đổi chính

1. Barcode scanner thật: Camera API + BarcodeDetector + ZXing fallback, không còn nút “nhận diện giả”.
2. Mô hình khớp gối Three.js tương tác, xoay/zoom/pan và gập theo `kneeAngle` thật.
3. UDP receiver `:5005` nhận dữ liệu ESP32-S3/MPU6050 rồi phát SSE cho mọi trình duyệt đang kết nối.
4. Tách “đã liên kết sản phẩm” khỏi “đang nhận dữ liệu phần cứng thật”.
5. Xóa raw data terminal/Packet JSON-HEX/Blender khỏi UI người bệnh.
6. SOS realtime: phát hiện va đập/chuyển động không an toàn, SSE, âm thanh/rung, cảnh báo caregiver, ACK “Tôi ổn”.
7. Web Push nền cho caregiver/doctor/admin đã đăng ký nhận cảnh báo; thêm manifest + service worker.
8. Firmware có lệnh `ALARM,ON/OFF` và fail-safe tại chỗ nếu có buzzer được đấu.
9. Giao diện sáng, tương phản cao hơn, animation/hover/focus/press rõ ràng, từ ngữ kỹ thuật được giảm ở màn người dùng.
10. Session Admin ký HMAC, không còn phụ thuộc session Map chỉ sống tới lần restart server.

- Liên kết mã sản phẩm được lưu backend theo tài khoản, không còn chỉ là trạng thái UI tạm thời.
- Mã link dạng URL bị từ chối để tránh nhầm QR mở web với mã sản phẩm.
- Thêm firmware 2 MPU6050 khuyến nghị để tính góc gối tương đối giữa đùi và cẳng chân.
- SOS gắn mã thiết bị/người bệnh khi có liên kết sản phẩm và gửi thông tin đó tới cảnh báo người thân.
- Đã khóa thêm API SOS/Gemini/chat/location bằng session phù hợp.
