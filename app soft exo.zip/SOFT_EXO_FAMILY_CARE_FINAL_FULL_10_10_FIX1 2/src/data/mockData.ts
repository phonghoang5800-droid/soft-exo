import { 
  UserRole, 
  UserProfile, 
  AffectedLeg, 
  CaregiverAlert, 
  AlertType, 
  AlertSeverity, 
  ClinicalCondition, 
  ChatMessage, 
  ChatChannel, 
  PatientConversation, 
  DoctorPatientRecord, 
  RehabExercise, 
  DailyProgress, 
  AppFeature, 
  FeatureCategory, 
  RegisteredUserRecord,
  ConnectedDevice,
  DeviceStatus
} from '../types';

export const ALL_APP_FEATURES: AppFeature[] = [
  {
    id: 'feat_3d_twin',
    name: 'Theo dõi chuyển động khớp gối',
    category: FeatureCategory.CORE_SENSORS,
    description: 'Hiển thị tình trạng gập duỗi của khớp gối theo thời gian thực để người dùng dễ theo dõi.',
    isCore: true,
    iconName: 'Box',
  },
  {
    id: 'feat_imu_sensor',
    name: 'Đo góc gập duỗi tự động',
    category: FeatureCategory.CORE_SENSORS,
    description: 'Ghi nhận góc gối trong lúc tập để biết tiến độ phục hồi mỗi ngày.',
    isCore: true,
    iconName: 'Activity',
  },
  {
    id: 'feat_ai_coach',
    name: 'Hướng dẫn tập luyện thông minh',
    category: FeatureCategory.AI_COACH,
    description: 'Đếm số lần tập tự động, chấm điểm góc gập chuẩn và nhắc nhở tư thế.',
    isCore: true,
    iconName: 'Sparkles',
  },
  {
    id: 'feat_fall_detection',
    name: 'Cảnh báo té ngã khẩn cấp',
    category: FeatureCategory.SAFETY_ALERT,
    description: 'Tự động cảnh báo cho người thân khi phát hiện va chạm mạnh hoặc té ngã bất thường.',
    isCore: false,
    iconName: 'AlertTriangle',
  },
  {
    id: 'feat_doctor_telehealth',
    name: 'Kết nối tư vấn với bác sĩ',
    category: FeatureCategory.TELE_HEALTH,
    description: 'Bác sĩ có thể theo dõi kết quả luyện tập và hướng dẫn điều chỉnh phù hợp.',
    isCore: false,
    iconName: 'Stethoscope',
  },
  {
    id: 'feat_caregiver_portal',
    name: 'Theo dõi người thân từ xa',
    category: FeatureCategory.TELE_HEALTH,
    description: 'Gia đình dễ dàng xem tình hình tập luyện và nhận thông báo khi cần hỗ trợ.',
    isCore: false,
    iconName: 'HeartHandshake',
  },
  {
    id: 'feat_rom_analytics',
    name: 'Báo cáo tiến độ phục hồi',
    category: FeatureCategory.ANALYTICS,
    description: 'Tổng hợp tiến độ theo tuần hoặc tháng để người dùng và bác sĩ dễ đánh giá.',
    isCore: false,
    iconName: 'BarChart3',
  },
];

export const INITIAL_USER_PROFILE: UserProfile = {
  id: 'user_01',
  fullName: 'Người dùng',
  phone: '',
  email: '',
  role: UserRole.PATIENT,
  age: 0,
  condition: 'Chưa cập nhật',
  surgeryDate: '',
  affectedLeg: AffectedLeg.RIGHT,
  targetRomAngle: 0,
  currentMaxAngle: 0,
  recoveryDays: 0,
  isDoctorAssigned: false,
  doctorName: 'Chưa được phân công',
  doctorHospital: '',
  caregiverName: 'Chưa liên kết',
  caregiverPhone: '',
};

export const INITIAL_CONNECTED_DEVICE: ConnectedDevice = {
  id: 'EXO2026-0415-0012',
  name: 'Thiết bị hỗ trợ SOFT-EXO',
  macAddress: '24:6F:28:AE:10:9B',
  status: DeviceStatus.DISCONNECTED,
  batteryPercent: 0,
  firmwareVersion: 'v2.1.0-IMU',
  sensorType: 'ESP32-S3 + MPU6050',
  serialNumber: 'KT-8821-VN',
  qrCodePayload: 'KNEE-ESP32-PRO-8821',
};

export const SAMPLE_REHAB_EXERCISES: RehabExercise[] = [
  {
    id: 'ex_01',
    title: 'Trượt Gót Chân Nằm (Heel Slide)',
    subtitle: 'Tăng góc gập chủ động',
    description: 'Nằm ngửa trên thảm, từ từ co đầu gối và trượt gót chân về phía hông đến khi đạt góc tối đa, giữ trong 5 giây rồi duỗi thẳng lại.',
    targetAngle: 90,
    holdTimeSeconds: 5,
    totalReps: 10,
    category: 'Giai đoạn 1 (Tuần 1-2)',
    benefits: 'Phục hồi góc gập khớp gối, kích hoạt cơ hamstring và ngăn dính khớp.',
    precautions: 'Không dùng lực giật mạnh, dừng lại ngay nếu đau quá ngưỡng 5/10.',
    difficulty: 'Dễ',
    iconName: 'Activity',
    isCompletedToday: false,
  },
  {
    id: 'ex_02',
    title: 'Gồng Cơ Tứ Đầu Đùi (Quad Sets)',
    subtitle: 'Khôi phục kiểm soát duỗi gối',
    description: 'Nằm hoặc ngồi thẳng chân, gồng chặt cơ mặt trước đùi ép khoeo chân sát xuống mặt phẳng, giữ 5 giây rồi thả lỏng.',
    targetAngle: 0,
    holdTimeSeconds: 5,
    totalReps: 15,
    category: 'Giai đoạn 1 (Tuần 1-2)',
    benefits: 'Chống teo cơ đùi trước, phục hồi chức năng duỗi thẳng 0° hoàn toàn.',
    precautions: 'Không nín thở khi gồng cơ, tập đều đặn 3 cữ mỗi ngày.',
    difficulty: 'Dễ',
    iconName: 'Flame',
    isCompletedToday: false,
  },
  {
    id: 'ex_03',
    title: 'Nâng Chân Thẳng (Straight Leg Raise)',
    subtitle: 'Tăng sức mạnh cơ đùi & hông',
    description: 'Gồng chặt đầu gối duỗi thẳng, nâng toàn bộ chân lên cao khoảng 30cm so với mặt giường, giữ 3 giây rồi hạ từ từ.',
    targetAngle: 45,
    holdTimeSeconds: 3,
    totalReps: 10,
    category: 'Giai đoạn 2 (Tuần 3-4)',
    benefits: 'Tăng cường sức mạnh cơ tứ đầu và cơ gấp hông mà không gây áp lực lên ổ khớp gối.',
    precautions: 'Đảm bảo gối luôn khóa thẳng trong suốt quá trình nâng.',
    difficulty: 'Trung bình',
    iconName: 'TrendingUp',
    isCompletedToday: false,
  },
  {
    id: 'ex_04',
    title: 'Gập Gối Ngồi Ghế Có Kháng Lực',
    subtitle: 'Mở rộng biên độ ROM sâu',
    description: 'Ngồi thẳng trên ghế cao, từ từ co chân gập sâu ra phía sau mép ghế đến góc chỉ định, giữ 5 giây.',
    targetAngle: 110,
    holdTimeSeconds: 5,
    totalReps: 12,
    category: 'Giai đoạn 3 (Tuần 5-8)',
    benefits: 'Đạt biên độ góc gập sinh hoạt bình thường (>110° để ngồi xổm hoặc leo cầu thang).',
    precautions: 'Chỉ tập khi có sự đồng ý của bác sĩ điều trị.',
    difficulty: 'Nâng cao',
    iconName: 'Zap',
    isCompletedToday: false,
  },
];

export const SAMPLE_CAREGIVER_ALERTS: CaregiverAlert[] = [];

export const SAMPLE_DAILY_PROGRESS: DailyProgress[] = [
  { dayOfWeek: 'T2', maxAngle: 0, completedReps: 0, painLevel: 0 },
  { dayOfWeek: 'T3', maxAngle: 0, completedReps: 0, painLevel: 0 },
  { dayOfWeek: 'T4', maxAngle: 0, completedReps: 0, painLevel: 0 },
  { dayOfWeek: 'T5', maxAngle: 0, completedReps: 0, painLevel: 0 },
  { dayOfWeek: 'T6', maxAngle: 0, completedReps: 0, painLevel: 0 },
  { dayOfWeek: 'T7', maxAngle: 0, completedReps: 0, painLevel: 0 },
  { dayOfWeek: 'CN', maxAngle: 0, completedReps: 0, painLevel: 0 },
];

export const SAMPLE_DOCTOR_PATIENTS: DoctorPatientRecord[] = [];

export const SAMPLE_PATIENT_CONVERSATIONS: PatientConversation[] = [];

export const INITIAL_AI_CHAT_MESSAGES: ChatMessage[] = [
  {
    id: 'ai_msg_01',
    senderName: 'Trợ lý AI SOFT-EXO',
    senderRole: UserRole.DOCTOR,
    content: 'Xin chào! Tôi là Trợ lý AI Y Tế chuyên khoa Phục hồi Khớp gối. Tôi có thể giúp bạn giải đáp bài tập, tư thế đúng, hoặc phân tích góc gối từ đai cảm biến IMU.',
    timestamp: '08:00',
    isFromUser: false,
    targetChannel: ChatChannel.AI_ASSISTANT,
  },
];

export const SAMPLE_MASTER_REGISTERED_USERS: RegisteredUserRecord[] = [];
