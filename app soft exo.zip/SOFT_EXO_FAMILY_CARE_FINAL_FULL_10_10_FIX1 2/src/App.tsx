import React, { useRef, useState } from 'react';
import { 
  Layers, 
  Home, 
  Activity, 
  Users, 
  Stethoscope, 
  HeartHandshake, 
  MessageSquare, 
  Cpu, 
  User, 
  ScanLine,
  LogOut,
  Sparkles,
  ShieldAlert,
  ChevronDown,
  Menu,
  X,
  Compass,
  Radio,
  ListOrdered,
  Flame,
  Zap,
  RotateCw,
  FileSpreadsheet,
  MapPin,
  Navigation,
  Hospital
} from 'lucide-react';

import { 
  UserRole, 
  UserProfile, 
  RegisteredUserRecord, 
  ChatMessage, 
  ChatChannel, 
  RehabExercise, 
  CaregiverAlert, 
  AlertType, 
  AlertSeverity,
  DeviceStatus,
  USER_ROLE_INFO
} from './types';
import { useAppStore } from './store';
import { useGeolocation } from './hooks/useGeolocation';
import { db, doc, setDoc } from './firebase';

import { KneeTwinLogo } from './components/KneeTwinLogo';
import { LocationPromptModal } from './components/LocationPromptModal';
import { GPSDetailsModal } from './components/GPSDetailsModal';
import { StandaloneSheetScreen } from './screens/StandaloneSheetScreen';
import { HomeScreen } from './screens/HomeScreen';
import { DigitalTwinScreen } from './screens/DigitalTwinScreen';
import { ExerciseListScreen } from './screens/ExerciseListScreen';
import { ExerciseTrainingScreen } from './screens/ExerciseTrainingScreen';
import { DoctorScreen } from './screens/DoctorScreen';
import { CaregiverScreen } from './screens/CaregiverScreen';
import { ChatScreen } from './screens/ChatScreen';
import { DeviceConnectScreen } from './screens/DeviceConnectScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { AuthScreen } from './screens/AuthScreen';
import { AdminPortalScreen } from './screens/AdminPortalScreen';
import { RecoveryPassportScreen } from './screens/RecoveryPassportScreen';

type AppTab = 
  | 'admin'
  | 'home'
  | 'exercises'
  | 'training'
  | 'twin3d'
  | 'doctor'
  | 'caregiver'
  | 'chat'
  | 'device'
  | 'profile'
  | 'passport';

export default function App() {
  const store = useAppStore();
  const geo = useGeolocation();
  const [showIntro, setShowIntro] = useState(true);
  const [introReady, setIntroReady] = useState(false);

  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    try {
      const activeUser = localStorage.getItem('kneetwin_active_session');
      const token = localStorage.getItem('soft_exo_session_token');
      return !!activeUser && !!token;
    } catch {
      return false;
    }
  });
  const [activeTab, setActiveTab] = useState<AppTab>('home');
  const [selectedExercise, setSelectedExercise] = useState<RehabExercise>(store.exercises[0]);
  const [showGpsModal, setShowGpsModal] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeChatPatientId, setActiveChatPatientId] = useState<string>('pat_01');
  const [activePassportPatientId, setActivePassportPatientId] = useState<string>('');
  const [latestSosAlert, setLatestSosAlert] = useState<any | null>(null);
  const alarmAudioRef = useRef<{ ctx: AudioContext; timer: number } | null>(null);

  React.useEffect(() => {
    const timer = window.setTimeout(() => setIntroReady(true), 2500);
    return () => window.clearTimeout(timer);
  }, []);



  // Live hardware bridge. Every telemetry packet from ESP32/MPU6050 reaches
  // the browser through SSE, so the 3D knee follows the real sensor angle.
  React.useEffect(() => {
    if (!isLoggedIn) return;
    const token = localStorage.getItem('soft_exo_session_token') || '';
    if (!token) return;
    const source = new EventSource(`/api/realtime/telemetry?token=${encodeURIComponent(token)}`);
    const onTelemetry = (event: MessageEvent) => {
      try {
        const incoming = JSON.parse(event.data);
        store.setTelemetry(prev => ({ ...prev, ...incoming }));
      } catch (err) {
        console.warn('Telemetry SSE parse notice:', err);
      }
    };
    source.addEventListener('telemetry', onTelemetry as EventListener);
    source.onerror = () => {
      // EventSource reconnects automatically. No noisy popup is needed.
    };
    return () => source.close();
  }, [isLoggedIn]);

  // Realtime SOS stream while the app is open. Background/closed-app delivery is
  // handled separately by standards-based Web Push when the device subscribed.
  React.useEffect(() => {
    if (!isLoggedIn) return;
    const token = localStorage.getItem('soft_exo_session_token') || '';
    if (!token) return;
    const source = new EventSource(`/api/realtime/alerts?token=${encodeURIComponent(token)}`);
    const onSos = (event: MessageEvent) => {
      try {
        const alert = JSON.parse(event.data);
        setLatestSosAlert(alert);
        if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
          try {
            new Notification(alert.title || 'SOFT-EXO • Cảnh báo an toàn', {
              body: alert.message || 'Phát hiện sự kiện cần kiểm tra ngay.',
              tag: alert.id || 'soft-exo-sos',
            });
          } catch {}
        }
        const caregiverAlert: CaregiverAlert = {
          id: alert.id,
          patientName: alert.patientName || 'Người bệnh SOFT-EXO',
          type: alert.type === 'FALL_DETECTED' ? AlertType.FALL_DETECTED : AlertType.OVER_ANGLE,
          title: alert.title,
          message: alert.message,
          timestamp: 'Vừa xong',
          severity: alert.severity === 'DANGER' ? AlertSeverity.DANGER : AlertSeverity.WARNING,
          isRead: false,
          location: alert.location || 'Đang cập nhật vị trí GPS',
        };
        store.setAlerts(prev => prev.some(a => a.id === caregiverAlert.id) ? prev : [caregiverAlert, ...prev]);
      } catch (err) {
        console.warn('SOS SSE parse notice:', err);
      }
    };
    const onCleared = () => setLatestSosAlert(null);
    source.addEventListener('sos', onSos as EventListener);
    source.addEventListener('sos-cleared', onCleared as EventListener);
    return () => source.close();
  }, [isLoggedIn]);

  // Audible + vibration warning on the patient and caregiver device. Browsers
  // may require one prior user interaction before allowing sound, but vibration
  // and the visual emergency banner still work where supported.
  React.useEffect(() => {
    if (!store.telemetry.isFallDetected) {
      if (alarmAudioRef.current) {
        window.clearInterval(alarmAudioRef.current.timer);
        alarmAudioRef.current.ctx.close().catch(() => {});
        alarmAudioRef.current = null;
      }
      if ('vibrate' in navigator) navigator.vibrate(0);
      return;
    }

    if ('vibrate' in navigator) navigator.vibrate([500, 200, 500, 200, 800]);
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx || alarmAudioRef.current) return;
      const ctx: AudioContext = new AudioCtx();
      const beep = () => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain); gain.connect(ctx.destination);
        osc.type = 'square';
        osc.frequency.setValueAtTime(920, ctx.currentTime);
        gain.gain.setValueAtTime(0.0001, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.18, ctx.currentTime + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.35);
        osc.start(); osc.stop(ctx.currentTime + 0.38);
      };
      beep();
      const timer = window.setInterval(beep, 1800);
      alarmAudioRef.current = { ctx, timer };
    } catch {}

    return () => {
      if (alarmAudioRef.current) {
        window.clearInterval(alarmAudioRef.current.timer);
        alarmAudioRef.current.ctx.close().catch(() => {});
        alarmAudioRef.current = null;
      }
    };
  }, [store.telemetry.isFallDetected]);

  // Load active session profile on initial mount
  React.useEffect(() => {
    try {
      const activeUserStr = localStorage.getItem('kneetwin_active_session');
      const token = localStorage.getItem('soft_exo_session_token');
      if (activeUserStr && token) {
        const savedProfile = JSON.parse(activeUserStr);
        store.setCurrentRole(savedProfile.role);
        store.setUserProfile(savedProfile);
        setIsLoggedIn(true);
        if (savedProfile.role === UserRole.ADMIN) {
          setActiveTab('admin');
        } else if (savedProfile.role === UserRole.DOCTOR) {
          setActiveTab('doctor');
        } else if (savedProfile.role === UserRole.CAREGIVER) {
          setActiveTab('caregiver');
        } else {
          setActiveTab('home');
        }
      }
    } catch (e) {
      console.error(e);
    }
  }, []);

  // Check if opening the standalone Sheet view via dedicated direct link (?view=sheet or /sheet)
  const isSheetView = typeof window !== 'undefined' && (
    window.location.search.includes('view=sheet') || 
    window.location.pathname === '/sheet'
  );

  if (isSheetView) {
    return <StandaloneSheetScreen users={store.masterRegisteredUsers} />;
  }

  if (showIntro) {
    return (
      <div className="soft-exo-intro">
        <div className="intro-grid" aria-hidden="true" />
        <div className="intro-orb intro-orb-one" aria-hidden="true" />
        <div className="intro-orb intro-orb-two" aria-hidden="true" />

        <main className="intro-content">
          <div className="intro-logo-stage">
            <div className="intro-ring intro-ring-one" aria-hidden="true" />
            <div className="intro-ring intro-ring-two" aria-hidden="true" />
            <div className="intro-logo-card">
              <KneeTwinLogo size="xl" />
            </div>
          </div>

          <div className="intro-copy">
            <div className="intro-eyebrow">SOFT-EXO FAMILY CARE</div>
            <h1>Đồng hành cùng từng bước phục hồi</h1>
            <p>Chăm sóc, luyện tập và kết nối với người thân trong một không gian đơn giản, an tâm và dễ sử dụng.</p>
          </div>

          <div className={`intro-home-wrap ${introReady ? 'is-ready' : ''}`}>
            <button
              type="button"
              className="intro-home-button"
              onClick={() => setShowIntro(false)}
              disabled={!introReady}
            >
              <Home className="w-5 h-5" />
              <span>Trang chủ</span>
              <span className="intro-arrow" aria-hidden="true">→</span>
            </button>
            <span className="intro-home-note">Bắt đầu sử dụng SOFT-EXO</span>
          </div>
        </main>
      </div>
    );
  }

  // Phone QR URL

  const handleLoginSuccess = (profile: UserProfile) => {
    try {
      localStorage.setItem('kneetwin_active_session', JSON.stringify(profile));
    } catch (e) {
      console.error(e);
    }
    store.setCurrentRole(profile.role);
    store.setUserProfile(profile);
    setIsLoggedIn(true);

    if (profile.role === UserRole.ADMIN) {
      setActiveTab('admin');
    } else if (profile.role === UserRole.DOCTOR) {
      setActiveTab('doctor');
    } else if (profile.role === UserRole.CAREGIVER) {
      setActiveTab('caregiver');
    } else {
      setActiveTab('home');
    }
  };

  const handleLogout = () => {
    try {
      localStorage.removeItem('kneetwin_active_session');
      localStorage.removeItem('soft_exo_session_token');
    } catch (e) {
      console.error(e);
    }
    setIsLoggedIn(false);
  };

  const handleSelectExercise = (exercise: RehabExercise) => {
    setSelectedExercise(exercise);
    setActiveTab('training');
  };

  const handleCompleteExercise = (exerciseId: string, reps: number, maxAngle: number) => {
    store.setExercises(prev =>
      prev.map(e => (e.id === exerciseId ? { ...e, isCompletedToday: true } : e))
    );
    if (maxAngle > store.userProfile.currentMaxAngle) {
      store.setUserProfile(prev => ({ ...prev, currentMaxAngle: maxAngle }));
    }
  };

  const handleSimulateAngle = (_angle: number) => {
    // Production mode: synthetic telemetry is disabled. The UI only changes
    // when real ESP32/MPU6050 data arrives through the backend.
  };

  const handleCalibrateZero = () => {
    store.setTelemetry(prev => ({
      ...prev,
      kneeAngle: 0,
      thighPitch: 0,
      shinPitch: 0,
      isCalibrated: true,
      rawPacket: `[CALIB_ZERO] Goc_Goi:0.0,Pitch:0.0,Roll:0.0,G:1.00G,Bat:${prev.batteryLevel}%`,
    }));
  };

  const handleTriggerFallTest = () => {
    store.setTelemetry(prev => ({
      ...prev,
      isFallDetected: true,
      gForceMagnitude: 2.85,
      fallImpactG: 2.85,
      activityState: '🚨 TÉ NGÃ VA ĐẬP MẠNH (2.85G)',
      rawPacket: `[ALERT_FALL] G:2.85G,Impact:HIGH,Goc_Goi:${prev.kneeAngle.toFixed(1)}`,
    }));

    const locationText = geo.location
      ? `${geo.location.formattedAddress} (Tọa độ: ${geo.location.latitude}° N, ${geo.location.longitude}° E • Độ sai số: ±${geo.location.accuracy}m)`
      : 'Vị trí: Chưa bật GPS (Khu vực nhà riêng)';

    const newAlert: CaregiverAlert = {
      id: `alert_fall_${Date.now()}`,
      patientName: store.userProfile.fullName,
      type: AlertType.FALL_DETECTED,
      title: '🚨 CẢNH BÁO TÉ NGÃ KHẨN CẤP (Gia tốc 2.85G)',
      message: `Thiết bị SOFT-EXO phát hiện va chạm mạnh. Hệ thống đã tạo cảnh báo an toàn và cập nhật vị trí cho người thân.`,
      timestamp: 'Vừa xong',
      severity: AlertSeverity.DANGER,
      isRead: false,
      location: locationText,
    };

    store.setAlerts(prev => [newAlert, ...prev]);

    // Sync SOS Alert to Firebase Firestore
    setDoc(doc(db, 'alerts', newAlert.id), {
      ...newAlert,
      userId: store.userProfile.id,
      createdAt: new Date().toISOString(),
    }).catch(err => console.warn('Firestore alert sync note:', err));
  };

  const handleSendMessage = (channel: ChatChannel, content: string) => {
    const newMsg: ChatMessage = {
      id: `msg_${Date.now()}`,
      senderName: store.userProfile.fullName,
      senderRole: store.currentRole,
      content,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isFromUser: true,
      targetChannel: channel,
    };

    if (channel === ChatChannel.DOCTOR_CONSULTATION) {
      store.setConversations(prev =>
        prev.map(c =>
          c.patientId === activeChatPatientId
            ? {
                ...c,
                lastMessage: content,
                lastTimestamp: newMsg.timestamp,
                messages: [...c.messages, newMsg],
              }
            : c
        )
      );

      // Không giả lập phản hồi của bác sĩ. Tin nhắn chuyên môn chỉ xuất hiện khi bác sĩ thật gửi hoặc khi người dùng chủ động mở trợ lý AI được gắn nhãn rõ ràng.
    }
  };

  const handleSelectUserFromMasterList = (userRecord: RegisteredUserRecord) => {
    store.setCurrentRole(userRecord.role);
    store.setUserProfile({
      id: userRecord.id,
      fullName: userRecord.fullName,
      phone: userRecord.phone,
      email: userRecord.email,
      role: userRecord.role,
      age: Number((userRecord as any).age) || 0,
      condition: userRecord.condition || 'Chưa cập nhật',
      surgeryDate: (userRecord as any).surgeryDate || '',
      affectedLeg: userRecord.affectedLeg,
      targetRomAngle: Number((userRecord as any).targetRomAngle) || 0,
      currentMaxAngle: 0,
      recoveryDays: 0,
      isDoctorAssigned: Boolean((userRecord as any).doctorName),
      doctorName: (userRecord as any).doctorName || 'Chưa được phân công',
      doctorHospital: (userRecord as any).doctorHospital || '',
      caregiverName: (userRecord as any).caregiverName || 'Chưa liên kết',
      caregiverPhone: (userRecord as any).caregiverPhone || '',
    });
    setIsLoggedIn(true);
    if (userRecord.role === UserRole.DOCTOR) setActiveTab('doctor');
    else if (userRecord.role === UserRole.CAREGIVER) setActiveTab('caregiver');
    else setActiveTab('home');
  };

  const handleRegisterNewUser = (newUserRecord: RegisteredUserRecord) => {
    store.setMasterRegisteredUsers(prev => [newUserRecord, ...prev]);
  };

  const handleAcknowledgeSafety = async () => {
    try {
      const token = localStorage.getItem('soft_exo_session_token') || '';
      await fetch('/api/sos/ack', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          alertId: latestSosAlert?.id,
          note: 'Người bệnh xác nhận an toàn trên ứng dụng.',
        }),
      });
    } catch (err) {
      console.warn('SOS acknowledgement notice:', err);
    }
    store.setTelemetry(prev => ({
      ...prev,
      isFallDetected: false,
      fallImpactG: 0,
      activityState: prev.isConnected ? 'Đang đồng bộ chuyển động thật từ thiết bị' : 'Đang chờ dữ liệu từ thiết bị',
    }));
    setLatestSosAlert(null);
  };

  const currentRoleInfo = USER_ROLE_INFO[store.currentRole];
  const roleHomeTab: AppTab = store.currentRole === UserRole.ADMIN ? 'admin' : store.currentRole === UserRole.DOCTOR ? 'doctor' : store.currentRole === UserRole.CAREGIVER ? 'caregiver' : 'home';
  const roleClass = `role-${String(store.currentRole || UserRole.PATIENT).toLowerCase()}`;

  if (!isLoggedIn) {
    return (
      <AuthScreen
        onLoginSuccess={handleLoginSuccess}
        onRegisterNewUser={handleRegisterNewUser}
      />
    );
  }

  return (
    <div className={`app-shell ${roleClass} min-h-screen flex flex-col font-sans selection:bg-blue-200 selection:text-slate-950`}>
      {/* Fall Emergency Banner (If active) */}
      {store.telemetry.isFallDetected && (
        <div className="sos-live-banner px-4 py-3 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs sm:text-sm font-bold z-50 shadow-xl">
          <div className="flex items-start gap-2.5">
            <ShieldAlert className="w-5 h-5 shrink-0 mt-0.5" />
            <div>
              <div className="font-black">Cảnh báo an toàn đang hoạt động</div>
              <div className="font-medium opacity-95 mt-0.5">
                {latestSosAlert?.message || `Phát hiện va đập / chuyển động bất thường (${store.telemetry.fallImpactG.toFixed(2)}G).`}
                {' '}Người thân đã bật cảnh báo khẩn cấp sẽ được thông báo ngay.
              </div>
            </div>
          </div>
          {store.currentRole === UserRole.PATIENT ? (
            <button
              onClick={handleAcknowledgeSafety}
              className="px-4 py-2 bg-white text-rose-700 rounded-xl text-xs font-black hover:bg-rose-50 transition-all shadow whitespace-nowrap"
            >
              Tôi ổn • Tắt cảnh báo
            </button>
          ) : (
            <button
              onClick={() => setActiveTab(store.currentRole === UserRole.CAREGIVER ? 'caregiver' : 'home')}
              className="px-4 py-2 bg-white text-rose-700 rounded-xl text-xs font-black hover:bg-rose-50 transition-all shadow whitespace-nowrap"
            >
              Xem cảnh báo
            </button>
          )}
        </div>
      )}

      {/* TOP BAR CONTRACT: Exactly 3 Zones, Single Row */}
      <header className="app-topbar sticky top-0 z-40 px-4 sm:px-8 py-3 flex items-center justify-between">
        {/* Zone 1: Brand (Single text element) */}
        <div className="cursor-pointer" onClick={() => setActiveTab(roleHomeTab)}>
          <KneeTwinLogo size="md" />
        </div>

        {/* Zone 2: Navigation (Tailored specifically per User Role) */}
        <nav className="app-nav hidden xl:flex items-center gap-1 p-1 rounded-2xl">
          {store.currentRole === UserRole.ADMIN ? (
            <>
              <button
                onClick={() => setActiveTab('admin')}
                className={`px-4 py-1.5 text-xs font-bold rounded-xl transition-colors whitespace-nowrap ${
                  activeTab === 'admin' ? 'bg-violet-600 text-white shadow-md' : 'text-violet-200 hover:text-white'
                }`}
              >
                Command Center
              </button>
            </>
          ) : store.currentRole === UserRole.DOCTOR ? (
            <>
              <button
                onClick={() => setActiveTab('doctor')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-colors whitespace-nowrap ${
                  activeTab === 'doctor' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Người bệnh
              </button>
              <button
                onClick={() => setActiveTab('chat')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-colors whitespace-nowrap ${
                  activeTab === 'chat' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Trao đổi
              </button>
              <button
                onClick={() => setActiveTab('twin3d')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-colors whitespace-nowrap ${
                  activeTab === 'twin3d' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Theo dõi vận động
              </button>
              <button
                onClick={() => setActiveTab('device')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-colors whitespace-nowrap ${
                  activeTab === 'device' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Thiết bị
              </button>
            </>
          ) : store.currentRole === UserRole.CAREGIVER ? (
            <>
              <button
                onClick={() => setActiveTab('caregiver')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-colors whitespace-nowrap ${
                  activeTab === 'caregiver' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Family Care
              </button>
              <button
                onClick={() => setActiveTab('passport')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-colors whitespace-nowrap ${
                  activeTab === 'passport' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Hộ chiếu phục hồi
              </button>
              <button
                onClick={() => setActiveTab('chat')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-colors whitespace-nowrap ${
                  activeTab === 'chat' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Trao đổi
              </button>

            </>
          ) : (
            <>
              <button
                onClick={() => setActiveTab('home')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-colors whitespace-nowrap ${
                  activeTab === 'home' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Hôm nay
              </button>
              <button
                onClick={() => setActiveTab('exercises')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-colors whitespace-nowrap ${
                  activeTab === 'exercises' || activeTab === 'training' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Bài tập
              </button>
              <button
                onClick={() => setActiveTab('twin3d')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-colors whitespace-nowrap ${
                  activeTab === 'twin3d' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Theo dõi vận động
              </button>
              <button
                onClick={() => setActiveTab('passport')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-colors whitespace-nowrap ${
                  activeTab === 'passport' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Hộ chiếu phục hồi
              </button>
              <button
                onClick={() => setActiveTab('chat')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-colors whitespace-nowrap ${
                  activeTab === 'chat' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Trao đổi
              </button>
              <button
                onClick={() => setActiveTab('device')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition-colors whitespace-nowrap ${
                  activeTab === 'device' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Thiết bị
              </button>
            </>
          )}
        </nav>

        {/* Zone 3: Primary Actions */}
        <div className="flex items-center gap-2">
          {/* GPS Live Pill Button */}
          {store.currentRole === UserRole.PATIENT && (
          <button
            onClick={() => setShowGpsModal(true)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border transition-all whitespace-nowrap shrink-0 ${
              geo.permissionStatus === 'granted' && geo.location
                ? 'bg-emerald-950/80 border-emerald-700 text-emerald-300 hover:bg-emerald-900/80'
                : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
            }`}
            title="Định vị vị trí thực tế GPS & Trạm Y Tế"
          >
            <MapPin className={`w-3.5 h-3.5 ${geo.permissionStatus === 'granted' ? 'text-emerald-400' : 'text-slate-400'}`} />
            <span className="hidden md:inline max-w-[140px] truncate">
              {geo.permissionStatus === 'granted' && geo.location
                ? (geo.location.district ? `${geo.location.district}, ${geo.location.city || ''}` : geo.location.formattedAddress)
                : geo.isLocating
                ? 'Đang tìm GPS...'
                : 'Định vị GPS'}
            </span>
            {geo.permissionStatus === 'granted' && (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
            )}
          </button>
          )}

          {store.currentRole === UserRole.PATIENT && (
          <button
            onClick={() => setActiveTab('device')}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-2 rounded-xl text-xs font-semibold border border-slate-700 transition-colors whitespace-nowrap shrink-0"
          >
            <ScanLine className="w-4 h-4 text-indigo-400" />
            <span className="hidden sm:inline">Quét mã sản phẩm</span>
          </button>
          )}

          <button
            onClick={() => setActiveTab('profile')}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-2 rounded-xl text-xs font-semibold border border-slate-700 transition-colors whitespace-nowrap shrink-0"
          >
            <div
              className="w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-bold text-white"
              style={{ backgroundColor: currentRoleInfo.color }}
            >
              {store.userProfile.fullName.charAt(0)}
            </div>
            <span className="hidden sm:inline">{store.userProfile.fullName.split(' ').pop()}</span>
          </button>

          {/* Mobile hamburger menu */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="xl:hidden p-2 rounded-xl bg-slate-800 text-slate-300 border border-slate-700"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </header>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="mobile-drawer xl:hidden p-4 space-y-2 z-30">
          {(store.currentRole === UserRole.ADMIN
            ? [
                { id: 'admin', label: '⚡ Command Center' },
                { id: 'profile', label: '👤 Hồ sơ Admin' },
              ]
            : store.currentRole === UserRole.DOCTOR
            ? [
                { id: 'doctor', label: '📋 Người bệnh' },
                { id: 'chat', label: '💬 Trao đổi' },
                { id: 'twin3d', label: '🦵 Theo dõi vận động' },
                { id: 'profile', label: '👤 Hồ sơ bác sĩ' },
              ]
            : store.currentRole === UserRole.CAREGIVER
            ? [
                { id: 'caregiver', label: '💙 Family Care' },
                { id: 'passport', label: '🪪 Tiến độ người bệnh' },
                { id: 'chat', label: '💬 Trao đổi' },
                { id: 'profile', label: '👤 Hồ sơ người thân' },
              ]
            : [
                { id: 'home', label: '🏠 Hôm nay' },
                { id: 'exercises', label: '▶️ Bài tập' },
                { id: 'twin3d', label: '🦵 Chuyển động' },
                { id: 'passport', label: '🪪 Hộ chiếu phục hồi' },
                { id: 'chat', label: '💬 Trao đổi' },
                { id: 'device', label: '⌁ Thiết bị' },
                { id: 'profile', label: '👤 Hồ sơ của tôi' },
              ]
          ).map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id as AppTab);
                setMobileMenuOpen(false);
              }}
              className={`w-full text-left p-3 rounded-xl text-xs font-semibold ${
                activeTab === item.id ? 'bg-indigo-600 text-white' : 'text-slate-300 hover:bg-slate-800'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      )}

      {/* MAIN BODY WORKSPACE */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        <div key={activeTab} className="page-transition-wrap space-y-6">
        {activeTab === 'admin' && (
          <AdminPortalScreen
            users={store.masterRegisteredUsers}
            currentAdminUser={store.userProfile}
            onSelectUserForLogin={() => {}}
            onDeleteUser={async (userId) => {
              store.setMasterRegisteredUsers(prev => prev.filter(u => u.id !== userId));
              try {
                await fetch(`/api/users/${userId}`, {
                  method: 'DELETE',
                  headers: { Authorization: `Bearer ${localStorage.getItem('soft_exo_session_token') || ''}` },
                });
              } catch (e) {
                console.warn('API delete user notice:', e);
              }
            }}
            onRegisterNewUser={(newUser) => {
              store.setMasterRegisteredUsers(prev => [newUser, ...prev]);
            }}
            onOpenChatWithUser={(userId) => {
              setActiveChatPatientId(userId);
              setActiveTab('chat');
            }}
          />
        )}
        {activeTab === 'home' && (
          <HomeScreen
            userProfile={store.userProfile}
            telemetry={store.telemetry}
            exercises={store.exercises}
            location={geo.location}
            permissionStatus={geo.permissionStatus}
            nearbyHospitals={geo.nearbyHospitals}
            onOpenGpsModal={() => setShowGpsModal(true)}
            onRequestLocation={geo.requestLocation}
            onNavigateToExercise={(id) => {
              if (id) {
                const ex = store.exercises.find(e => e.id === id);
                if (ex) setSelectedExercise(ex);
              }
              setActiveTab('training');
            }}
            onNavigateTo3DTwin={() => setActiveTab('twin3d')}
            onNavigateToDevice={() => setActiveTab('device')}
            onOpenPassport={() => setActiveTab('passport')}
            onSimulateAngle={handleSimulateAngle}
          />
        )}

        {activeTab === 'exercises' && (
          <ExerciseListScreen
            exercises={store.exercises}
            onSelectExercise={handleSelectExercise}
          />
        )}

        {activeTab === 'training' && (
          <ExerciseTrainingScreen
            exercise={selectedExercise}
            telemetry={store.telemetry}
            onBack={() => setActiveTab('exercises')}
            onCompleteExercise={handleCompleteExercise}
            onSimulateAngle={handleSimulateAngle}
          />
        )}

        {activeTab === 'twin3d' && (
          <DigitalTwinScreen
            telemetry={store.telemetry}
            onSimulateAngle={handleSimulateAngle}
            onCalibrateZero={handleCalibrateZero}
          />
        )}

        {activeTab === 'doctor' && (
          <DoctorScreen
            patients={store.doctorPatients}
            onOpenChatWithPatient={(patId) => {
              setActiveChatPatientId(patId);
              setActiveTab('chat');
            }}
            onUpdatePatientRom={(patId, newRom) => {
              store.setDoctorPatients(prev =>
                prev.map(p => (p.id === patId ? { ...p, targetRomAngle: newRom } : p))
              );
              store.setUserProfile(prev => ({ ...prev, targetRomAngle: newRom }));
            }}
            onOpenRecoveryPassport={(patId) => {
              setActivePassportPatientId(patId);
              setActiveTab('passport');
            }}
          />
        )}

        {activeTab === 'caregiver' && (
          <CaregiverScreen
            userProfile={store.userProfile}
            telemetry={store.telemetry}
            alerts={store.alerts}
            exercises={store.exercises}
            location={geo.location}
            permissionStatus={geo.permissionStatus}
            onOpenGpsModal={() => setShowGpsModal(true)}
            onOpenChat={() => setActiveTab('chat')}
            onOpenPassport={() => setActiveTab('passport')}
            onMarkAlertRead={(id) => {
              store.setAlerts(prev =>
                prev.map(a => (a.id === id ? { ...a, isRead: true } : a))
              );
            }}
            onDeleteAlert={(id) => {
              store.setAlerts(prev => prev.filter(a => a.id !== id));
            }}
          />
        )}

        {activeTab === 'passport' && (
          <RecoveryPassportScreen
            userRole={store.currentRole}
            userProfile={store.userProfile}
            telemetry={store.telemetry}
            patientId={store.currentRole === UserRole.DOCTOR ? activePassportPatientId : undefined}
          />
        )}

        {activeTab === 'chat' && (
          <ChatScreen
            userRole={store.currentRole}
            conversations={store.conversations}
            activePatientId={activeChatPatientId}
            onSelectPatientConversation={(patId) => setActiveChatPatientId(patId)}
            onSendMessage={handleSendMessage}
          />
        )}

        {activeTab === 'device' && (
          <DeviceConnectScreen
            device={store.connectedDevice}
            telemetry={store.telemetry}
            onConnectDevice={(productCode) => {
              store.setConnectedDevice(prev => ({
                ...prev,
                id: productCode || prev.id,
                serialNumber: productCode || prev.serialNumber,
                qrCodePayload: productCode || prev.qrCodePayload,
                status: DeviceStatus.CONNECTED,
              }));
            }}
            onDisconnectDevice={() => {
              store.setConnectedDevice(prev => ({ ...prev, status: DeviceStatus.DISCONNECTED }));
            }}
            onCalibrateZero={handleCalibrateZero}
            onUpdateSamplingRate={(rate) => {
              store.setTelemetry(prev => ({ ...prev, samplingRateHz: rate }));
            }}
          />
        )}

        {activeTab === 'profile' && (
          <ProfileScreen
            userProfile={store.userProfile}
            location={geo.location}
            permissionStatus={geo.permissionStatus}
            onOpenGpsModal={() => setShowGpsModal(true)}
            onRequestLocation={geo.requestLocation}
            onProfileUpdated={(profile) => store.setUserProfile(profile)}
            onLogout={handleLogout}
          />
        )}
        </div>
      </main>

      {/* First-time GPS Geolocation Prompt Modal */}
      <LocationPromptModal
        isOpen={isLoggedIn && geo.permissionStatus === 'prompt'}
        isLocating={geo.isLocating}
        errorMessage={geo.errorMessage}
        onAllowLocation={geo.requestLocation}
        onDenyLocation={geo.turnOffLocation}
      />

      {/* Detailed GPS Radar & Emergency Medical Centers Modal */}
      <GPSDetailsModal
        isOpen={showGpsModal}
        onClose={() => setShowGpsModal(false)}
        location={geo.location}
        permissionStatus={geo.permissionStatus}
        isLocating={geo.isLocating}
        nearbyHospitals={geo.nearbyHospitals}
        onRequestLocation={geo.requestLocation}
        onTurnOffLocation={geo.turnOffLocation}
      />

      {/* FLOATING MESSENGER QUICK CHAT BUBBLE (Available on all screens) */}
      {activeTab !== 'chat' && (
        <button
          onClick={() => setActiveTab('chat')}
          className="fixed bottom-6 right-6 z-40 p-4 bg-gradient-to-tr from-[#0084FF] to-indigo-600 hover:from-blue-600 hover:to-indigo-500 text-white rounded-full shadow-2xl transition-transform hover:scale-110 flex items-center justify-center group ring-4 ring-[#0084FF]/20"
          title="Mở phần trao đổi"
        >
          <MessageSquare className="w-6 h-6" />
          <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-emerald-500 border-2 border-slate-950 text-[10px] font-bold text-white flex items-center justify-center">
            1
          </span>
          <span className="max-w-0 overflow-hidden whitespace-nowrap group-hover:max-w-xs group-hover:ml-2 text-xs font-bold transition-all duration-300">
            Chat với Bác sĩ
          </span>
        </button>
      )}

      {/* FOOTER */}
      <footer className="border-t border-slate-800 bg-slate-950 py-4 px-4 sm:px-8 text-center text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
        <span>SOFT-EXO Family Care • Hỗ trợ phục hồi và chăm sóc tại nhà</span>
        <span className="text-slate-600">Ứng dụng hỗ trợ kết nối người bệnh • người thân • bác sĩ</span>
      </footer>
    </div>
  );
}
