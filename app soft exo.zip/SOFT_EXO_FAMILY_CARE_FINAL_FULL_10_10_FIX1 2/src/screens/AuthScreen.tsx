import React, { useState, useEffect } from 'react';
import { 
  User, 
  Lock, 
  Phone, 
  Mail, 
  ArrowRight, 
  CheckCircle2, 
  Eye, 
  EyeOff, 
  Sparkles, 
  ShieldCheck, 
  Smartphone, 
  Check, 
  ChevronRight,
  RotateCw,
  AlertTriangle,
  KeyRound,
  Hospital,
  Activity,
  Send,
  Inbox,
  AlertCircle,
  Zap,
  HeartHandshake,
  Building2,
  Link2,
  FileText
} from 'lucide-react';
import { UserRole, AuthMode, AuthChannel, AffectedLeg, RegisteredUserRecord } from '../types';
import { ALL_APP_FEATURES } from '../data/mockData';
import { KneeTwinLogo } from '../components/KneeTwinLogo';
import { db, doc, setDoc, getDocs, collection } from '../firebase';

// Persistent storage key
const STORAGE_USERS_KEY = 'kneetwin_master_users_db';

// Regex for Vietnamese Mobile Numbers & User input test numbers (10-12 digits)
export const isValidVietnamesePhone = (phoneStr: string): boolean => {
  const cleaned = phoneStr.replace(/[\s.-]/g, '');
  // Accepts standard 10-digit mobile numbers as well as 10-12 digit inputs like 036797367555 or +84
  const vnPhoneRegex = /^(0|\+84)[0-9]{8,12}$/;
  return vnPhoneRegex.test(cleaned);
};

// Regex for Email address
export const isValidEmail = (emailStr: string): boolean => {
  const cleaned = emailStr.trim();
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return emailRegex.test(cleaned);
};

interface AuthScreenProps {
  onLoginSuccess: (userProfile: any) => void;
  onRegisterNewUser: (newUser: RegisteredUserRecord) => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({
  onLoginSuccess,
  onRegisterNewUser,
}) => {
  const [authMode, setAuthMode] = useState<AuthMode>(AuthMode.LOGIN);
  const [authChannel, setAuthChannel] = useState<AuthChannel>(AuthChannel.EMAIL);
  const [showPassword, setShowPassword] = useState(false);

  // Login Form
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Optional notification banner for authentication feedback
  const [notificationBanner, setNotificationBanner] = useState<{
    type: 'sms' | 'email';
    target: string;
    code: string;
    title: string;
    message: string;
  } | null>(null);

  // OTP Verification for Login
  const [enteredLoginOtp, setEnteredLoginOtp] = useState('');

  // Register Form Multi-Step (1: Info & OTP Method Choice, 2: OTP Verification, 3: Features, 4: Review)
  const [regStep, setRegStep] = useState<1 | 2 | 3 | 4>(1);
  const [regRole, setRegRole] = useState<UserRole>(UserRole.PATIENT);
  const [regFullName, setRegFullName] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regAge, setRegAge] = useState<number>(58);
  const [regAffectedLeg, setRegAffectedLeg] = useState<AffectedLeg>(AffectedLeg.RIGHT);
  const [regCondition, setRegCondition] = useState('Tái tạo dây chằng chéo trước (ACL)');
  const [regHospital, setRegHospital] = useState('');
  const [regFacilityCode, setRegFacilityCode] = useState('');
  const [regDepartment, setRegDepartment] = useState('');
  const [regMedicalRecordCode, setRegMedicalRecordCode] = useState('');
  const [regRelationship, setRegRelationship] = useState('Con/Cháu');
  const [regPatientInviteCode, setRegPatientInviteCode] = useState('');
  const [regPackageTier, setRegPackageTier] = useState('SOFT-EXO Care');
  const [selectedFeatureIds, setSelectedFeatureIds] = useState<string[]>([
    'feat_3d_twin', 'feat_imu_sensor', 'feat_ai_coach', 'feat_fall_detection', 'feat_doctor_telehealth'
  ]);

  // Validation errors for fields in Step 1
  const [fieldErrors, setFieldErrors] = useState<{
    fullName?: string;
    phone?: string;
    email?: string;
    password?: string;
  }>({});

  // OTP delivery is Email-only in this build
  const [otpDeliveryMethod, setOtpDeliveryMethod] = useState<'sms' | 'email'>('email');
  const [expectedOtp, setExpectedOtp] = useState<string>('');
  const [enteredOtp, setEnteredOtp] = useState<string>('');
  const [isOtpVerified, setIsOtpVerified] = useState<boolean>(false);
  const [otpError, setOtpError] = useState<string | null>(null);
  const [resendTimer, setResendTimer] = useState<number>(60);
  const [isSendingOtp, setIsSendingOtp] = useState(false);
  const [dispatchStatusMessage, setDispatchStatusMessage] = useState<string | null>(null);

  // =========================================================================
  // FORGOT PASSWORD STATE & FLOW (Quên mật khẩu: OTP VỀ SIM HOẶC GMAIL)
  // =========================================================================
  const [forgotTarget, setForgotTarget] = useState('');
  const [forgotChannel, setForgotChannel] = useState<'sms' | 'email'>('email');
  const [forgotStep, setForgotStep] = useState<1 | 2 | 3>(1); // 1: Input & Channel, 2: OTP, 3: New Password
  const [forgotExpectedOtp, setForgotExpectedOtp] = useState('');
  const [forgotEnteredOtp, setForgotEnteredOtp] = useState('');
  const [forgotIsOtpVerified, setForgotIsOtpVerified] = useState(false);
  const [forgotNewPassword, setForgotNewPassword] = useState('');
  const [forgotConfirmPassword, setForgotConfirmPassword] = useState('');
  const [forgotShowPassword, setForgotShowPassword] = useState(false);
  const [forgotError, setForgotError] = useState<string | null>(null);
  const [forgotSuccessMsg, setForgotSuccessMsg] = useState<string | null>(null);
  const [forgotResendTimer, setForgotResendTimer] = useState<number>(60);
  const [isSubmittingForgot, setIsSubmittingForgot] = useState(false);

  // Accounts Database (LocalStorage-backed)
  const getRegisteredUsersDatabase = (): any[] => {
    try {
      const stored = localStorage.getItem(STORAGE_USERS_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) {
          // V7: remove legacy demo identities from browser storage as well.
          const demoIds = new Set(['usr_admin_01', 'user_01', 'doc_01', 'care_01', 'reg_admin_01', 'reg_01', 'reg_02', 'reg_03', 'reg_04']);
          return parsed.filter((item: any) => !demoIds.has(String(item?.id || '')));
        }
      }
    } catch (e) {
      console.error(e);
    }
    return [];
  };

  // Countdown timer for Registration OTP
  useEffect(() => {
    let interval: any;
    if (resendTimer > 0 && regStep === 2 && authMode === AuthMode.REGISTER) {
      interval = setInterval(() => {
        setResendTimer(prev => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [resendTimer, regStep, authMode]);

  // Countdown timer for Forgot Password OTP
  useEffect(() => {
    let interval: any;
    if (forgotResendTimer > 0 && forgotStep === 2 && authMode === AuthMode.FORGOT_PASSWORD) {
      interval = setInterval(() => {
        setForgotResendTimer(prev => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [forgotResendTimer, forgotStep, authMode]);

  // Generate 6-digit random secure OTP
  const generateRandomOtp = () => {
    return Math.floor(100000 + Math.random() * 900000).toString();
  };

  // Send a REAL OTP to the user's email using the backend/Brevo provider.
  const sendRegistrationOtp = async (_method: 'sms' | 'email' = 'email') => {
    setIsSendingOtp(true);
    setOtpError(null);
    setOtpDeliveryMethod('email');
    const targetAddress = regEmail.trim();
    setDispatchStatusMessage(`Đang gửi mã OTP thật tới ${targetAddress}...`);

    try {
      const response = await fetch('/api/auth/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          target: targetAddress,
          channel: 'email',
          fullName: regFullName.trim(),
          purpose: 'register',
        }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(data.error || 'Không thể gửi OTP tới email này.');
      }

      setExpectedOtp('');
      setIsOtpVerified(false);
      setEnteredOtp('');
      setResendTimer(60);
      setRegStep(2);
      setDispatchStatusMessage(data.message || `Đã gửi OTP thật tới ${targetAddress}.`);
      setTimeout(() => setDispatchStatusMessage(null), 3500);
    } catch (err: any) {
      setOtpError(err?.message || 'Gửi OTP thất bại. Vui lòng kiểm tra cấu hình Email OTP trong trang Admin.');
      setDispatchStatusMessage(null);
    } finally {
      setIsSendingOtp(false);
    }
  };

  // Forgot password OTP is also delivered by real email only.
  const sendForgotPasswordOtp = async (_method: 'sms' | 'email' = 'email') => {
    setForgotError(null);
    setForgotSuccessMsg(null);
    setForgotChannel('email');
    const target = forgotTarget.trim();

    if (!target) {
      setForgotError('Vui lòng nhập địa chỉ email đã đăng ký tài khoản.');
      return;
    }
    if (!isValidEmail(target)) {
      setForgotError('Địa chỉ email không đúng định dạng (ví dụ: yourname@gmail.com).');
      return;
    }

    setIsSubmittingForgot(true);
    try {
      const response = await fetch('/api/auth/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ target, channel: 'email', purpose: 'forgot_password' }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || 'Không thể gửi OTP tới email này.');

      setForgotExpectedOtp('');
      setForgotIsOtpVerified(false);
      setForgotEnteredOtp('');
      setForgotResendTimer(60);
      setForgotStep(2);
      setForgotSuccessMsg(`Đã gửi mã OTP thật tới ${target}. Kiểm tra Inbox hoặc Spam.`);
    } catch (err: any) {
      setForgotError(err?.message || 'Gửi OTP thất bại.');
    } finally {
      setIsSubmittingForgot(false);
    }
  };

  // Verify forgot-password OTP against the backend. The code never exists in the browser.
  const handleVerifyForgotOtp = async () => {
    setForgotError(null);
    const code = forgotEnteredOtp.trim();
    if (!/^\d{6}$/.test(code)) {
      setForgotError('Vui lòng nhập đủ 6 chữ số OTP trong email.');
      return;
    }
    try {
      const response = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ target: forgotTarget.trim(), code, purpose: 'forgot_password' }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data.verified) throw new Error(data.error || 'OTP không chính xác.');
      setForgotIsOtpVerified(true);
      setForgotStep(3);
      setForgotSuccessMsg(null);
    } catch (err: any) {
      setForgotError(err?.message || 'Không thể xác thực OTP.');
    }
  };

  // Submit New Password after OTP verified
  const handleResetPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError(null);
    setForgotSuccessMsg(null);

    if (!forgotNewPassword || forgotNewPassword.length < 6) {
      setForgotError('Mật khẩu mới phải có tối thiểu 6 ký tự.');
      return;
    }

    if (forgotNewPassword !== forgotConfirmPassword) {
      setForgotError('Mật khẩu nhập lại không khớp với mật khẩu mới. Vui lòng kiểm tra lại.');
      return;
    }

    setIsSubmittingForgot(true);

    try {
      // 1. Call Backend API to update password
      const response = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          target: forgotTarget.trim(),
          code: forgotEnteredOtp.trim(),
          newPassword: forgotNewPassword,
        }),
      });
      const resetData = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(resetData.error || 'Không thể cập nhật mật khẩu mới.');
      }

      setIsSubmittingForgot(false);
      setForgotSuccessMsg('🎉 Đặt lại mật khẩu mới thành công! Hệ thống đang chuyển về màn hình đăng nhập...');

      // Auto pre-fill login
      setLoginIdentifier(forgotTarget.trim());
      setLoginPassword(forgotNewPassword);

      setTimeout(() => {
        setAuthMode(AuthMode.LOGIN);
        setForgotStep(1);
        setForgotTarget('');
        setForgotNewPassword('');
        setForgotConfirmPassword('');
        setForgotSuccessMsg(null);
      }, 1800);
    } catch (err: any) {
      setIsSubmittingForgot(false);
      setForgotError(err?.message || 'Có lỗi xảy ra khi cập nhật mật khẩu mới. Vui lòng thử lại.');
    }
  };

  // Validate registration form before sending Email OTP
  const handleStartRegistrationOtpVerification = () => {
    const errors: typeof fieldErrors = {};

    // 1. Full name validation
    if (!regFullName.trim() || regFullName.trim().length < 3) {
      errors.fullName = 'Vui lòng nhập họ và tên đầy đủ (tối thiểu 3 ký tự).';
    }

    // 2. Phone validation (Strict Vietnamese Mobile format)
    if (!regPhone.trim()) {
      errors.phone = 'Vui lòng nhập số điện thoại di động.';
    } else if (!isValidVietnamesePhone(regPhone)) {
      errors.phone = 'Số điện thoại không đúng định dạng nhà mạng Việt Nam (yêu cầu 10 số, bắt đầu bằng 03, 05, 07, 08, 09).';
    }

    // 3. Email validation (Strict RFC Email format)
    if (!regEmail.trim()) {
      errors.email = 'Vui lòng nhập địa chỉ Email.';
    } else if (!isValidEmail(regEmail)) {
      errors.email = 'Địa chỉ Email không đúng định dạng (ví dụ: yourname@gmail.com, name@domain.vn).';
    }

    // 4. Password validation
    if (!regPassword || regPassword.length < 6) {
      errors.password = 'Mật khẩu bảo mật phải có tối thiểu 6 ký tự.';
    }

    // Check if phone or email is already registered.
    const existingUsers = getRegisteredUsersDatabase();
    const cleanPhone = regPhone.replace(/[\s.-]/g, '');
    const cleanEmail = regEmail.trim().toLowerCase();
    const isPhoneTaken = existingUsers.some(u => u.phone && u.phone.replace(/[\s.-]/g, '') === cleanPhone);
    const isEmailTaken = existingUsers.some(u => u.email && u.email.toLowerCase() === cleanEmail);

    if (isPhoneTaken) {
      errors.phone = 'Số điện thoại này đã được đăng ký. Vui lòng đăng nhập hoặc chọn Quên mật khẩu.';
    }
    if (isEmailTaken) {
      errors.email = 'Địa chỉ email này đã được đăng ký. Vui lòng đăng nhập hoặc chọn Quên mật khẩu.';
    }

    setFieldErrors(errors);

    if (Object.keys(errors).length > 0) {
      return;
    }

    // All inputs are strictly valid -> dispatch OTP via chosen method
    setOtpDeliveryMethod('email');
    sendRegistrationOtp('email');
  };

  // SMS OTP has been removed from this build. Email OTP is the single verified channel.
  const handleSwitchOtpMethod = (_newMethod: 'sms' | 'email') => {
    setOtpDeliveryMethod('email');
    sendRegistrationOtp('email');
  };

  // Verify single OTP
  const handleVerifyOtp = async () => {
    setOtpError(null);
    const code = enteredOtp.trim();
    if (!/^\d{6}$/.test(code)) {
      setOtpError('Vui lòng nhập đủ 6 chữ số OTP trong email.');
      return;
    }
    try {
      const response = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ target: regEmail.trim(), code, purpose: 'register' }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data.verified) throw new Error(data.error || 'Mã OTP không chính xác.');
      setIsOtpVerified(true);
      setOtpError(null);
    } catch (err: any) {
      setIsOtpVerified(false);
      setOtpError(err?.message || 'Không thể xác thực OTP.');
    }
  };

  // Step 2 Proceed to Step 3 after OTP is verified
  const handleProceedToStep3 = () => {
    if (!isOtpVerified) {
      setOtpError('Vui lòng nhập và xác nhận đúng mã 6 số OTP gửi qua Email trước khi tiếp tục.');
      return;
    }
    setOtpError(null);
    setRegStep(3);
  };

  const handleToggleFeature = (id: string) => {
    setSelectedFeatureIds((prev) =>
      prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id]
    );
  };

  // Login is validated against the shared backend database so accounts work
  // across phones/browsers connected to the same SOFT-EXO server.
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setIsLoggingIn(true);

    const identifier = loginIdentifier.trim();
    const password = loginPassword;
    if (!identifier || !password) {
      setLoginError('Vui lòng nhập tài khoản và mật khẩu.');
      setIsLoggingIn(false);
      return;
    }
    if (authChannel === AuthChannel.PHONE && !isValidVietnamesePhone(identifier)) {
      setLoginError('Số điện thoại không đúng định dạng.');
      setIsLoggingIn(false);
      return;
    }
    if (authChannel === AuthChannel.EMAIL && !isValidEmail(identifier)) {
      setLoginError('Địa chỉ email không đúng định dạng.');
      setIsLoggingIn(false);
      return;
    }

    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier, password }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data.user) {
        throw new Error(data.error || 'Tài khoản hoặc mật khẩu không chính xác.');
      }

      const u = data.user;
      if (data.token) localStorage.setItem('soft_exo_session_token', data.token);
      onLoginSuccess({
        id: u.id,
        fullName: u.fullName,
        phone: u.phone,
        email: u.email,
        role: u.role,
        age: Number(u.age) || 0,
        condition: u.condition || 'Chưa cập nhật',
        surgeryDate: u.surgeryDate || '',
        affectedLeg: u.affectedLeg || AffectedLeg.RIGHT,
        targetRomAngle: Number(u.targetRomAngle) || 0,
        currentMaxAngle: 0,
        recoveryDays: 0,
        isDoctorAssigned: Boolean(u.doctorId || u.doctorName),
        doctorName: u.doctorName || 'Chưa được phân công',
        doctorHospital: u.doctorHospital || '',
        caregiverName: u.caregiverName || 'Chưa liên kết',
        caregiverPhone: u.caregiverPhone || '',
        dateOfBirth: u.dateOfBirth || '',
        gender: u.gender || '',
        address: u.address || '',
        recoveryStartDate: u.recoveryStartDate || '',
        emergencyContactName: u.emergencyContactName || '',
        emergencyContactPhone: u.emergencyContactPhone || '',
        medicalHistory: u.medicalHistory || '',
        allergies: u.allergies || '',
        medications: u.medications || '',
        privacyConsentAt: u.privacyConsentAt || '',
        shareWithDoctor: Boolean(u.shareWithDoctor),
        shareWithCaregiver: Boolean(u.shareWithCaregiver),
        shareLocationOnSos: Boolean(u.shareLocationOnSos),
        facilityName: u.facilityName || u.doctorHospital || '',
        facilityCode: u.facilityCode || '',
        department: u.department || '',
        medicalRecordCode: u.medicalRecordCode || '',
        familyInviteCode: u.familyInviteCode || '',
        relationship: u.relationship || '',
        linkedPatientId: u.linkedPatientId || '',
        linkedAt: u.linkedAt || '',
      });
    } catch (err: any) {
      setLoginError(err?.message || 'Đăng nhập thất bại.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleCompleteRegistration = async () => {
    setOtpError(null);
    const draftUserRecord: RegisteredUserRecord = {
      id: `usr_${Date.now()}`,
      fullName: regFullName.trim(),
      email: regEmail.trim().toLowerCase(),
      phone: regPhone.trim(),
      role: regRole,
      packageTier: regRole === UserRole.PATIENT ? 'SOFT-EXO Patient' : 'SOFT-EXO Family Care',
      registeredFeatures: selectedFeatureIds.map(
        (id) => ALL_APP_FEATURES.find((f) => f.id === id)?.name || id
      ),
      hardwareDeviceId: '',
      condition: regRole === UserRole.PATIENT ? regCondition : 'Người thân hỗ trợ phục hồi',
      affectedLeg: regRole === UserRole.PATIENT ? regAffectedLeg : AffectedLeg.BOTH,
      registrationTimestamp: new Date().toLocaleString('vi-VN'),
      status: 'Đã kích hoạt',
      notes: 'Đã xác thực Email OTP thật thành công qua Brevo',
      facilityName: regRole === UserRole.PATIENT ? regHospital.trim() : '',
      facilityCode: regRole === UserRole.PATIENT ? regFacilityCode.trim() : '',
      department: regRole === UserRole.PATIENT ? regDepartment.trim() : '',
      medicalRecordCode: regRole === UserRole.PATIENT ? regMedicalRecordCode.trim() : '',
      patientInviteCode: regRole === UserRole.CAREGIVER ? regPatientInviteCode.trim() : '',
      relationship: regRole === UserRole.CAREGIVER ? regRelationship : '',
    };

    try {
      const response = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...draftUserRecord,
          password: regPassword,
          age: regAge,
        }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data.user) {
        throw new Error(data.error || 'Không thể tạo tài khoản trên hệ thống.');
      }

      if (data.token) localStorage.setItem('soft_exo_session_token', data.token);

      const newUserRecord: RegisteredUserRecord = {
        ...draftUserRecord,
        ...data.user,
        role: regRole,
      };

      // Local cache only. The shared server database remains the source of truth.
      const existingUsers = getRegisteredUsersDatabase().filter((u) => u.id !== newUserRecord.id);
      localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify([
        ...existingUsers,
        { ...newUserRecord, age: regAge },
      ]));

      // Optional cloud sync. Failure here must not block registration.
      setDoc(doc(db, 'users', newUserRecord.id), {
        id: newUserRecord.id,
        fullName: newUserRecord.fullName,
        email: newUserRecord.email,
        phone: newUserRecord.phone,
        role: newUserRecord.role,
        age: regAge,
        condition: newUserRecord.condition,
        affectedLeg: newUserRecord.affectedLeg,
        packageTier: newUserRecord.packageTier,
        registeredFeatures: newUserRecord.registeredFeatures,
        hardwareDeviceId: newUserRecord.hardwareDeviceId,
        registrationTimestamp: new Date().toISOString(),
        status: 'Đã kích hoạt',
      }).catch(err => console.warn('Firestore user sync note:', err));

      onRegisterNewUser(newUserRecord);
      onLoginSuccess({
        id: newUserRecord.id,
        fullName: newUserRecord.fullName,
        phone: newUserRecord.phone,
        email: newUserRecord.email,
        role: regRole,
        age: regAge,
        condition: newUserRecord.condition,
        surgeryDate: '',
        affectedLeg: newUserRecord.affectedLeg,
        targetRomAngle: 0,
        currentMaxAngle: 0,
        recoveryDays: 0,
        isDoctorAssigned: false,
        doctorName: 'Chưa được phân công',
        doctorHospital: '',
        caregiverName: 'Chưa liên kết',
        caregiverPhone: '',
        facilityName: regRole === UserRole.PATIENT ? regHospital.trim() : '',
        facilityCode: regRole === UserRole.PATIENT ? regFacilityCode.trim() : '',
        department: regRole === UserRole.PATIENT ? regDepartment.trim() : '',
        medicalRecordCode: regRole === UserRole.PATIENT ? regMedicalRecordCode.trim() : '',
        relationship: regRole === UserRole.CAREGIVER ? regRelationship : '',
        linkedPatientId: data.user?.linkedPatientId || '',
      });
    } catch (err: any) {
      setOtpError(err?.message || 'Kích hoạt tài khoản thất bại. Vui lòng thử lại.');
    }
  };

  return (
    <div className="auth-shell min-h-screen py-5 sm:py-8 px-4 flex flex-col items-center justify-center relative">
      
      {/* Main Authentication Box */}
      <div className="auth-panel w-full max-w-lg rounded-3xl p-5 sm:p-8 space-y-6">
        
        {/* App Title & Logo */}
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="auth-top-chip">
            <ShieldCheck className="w-4 h-4" />
            SOFT-EXO Family Care
          </div>
          <KneeTwinLogo size="lg" />
          <div className="space-y-2 max-w-md">
            <h1 className="auth-card-title">
              {authMode === AuthMode.LOGIN ? 'Chào mừng quay lại' : authMode === AuthMode.REGISTER ? 'Tạo tài khoản mới' : 'Khôi phục mật khẩu'}
            </h1>
            <p className="auth-card-subtitle">
              Theo dõi quá trình phục hồi khớp gối, luyện tập tại nhà và kết nối với gia đình hoặc bác sĩ trên một giao diện đơn giản, dễ dùng.
            </p>
          </div>
        </div>

        {/* Tab Switcher: Login vs Register vs Forgot Password */}
        <div className="auth-mode-tabs flex gap-1">
          <button
            onClick={() => { 
              setAuthMode(AuthMode.LOGIN); 
              setNotificationBanner(null); 
              setLoginError(null);
            }}
            className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all ${
              authMode === AuthMode.LOGIN
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            Đăng nhập
          </button>
          <button
            onClick={() => { 
              setAuthMode(AuthMode.REGISTER); 
              setRegStep(1);
              setIsOtpVerified(false);
              setNotificationBanner(null);
              setFieldErrors({});
            }}
            className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all ${
              authMode === AuthMode.REGISTER
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            Đăng ký
          </button>
          {authMode === AuthMode.FORGOT_PASSWORD && (
            <button
              onClick={() => setAuthMode(AuthMode.FORGOT_PASSWORD)}
              className="flex-1 py-2.5 rounded-xl text-xs font-bold transition-all bg-amber-600 text-white shadow-md"
            >
              Quên mật khẩu
            </button>
          )}
        </div>

        {/* ========================================================================= */}
        {/* VIEW 1: LOGIN (AUTHENTIC LOGIN WITH STRICT VALIDATION)                    */}
        {/* ========================================================================= */}
        {authMode === AuthMode.LOGIN && (
          <form onSubmit={handleLoginSubmit} className="space-y-4">
            
            {/* Error Message Box */}
            {loginError && (
              <div className="p-3 bg-rose-950/80 border border-rose-800 text-rose-200 text-xs rounded-2xl flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span className="leading-relaxed">{loginError}</span>
              </div>
            )}

            {/* Channel Tabs: Phone vs Email */}
            <div className="flex justify-center gap-2 rounded-2xl bg-slate-50 p-1.5 text-xs font-semibold text-slate-500 border border-slate-200">
              <button
                type="button"
                onClick={() => { setAuthChannel(AuthChannel.PHONE); setLoginError(null); }}
                className={`pb-1 border-b-2 transition-colors ${
                  authChannel === AuthChannel.PHONE
                    ? 'text-indigo-400 border-indigo-500 font-bold'
                    : 'border-transparent hover:text-slate-900'
                }`}
              >
                Đăng nhập bằng Số điện thoại
              </button>
              <button
                type="button"
                onClick={() => { setAuthChannel(AuthChannel.EMAIL); setLoginError(null); }}
                className={`pb-1 border-b-2 transition-colors ${
                  authChannel === AuthChannel.EMAIL
                    ? 'text-indigo-400 border-indigo-500 font-bold'
                    : 'border-transparent hover:text-slate-900'
                }`}
              >
                Đăng nhập bằng Email
              </button>
            </div>

            {/* Input Identifier */}
            <div className="auth-field space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">
                {authChannel === AuthChannel.PHONE ? 'Số điện thoại di động:' : 'Địa chỉ Email:'}
              </label>
              <div className="relative">
                {authChannel === AuthChannel.PHONE ? (
                  <Phone className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                ) : (
                  <Mail className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                )}
                <input
                  type={authChannel === AuthChannel.PHONE ? 'tel' : 'email'}
                  value={loginIdentifier}
                  onChange={(e) => setLoginIdentifier(e.target.value)}
                  placeholder={authChannel === AuthChannel.PHONE ? 'Nhập số điện thoại của bạn' : 'Nhập địa chỉ email'}
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl pl-10 pr-4 py-3 text-xs sm:text-sm text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 font-mono"
                />
              </div>
            </div>

            {/* Password Input & Forgot Password Trigger */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-slate-300">Mật khẩu bảo mật:</label>
                <button
                  type="button"
                  onClick={() => {
                    setAuthMode(AuthMode.FORGOT_PASSWORD);
                    setForgotStep(1);
                    setForgotError(null);
                    setForgotSuccessMsg(null);
                    setForgotTarget(authChannel === AuthChannel.EMAIL ? loginIdentifier.trim() : '');
                    setForgotChannel('email');
                  }}
                  className="text-xs text-amber-400 hover:text-amber-300 font-bold transition-colors flex items-center gap-1"
                >
                  <KeyRound className="w-3.5 h-3.5" />
                  <span>Quên mật khẩu?</span>
                </button>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="Nhập mật khẩu"
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl pl-10 pr-10 py-3 text-xs sm:text-sm text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Submit Login Button */}
            <button
              type="submit"
              disabled={isLoggingIn}
              className="auth-primary-btn w-full py-3.5 text-white font-bold text-xs sm:text-sm rounded-2xl shadow-lg flex items-center justify-center gap-2"
            >
              {isLoggingIn ? (
                <>
                  <RotateCw className="w-4 h-4 animate-spin" />
                  <span>Đang xác thực thông tin...</span>
                </>
              ) : (
                <>
                  <span>Đăng Nhập Vào Hệ Thống</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        )}

        {/* ========================================================================= */}
        {/* VIEW 3: FORGOT PASSWORD (EMAIL OTP THẬT)     */}
        {/* ========================================================================= */}
        {authMode === AuthMode.FORGOT_PASSWORD && (
          <div className="space-y-5">
            {/* Header Info */}
            <div className="text-center space-y-1">
              <div className="inline-flex items-center justify-center p-3 bg-amber-950/60 border border-amber-800/80 rounded-2xl text-amber-400 mb-1">
                <KeyRound className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white">Khôi Phục Mật Khẩu Tài Khoản</h3>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                Lấy lại mật khẩu bằng <strong>Email OTP thật</strong>. Mã 6 số sẽ được gửi trực tiếp tới hộp thư đã đăng ký và chỉ dùng một lần.
              </p>
            </div>

            {/* Step Indicators */}
            <div className="flex items-center justify-between text-xs px-2">
              <div className={`flex items-center gap-1.5 font-bold ${forgotStep >= 1 ? 'text-amber-400' : 'text-slate-600'}`}>
                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] border ${
                  forgotStep >= 1 ? 'bg-amber-950 border-amber-700 text-amber-300' : 'bg-slate-950 border-slate-800'
                }`}>1</span>
                <span>Kênh nhận OTP</span>
              </div>
              <div className="h-px w-8 bg-slate-800" />
              <div className={`flex items-center gap-1.5 font-bold ${forgotStep >= 2 ? 'text-amber-400' : 'text-slate-600'}`}>
                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] border ${
                  forgotStep >= 2 ? 'bg-amber-950 border-amber-700 text-amber-300' : 'bg-slate-950 border-slate-800'
                }`}>2</span>
                <span>Nhập mã OTP</span>
              </div>
              <div className="h-px w-8 bg-slate-800" />
              <div className={`flex items-center gap-1.5 font-bold ${forgotStep >= 3 ? 'text-amber-400' : 'text-slate-600'}`}>
                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] border ${
                  forgotStep >= 3 ? 'bg-amber-950 border-amber-700 text-amber-300' : 'bg-slate-950 border-slate-800'
                }`}>3</span>
                <span>Đặt mật khẩu mới</span>
              </div>
            </div>

            {/* Error or Success Alert */}
            {forgotError && (
              <div className="p-3 bg-rose-950/80 border border-rose-800 text-rose-200 text-xs rounded-2xl flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span className="leading-relaxed">{forgotError}</span>
              </div>
            )}

            {forgotSuccessMsg && (
              <div className="p-3.5 bg-emerald-950/90 border border-emerald-700 text-emerald-200 text-xs rounded-2xl flex items-center gap-2 shadow-lg">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                <span className="font-semibold">{forgotSuccessMsg}</span>
              </div>
            )}

            {/* FORGOT STEP 1: CHOOSE CHANNEL (SIM OR GMAIL) AND ENTER TARGET */}
            {forgotStep === 1 && (
              <div className="space-y-4">
                {/* Email OTP channel */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                    <Send className="w-3.5 h-3.5 text-amber-400" />
                    <span>Mã OTP sẽ được gửi tới email đã đăng ký:</span>
                  </label>

                  <div className="grid grid-cols-1 gap-3">
                    {/* Option 2: Gmail / Email */}
                    <div
                      onClick={() => {
                        setForgotChannel('email');
                        setForgotError(null);
                      }}
                      className={`p-3.5 rounded-2xl border cursor-pointer transition-all flex items-center gap-3 ${
                        forgotChannel === 'email'
                          ? 'bg-indigo-950/70 border-indigo-500 shadow-lg ring-1 ring-indigo-500/50'
                          : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className={`p-2.5 rounded-xl border ${
                        forgotChannel === 'email'
                          ? 'bg-indigo-600 text-white border-indigo-500'
                          : 'bg-slate-900 text-slate-400 border-slate-800'
                      }`}>
                        <Mail className="w-5 h-5" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="text-xs font-bold text-white flex items-center justify-between">
                          <span>Gửi OTP thật qua Email</span>
                          {forgotChannel === 'email' && <Check className="w-3.5 h-3.5 text-indigo-400" />}
                        </div>
                        <p className="text-[11px] text-slate-400">Kiểm tra Inbox hoặc Spam</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Input Target */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">
                    Nhập địa chỉ Email đăng ký tài khoản:
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                    <input
                      type="email"
                      value={forgotTarget}
                      onChange={(e) => {
                        setForgotTarget(e.target.value);
                        setForgotError(null);
                      }}
                      placeholder="Ví dụ: tenban@gmail.com"
                      className="w-full bg-slate-950 border border-slate-800 rounded-2xl pl-10 pr-4 py-3 text-xs sm:text-sm text-slate-100 placeholder-slate-600 focus:outline-none focus:border-amber-500 font-mono"
                    />
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setAuthMode(AuthMode.LOGIN);
                      setForgotError(null);
                    }}
                    className="px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-2xl transition-colors"
                  >
                    Quay lại Đăng nhập
                  </button>
                  <button
                    type="button"
                    disabled={isSubmittingForgot}
                    onClick={() => sendForgotPasswordOtp('email')}
                    className="flex-1 py-3 bg-amber-600 hover:bg-amber-500 disabled:bg-slate-800 text-white font-bold text-xs rounded-2xl transition-colors shadow-lg flex items-center justify-center gap-2"
                  >
                    {isSubmittingForgot ? (
                      <>
                        <RotateCw className="w-4 h-4 animate-spin" />
                        <span>Đang gửi mã OTP...</span>
                      </>
                    ) : (
                      <>
                        <span>Gửi Mã OTP Lấy Lại Mật Khẩu</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

            {/* FORGOT STEP 2: ENTER OTP CODE */}
            {forgotStep === 2 && (
              <div className="space-y-4">
                <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-2xl space-y-1 text-center">
                  <p className="text-xs text-slate-400">
                    Mã OTP 6 chữ số đã được gửi tới email:
                  </p>
                  <p className="text-sm font-bold font-mono text-amber-400">{forgotTarget}</p>
                </div>

                {/* OTP Input Card */}
                <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
                  <label className="text-xs font-semibold text-slate-300 block text-center">
                    Nhập mã xác thực 6 số OTP:
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      maxLength={6}
                      placeholder="000000"
                      value={forgotEnteredOtp}
                      onChange={(e) => {
                        setForgotEnteredOtp(e.target.value);
                        setForgotError(null);
                      }}
                      className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2.5 text-center text-sm font-mono tracking-widest text-white font-bold focus:outline-none focus:border-amber-500"
                    />
                    <button
                      type="button"
                      onClick={handleVerifyForgotOtp}
                      className="px-5 py-2.5 bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold rounded-xl transition-colors shadow shrink-0"
                    >
                      Xác nhận mã OTP
                    </button>
                  </div>

                </div>

                {/* Resend timer or switch channel */}
                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-3 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs">
                  <div className="text-slate-400 text-center sm:text-left">
                    <span>Chưa nhận được mã? </span>
                    {forgotResendTimer > 0 ? (
                      <span className="font-mono text-slate-500">({forgotResendTimer}s)</span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => sendForgotPasswordOtp('email')}
                        className="text-amber-400 hover:text-amber-300 font-bold ml-1"
                      >
                        Gửi lại mã OTP
                      </button>
                    )}
                  </div>
                </div>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setForgotStep(1)}
                    className="flex-1 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-2xl transition-colors"
                  >
                    Quay lại bước 1
                  </button>
                </div>
              </div>
            )}

            {/* FORGOT STEP 3: INPUT NEW PASSWORD (HIỂN THỊ Ô ĐỂ NHẬP MẬT KHẨU MỚI KHI ĐÚNG OTP) */}
            {forgotStep === 3 && (
              <form onSubmit={handleResetPasswordSubmit} className="space-y-4">
                <div className="p-3.5 bg-emerald-950/40 border border-emerald-800/80 rounded-2xl text-xs text-emerald-300 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Xác thực OTP thành công! Vui lòng nhập mật khẩu mới cho tài khoản:</span>
                </div>

                {/* New Password */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">Mật khẩu mới (tối thiểu 6 ký tự):</label>
                  <div className="relative">
                    <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                    <input
                      type={forgotShowPassword ? 'text' : 'password'}
                      value={forgotNewPassword}
                      onChange={(e) => setForgotNewPassword(e.target.value)}
                      placeholder="Nhập mật khẩu mới"
                      className="w-full bg-slate-950 border border-slate-800 rounded-2xl pl-10 pr-10 py-3 text-xs sm:text-sm text-slate-100 placeholder-slate-600 focus:outline-none focus:border-emerald-500 font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setForgotShowPassword(!forgotShowPassword)}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                    >
                      {forgotShowPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Confirm Password */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">Xác nhận lại mật khẩu mới:</label>
                  <div className="relative">
                    <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                    <input
                      type={forgotShowPassword ? 'text' : 'password'}
                      value={forgotConfirmPassword}
                      onChange={(e) => setForgotConfirmPassword(e.target.value)}
                      placeholder="Nhập lại mật khẩu mới"
                      className="w-full bg-slate-950 border border-slate-800 rounded-2xl pl-10 pr-10 py-3 text-xs sm:text-sm text-slate-100 placeholder-slate-600 focus:outline-none focus:border-emerald-500 font-mono"
                    />
                  </div>
                </div>

                {/* Submit */}
                <button
                  type="submit"
                  disabled={isSubmittingForgot}
                  className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 text-white font-bold text-xs sm:text-sm rounded-2xl transition-colors shadow-lg flex items-center justify-center gap-2"
                >
                  {isSubmittingForgot ? (
                    <>
                      <RotateCw className="w-4 h-4 animate-spin" />
                      <span>Đang cập nhật mật khẩu mới...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Lưu Mật Khẩu Mới & Đăng Nhập Ngay</span>
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* VIEW 2: REGISTER MULTI-STEP WIZARD (STRICT VALIDATION + SINGLE OTP)       */}
        {/* ========================================================================= */}
        {authMode === AuthMode.REGISTER && (
          <div className="space-y-5">
            {/* Step Indicators */}
            <div className="flex items-center justify-between text-xs px-1">
              <div className={`flex items-center gap-1.5 font-bold ${regStep >= 1 ? 'text-indigo-400' : 'text-slate-600'}`}>
                <span className="w-5 h-5 rounded-full bg-indigo-950 border border-indigo-700 flex items-center justify-center text-[10px]">1</span>
                <span>Thông tin</span>
              </div>
              <div className="h-px w-6 bg-slate-800" />
              <div className={`flex items-center gap-1.5 font-bold ${regStep >= 2 ? 'text-indigo-400' : 'text-slate-600'}`}>
                <span className="w-5 h-5 rounded-full bg-indigo-950 border border-indigo-700 flex items-center justify-center text-[10px]">2</span>
                <span>Xác thực OTP</span>
              </div>
              <div className="h-px w-6 bg-slate-800" />
              <div className={`flex items-center gap-1.5 font-bold ${regStep >= 3 ? 'text-indigo-400' : 'text-slate-600'}`}>
                <span className="w-5 h-5 rounded-full bg-indigo-950 border border-indigo-700 flex items-center justify-center text-[10px]">3</span>
                <span>Thiết lập</span>
              </div>
              <div className="h-px w-6 bg-slate-800" />
              <div className={`flex items-center gap-1.5 font-bold ${regStep >= 4 ? 'text-indigo-400' : 'text-slate-600'}`}>
                <span className="w-5 h-5 rounded-full bg-indigo-950 border border-indigo-700 flex items-center justify-center text-[10px]">4</span>
                <span>Hoàn tất</span>
              </div>
            </div>

            {/* STEP 1: Enter Profile Info & Choose OTP Delivery Method */}
            {regStep === 1 && (
              <div className="space-y-4">
                <div className="p-3.5 bg-indigo-950/40 border border-indigo-800/60 rounded-2xl text-xs text-indigo-300 flex items-start gap-2.5 shadow-sm">
                  <ShieldCheck className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
                  <p className="leading-relaxed">
                    <strong>Đăng ký tài khoản chính chủ:</strong> Vui lòng điền thông tin chính xác. Hệ thống sẽ gửi <strong>Email OTP thật gồm 6 số</strong> tới địa chỉ email của bạn để xác minh trước khi kích hoạt tài khoản.
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="text-xs font-black text-slate-700">Bạn sử dụng SOFT-EXO với vai trò nào?</div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <button type="button" onClick={() => setRegRole(UserRole.PATIENT)} className={`role-choice-card ${regRole === UserRole.PATIENT ? 'is-selected patient' : ''}`}>
                      <div className="role-choice-icon"><User className="w-5 h-5" /></div>
                      <div className="text-left"><div className="text-sm font-black text-slate-900">Người bệnh</div><div className="text-[11px] text-slate-500 mt-1">Tập phục hồi, theo dõi tiến độ và kết nối bác sĩ/người thân.</div></div>
                      {regRole === UserRole.PATIENT && <CheckCircle2 className="w-5 h-5 text-blue-600 ml-auto" />}
                    </button>
                    <button type="button" onClick={() => setRegRole(UserRole.CAREGIVER)} className={`role-choice-card ${regRole === UserRole.CAREGIVER ? 'is-selected caregiver' : ''}`}>
                      <div className="role-choice-icon"><HeartHandshake className="w-5 h-5" /></div>
                      <div className="text-left"><div className="text-sm font-black text-slate-900">Người thân</div><div className="text-[11px] text-slate-500 mt-1">Theo dõi bài tập, tiến độ, SOS và trao đổi với người bệnh.</div></div>
                      {regRole === UserRole.CAREGIVER && <CheckCircle2 className="w-5 h-5 text-sky-600 ml-auto" />}
                    </button>
                  </div>
                  <p className="text-[11px] text-slate-500">Bác sĩ được Admin xác minh riêng. SOFT-EXO là ứng dụng hỗ trợ phục hồi, không phải hệ thống quản trị bệnh viện.</p>
                </div>

                {/* Full Name */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Họ và tên người dùng:</label>
                  <input
                    type="text"
                    placeholder="Ví dụ: Nguyễn Văn An"
                    value={regFullName}
                    onChange={(e) => {
                      setRegFullName(e.target.value);
                      if (fieldErrors.fullName) setFieldErrors(prev => ({ ...prev, fullName: undefined }));
                    }}
                    className={`w-full bg-slate-950 border rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none ${
                      fieldErrors.fullName ? 'border-rose-600' : 'border-slate-800 focus:border-indigo-500'
                    }`}
                  />
                  {fieldErrors.fullName && (
                    <p className="text-[11px] text-rose-400">{fieldErrors.fullName}</p>
                  )}
                </div>

                {/* Phone & Email */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-300">Số điện thoại di động:</label>
                    <div className="relative">
                      <Phone className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                      <input
                        type="tel"
                        placeholder="Ví dụ: 0987654321"
                        value={regPhone}
                        onChange={(e) => {
                          setRegPhone(e.target.value);
                          if (fieldErrors.phone) setFieldErrors(prev => ({ ...prev, phone: undefined }));
                        }}
                        className={`w-full bg-slate-950 border rounded-xl pl-9 pr-3 py-2.5 text-xs text-white font-mono focus:outline-none ${
                          fieldErrors.phone ? 'border-rose-600' : 'border-slate-800 focus:border-indigo-500'
                        }`}
                      />
                    </div>
                    {fieldErrors.phone && (
                      <p className="text-[11px] text-rose-400 leading-tight">{fieldErrors.phone}</p>
                    )}
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-300">Địa chỉ Email:</label>
                    <div className="relative">
                      <Mail className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                      <input
                        type="email"
                        placeholder="Ví dụ: yourname@gmail.com"
                        value={regEmail}
                        onChange={(e) => {
                          setRegEmail(e.target.value);
                          if (fieldErrors.email) setFieldErrors(prev => ({ ...prev, email: undefined }));
                        }}
                        className={`w-full bg-slate-950 border rounded-xl pl-9 pr-3 py-2.5 text-xs text-white focus:outline-none ${
                          fieldErrors.email ? 'border-rose-600' : 'border-slate-800 focus:border-indigo-500'
                        }`}
                      />
                    </div>
                    {fieldErrors.email && (
                      <p className="text-[11px] text-rose-400 leading-tight">{fieldErrors.email}</p>
                    )}
                  </div>
                </div>

                {/* Password */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Mật khẩu tài khoản (tối thiểu 6 ký tự):</label>
                  <div className="relative">
                    <Lock className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                    <input
                      type="password"
                      placeholder="Nhập mật khẩu bảo mật"
                      value={regPassword}
                      onChange={(e) => {
                        setRegPassword(e.target.value);
                        if (fieldErrors.password) setFieldErrors(prev => ({ ...prev, password: undefined }));
                      }}
                      className={`w-full bg-slate-950 border rounded-xl pl-9 pr-3 py-2.5 text-xs text-white font-mono focus:outline-none ${
                        fieldErrors.password ? 'border-rose-600' : 'border-slate-800 focus:border-indigo-500'
                      }`}
                    />
                  </div>
                  {fieldErrors.password && (
                    <p className="text-[11px] text-rose-400">{fieldErrors.password}</p>
                  )}
                </div>

                {/* Role-specific onboarding */}
                {regRole === UserRole.PATIENT ? (
                  <div className="space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="space-y-1"><label className="text-xs font-semibold text-slate-600">Tuổi</label><input type="number" value={regAge} onChange={(e) => setRegAge(Number(e.target.value))} className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2.5 text-xs text-slate-900 focus:outline-none focus:border-blue-500" /></div>
                      <div className="space-y-1"><label className="text-xs font-semibold text-slate-600">Khớp gối cần phục hồi</label><select value={regAffectedLeg} onChange={(e) => setRegAffectedLeg(e.target.value as any)} className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2.5 text-xs text-slate-900 focus:outline-none focus:border-blue-500"><option value={AffectedLeg.RIGHT}>Chân phải</option><option value={AffectedLeg.LEFT}>Chân trái</option><option value={AffectedLeg.BOTH}>Cả hai chân</option></select></div>
                    </div>
                    <div className="space-y-1"><label className="text-xs font-semibold text-slate-600">Tình trạng phục hồi</label><input type="text" value={regCondition} onChange={(e) => setRegCondition(e.target.value)} placeholder="Ví dụ: Sau tái tạo ACL, sau thay khớp gối..." className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2.5 text-xs text-slate-900 focus:outline-none focus:border-blue-500" /></div>
                    <div className="hospital-onboarding-card">
                      <div className="flex items-center gap-2 mb-3"><Building2 className="w-4 h-4 text-blue-600" /><div><div className="text-xs font-black text-slate-900">Nơi đang được hỗ trợ chuyên môn <span className="text-slate-400 font-semibold">(không bắt buộc)</span></div><div className="text-[10px] text-slate-500">Chỉ dùng để bổ sung bối cảnh phục hồi. SOFT-EXO không đại diện hoặc quản trị cơ sở y tế.</div></div></div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        <input value={regHospital} onChange={e => setRegHospital(e.target.value)} placeholder="Bệnh viện / phòng khám đang theo dõi (nếu có)" className="v5-input" />
                        <input value={regDepartment} onChange={e => setRegDepartment(e.target.value)} placeholder="Khoa / chuyên khoa (nếu biết)" className="v5-input" />
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="space-y-1"><label className="text-xs font-semibold text-slate-600">Tuổi</label><input type="number" value={regAge} onChange={(e) => setRegAge(Number(e.target.value))} className="v5-input" /></div>
                      <div className="space-y-1"><label className="text-xs font-semibold text-slate-600">Quan hệ với người bệnh</label><select value={regRelationship} onChange={e => setRegRelationship(e.target.value)} className="v5-input"><option>Con/Cháu</option><option>Vợ/Chồng</option><option>Cha/Mẹ</option><option>Anh/Chị/Em</option><option>Người chăm sóc</option><option>Khác</option></select></div>
                    </div>
                    <div className="family-link-preview">
                      <Link2 className="w-5 h-5 text-sky-600" />
                      <div className="flex-1"><div className="text-xs font-black text-slate-900">Mã liên kết người bệnh</div><div className="text-[10px] text-slate-500 mt-0.5">Nhập mã do người bệnh cung cấp để liên kết ngay. Có thể liên kết sau trong giao diện Người thân.</div><input value={regPatientInviteCode} onChange={e => setRegPatientInviteCode(e.target.value.toUpperCase())} placeholder="Ví dụ: FAM-AB12CD" className="v5-input mt-2 font-mono uppercase" /></div>
                    </div>
                  </div>
                )}

                {/* EMAIL OTP DELIVERY */}
                <div className="space-y-2 pt-1">
                  <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                    <KeyRound className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Xác thực Email</span>
                  </label>
                  
                  <div className="grid grid-cols-1 gap-2.5">
                    <div
                      onClick={() => setOtpDeliveryMethod('email')}
                      className={`p-3 rounded-2xl border cursor-pointer transition-all flex items-center gap-3 ${
                        otpDeliveryMethod === 'email'
                          ? 'bg-white border-indigo-300 shadow-md ring-2 ring-indigo-200'
                          : 'bg-slate-950 border-slate-800 hover:border-indigo-200'
                      }`}
                    >
                      <div className={`p-2 rounded-xl border ${
                        otpDeliveryMethod === 'email' 
                          ? 'bg-indigo-600 text-white border-indigo-500 shadow-sm' 
                          : 'bg-slate-900 text-slate-400 border-slate-800'
                      }`}>
                        <Mail className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-white flex items-center gap-1">
                          <span>Nhận mã xác thực qua Email</span>
                          {otpDeliveryMethod === 'email' && <Check className="w-3.5 h-3.5 text-indigo-400" />}
                        </div>
                        <p className="text-[10px] text-slate-400 truncate">
                          {regEmail.trim() ? `Mã sẽ gửi tới ${regEmail}` : 'Mã 6 số sẽ được gửi tới hộp thư của bạn'}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Dispatch Status */}
                {dispatchStatusMessage && (
                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-xs text-indigo-300 flex items-center gap-2">
                    <RotateCw className="w-4 h-4 animate-spin text-indigo-400" />
                    <span>{dispatchStatusMessage}</span>
                  </div>
                )}

                <button
                  type="button"
                  disabled={isSendingOtp}
                  onClick={handleStartRegistrationOtpVerification}
                  className="auth-primary-btn w-full py-3.5 text-white font-bold text-xs rounded-2xl shadow-md flex items-center justify-center gap-2"
                >
                  {isSendingOtp ? (
                    <>
                      <RotateCw className="w-4 h-4 animate-spin" />
                      <span>Đang gửi mã xác thực...</span>
                    </>
                  ) : (
                    <>
                      <span>
                        Gửi mã xác thực 6 số
                      </span>
                      <ChevronRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            )}

            {/* STEP 2: EMAIL OTP VERIFICATION */}
            {regStep === 2 && (
              <div className="space-y-5">
                <div className="text-center space-y-1">
                  <h3 className="text-sm font-bold text-white flex items-center justify-center gap-2">
                    <KeyRound className="w-4 h-4 text-emerald-400" />
                    <span>
                      Nhập mã xác thực Email
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Mã 6 chữ số đã được gửi tới{' '}
                    <strong className="text-white font-mono">
                      {regEmail}
                    </strong>
                  </p>
                </div>

                {otpError && (
                  <div className="p-3 bg-rose-950/80 border border-rose-800 text-rose-200 text-xs rounded-2xl flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                    <span>{otpError}</span>
                  </div>
                )}

                {/* SINGLE VERIFICATION CARD */}
                <div className={`p-4 rounded-2xl border transition-all ${
                  isOtpVerified 
                    ? 'bg-emerald-950/40 border-emerald-800' 
                    : 'bg-slate-950 border-slate-800'
                }`}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className={`p-2 rounded-xl border ${
                        otpDeliveryMethod === 'sms'
                          ? 'bg-emerald-950 text-emerald-400 border-emerald-800'
                          : 'bg-indigo-950 text-indigo-400 border-indigo-800'
                      }`}>
                        {otpDeliveryMethod === 'sms' ? <Smartphone className="w-4 h-4" /> : <Mail className="w-4 h-4" />}
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white">
                          {`Mã OTP qua Email: ${regEmail}`}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          Kiểm tra hộp thư đến (Inbox hoặc Spam)
                        </div>
                      </div>
                    </div>

                    {isOtpVerified && (
                      <span className="text-emerald-400 text-xs font-bold flex items-center gap-1">
                        <Check className="w-4 h-4" />
                        <span>Đã xác minh</span>
                      </span>
                    )}
                  </div>

                  {!isOtpVerified ? (
                    <div className="space-y-2 mt-3">
                      <div className="flex gap-2">
                        <input
                          type="text"
                          maxLength={6}
                          placeholder="Nhập 6 số OTP"
                          value={enteredOtp}
                          onChange={(e) => setEnteredOtp(e.target.value)}
                          className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs sm:text-sm text-white font-mono tracking-widest text-center focus:outline-none focus:border-emerald-500 font-bold"
                        />
                        <button
                          type="button"
                          onClick={handleVerifyOtp}
                          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl transition-colors shrink-0 shadow"
                        >
                          Xác nhận mã
                        </button>
                      </div>


                    </div>
                  ) : (
                    <div className="text-xs text-emerald-300 bg-emerald-950/60 p-2.5 rounded-xl border border-emerald-800 flex items-center gap-2 mt-2">
                      <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>
                        Email OTP đã được xác thực thành công. Tài khoản đã sẵn sàng kích hoạt.
                      </span>
                    </div>
                  )}
                </div>

                {/* Option to switch method or resend */}
                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-3 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs">
                  <div className="text-slate-400 text-center sm:text-left">
                    <span>Chưa nhận được mã? </span>
                    {resendTimer > 0 ? (
                      <span className="font-mono text-slate-500">({resendTimer}s)</span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => sendRegistrationOtp('email')}
                        className="text-emerald-400 hover:text-emerald-300 font-bold ml-1"
                      >
                        Gửi lại mã OTP
                      </button>
                    )}
                  </div>


                </div>

                {/* Navigation */}
                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setRegStep(1)}
                    className="flex-1 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-2xl transition-colors"
                  >
                    Quay lại sửa thông tin
                  </button>
                  <button
                    type="button"
                    onClick={handleProceedToStep3}
                    className={`flex-1 py-3 text-xs font-bold rounded-2xl transition-all shadow-md flex items-center justify-center gap-1.5 ${
                      isOtpVerified
                        ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                        : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                    }`}
                  >
                    <span>Tiếp tục: Thiết lập tài khoản</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 3: Role onboarding summary */}
            {regStep === 3 && (
              <div className="space-y-4 page-enter">
                <div className="onboarding-summary-hero">
                  <div className="text-xs font-black text-blue-700">{regRole === UserRole.PATIENT ? 'Không gian phục hồi của bạn' : 'Không gian chăm sóc gia đình'}</div>
                  <h3 className="text-lg font-black text-slate-950 mt-1">{regRole === UserRole.PATIENT ? 'Theo dõi đúng dữ liệu, đúng tiến độ' : 'Theo dõi người thân mà không cần hiểu thuật ngữ kỹ thuật'}</h3>
                  <p className="text-xs text-slate-600 mt-2 leading-relaxed">{regRole === UserRole.PATIENT ? 'Sau khi vào ứng dụng, bạn có thể hoàn thiện hồ sơ, kết nối bác sĩ/người thân và thiết bị SOFT-EXO. Chỉ số chưa có dữ liệu thật sẽ giữ ở 0 hoặc “Chưa có dữ liệu”.' : 'Bạn sẽ thấy bài tập hôm nay, số ngày đã tập, mức đau gần nhất, cảnh báo an toàn, vị trí SOS được cho phép và kênh trò chuyện với người bệnh.'}</p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {(regRole === UserRole.PATIENT ? [
                    ['Tiến độ thật', 'Chỉ tăng khi có buổi tập được lưu'],
                    ['Kết nối chăm sóc', 'Bác sĩ và người thân theo quyền bạn cho phép'],
                    ['An toàn', 'SOS và vị trí chỉ dùng theo quyền đã bật'],
                  ] : [
                    ['Bài tập hôm nay', 'Biết người thân đã tập hay chưa'],
                    ['Tiến độ dễ hiểu', 'Ngày phục hồi, thời gian tập, mức đau'],
                    ['Cảnh báo', 'Theo dõi SOS và liên hệ nhanh khi cần'],
                  ]).map(([title, desc]) => <div key={title} className="mini-benefit-card"><CheckCircle2 className="w-4 h-4 text-emerald-600" /><div><div className="text-xs font-black text-slate-900">{title}</div><div className="text-[10px] text-slate-500 mt-1">{desc}</div></div></div>)}
                </div>
                <div className="flex gap-2 pt-2"><button type="button" onClick={() => setRegStep(2)} className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-2xl">Quay lại</button><button type="button" onClick={() => setRegStep(4)} className="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-2xl shadow-md flex items-center justify-center gap-1.5"><span>Xem lại thông tin</span><ChevronRight className="w-4 h-4" /></button></div>
              </div>
            )}

            {/* STEP 4: Review & Final Confirmation */}
            {regStep === 4 && (
              <div className="space-y-4">
                <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2.5 text-xs">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <span className="text-slate-400">Họ và tên:</span>
                    <span className="font-bold text-white">{regFullName}</span>
                  </div>
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <span className="text-slate-400">Số điện thoại di động:</span>
                    <span className="font-mono text-emerald-400 font-bold">{regPhone}</span>
                  </div>
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <span className="text-slate-400">Địa chỉ Email:</span>
                    <span className="font-mono text-indigo-400">{regEmail}</span>
                  </div>
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <span className="text-slate-400">Vai trò tài khoản:</span>
                    <span className="font-bold text-amber-400">
                      {regRole === UserRole.PATIENT ? 'Người bệnh' : 'Người thân'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <span className="text-slate-400">Kênh xác thực OTP:</span>
                    <span className="text-emerald-400 font-bold flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" />
                      <span>Email OTP thật (Đã xác minh)</span>
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Gói tính năng:</span>
                    <span className="font-bold text-white">{regRole === UserRole.PATIENT ? 'Không gian phục hồi' : 'Không gian người thân'}</span>
                  </div>
                </div>

                {otpError && (
                  <div className="rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-semibold text-rose-700">
                    {otpError}
                  </div>
                )}

                <button
                  type="button"
                  onClick={handleCompleteRegistration}
                  className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm rounded-2xl transition-colors shadow-xl flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Kích Hoạt Tài Khoản & Vào Ứng Dụng Ngay</span>
                </button>
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
