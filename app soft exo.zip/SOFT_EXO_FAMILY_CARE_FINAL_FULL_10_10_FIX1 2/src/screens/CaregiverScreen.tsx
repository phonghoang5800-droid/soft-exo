import React, { useEffect, useMemo, useState } from 'react';
import { motion } from 'motion/react';
import {
  Bell,
  CalendarDays,
  CheckCircle2,
  ChevronRight,
  Circle,
  Clock3,
  FileText,
  HeartHandshake,
  HeartPulse,
  Link2,
  MapPin,
  MessageSquare,
  Phone,
  RefreshCw,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  UserRoundCheck,
  UsersRound,
} from 'lucide-react';
import {
  CaregiverAlert,
  GeoLocationData,
  LocationPermissionStatus,
  PatientProgressSummary,
  RehabExercise,
  SensorTelemetry,
  UserProfile,
} from '../types';

interface CaregiverScreenProps {
  userProfile: UserProfile;
  telemetry: SensorTelemetry;
  alerts: CaregiverAlert[];
  exercises: RehabExercise[];
  location?: GeoLocationData | null;
  permissionStatus?: LocationPermissionStatus;
  onOpenGpsModal?: () => void;
  onOpenChat?: () => void;
  onOpenPassport?: () => void;
  onMarkAlertRead: (id: string) => void;
  onDeleteAlert: (id: string) => void;
}

type CoRehabSession = {
  id: string;
  status: 'REQUESTED' | 'SUPPORTED' | 'COMPLETED' | 'CANCELLED';
  startedAt: string;
  joinedAt?: string;
  caregiverName?: string;
  checklist?: { safeSpace?: boolean; deviceReady?: boolean; waterReady?: boolean };
};

const getHeaders = () => {
  const token = localStorage.getItem('soft_exo_session_token') || '';
  return token ? { Authorization: `Bearer ${token}` } : {};
};

const formatDateTime = (value?: string | null) => {
  if (!value) return 'Chưa có';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return 'Chưa có';
  return d.toLocaleString('vi-VN', { dateStyle: 'short', timeStyle: 'short', timeZone: 'Asia/Ho_Chi_Minh' });
};

const vnDateKey = (value: Date | string) => {
  const d = value instanceof Date ? value : new Date(value);
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Ho_Chi_Minh', year: 'numeric', month: '2-digit', day: '2-digit',
  }).format(d);
};

export const CaregiverScreen: React.FC<CaregiverScreenProps> = ({
  userProfile,
  telemetry,
  alerts,
  exercises,
  onOpenChat,
  onOpenPassport,
  onMarkAlertRead,
}) => {
  const [summary, setSummary] = useState<PatientProgressSummary | null>(null);
  const [corehab, setCorehab] = useState<CoRehabSession | null>(null);
  const [loading, setLoading] = useState(true);
  const [notificationPermission, setNotificationPermission] = useState<string>(() =>
    typeof Notification !== 'undefined' ? Notification.permission : 'unsupported'
  );
  const [inviteCode, setInviteCode] = useState('');
  const [linking, setLinking] = useState(false);
  const [joining, setJoining] = useState(false);
  const [linkMessage, setLinkMessage] = useState('');

  const loadCareData = async () => {
    try {
      const [progressRes, corehabRes] = await Promise.all([
        fetch('/api/progress/summary', { headers: getHeaders() }),
        fetch('/api/co-rehab', { headers: getHeaders() }),
      ]);
      const progressData = await progressRes.json().catch(() => ({}));
      const corehabData = await corehabRes.json().catch(() => ({}));
      setSummary(progressRes.ok && progressData.summary ? progressData.summary : null);
      setCorehab(corehabRes.ok ? (corehabData.active || null) : null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCareData();
    const timer = window.setInterval(loadCareData, 20000);
    return () => window.clearInterval(timer);
  }, []);

  const today = summary?.todayDate || vnDateKey(new Date());
  const completedToday = useMemo(() => new Set(
    (summary?.recentSessions || [])
      .filter(item => vnDateKey(item.createdAt) === today)
      .map(item => item.exerciseId)
  ), [summary, today]);

  const linkedPatient = summary?.patient;
  const patientName = linkedPatient?.fullName || 'Chưa liên kết người bệnh';
  const patientPhone = linkedPatient?.phone || '';
  const patientLocation = (linkedPatient as any)?.location;
  const unreadAlerts = alerts.filter(item => !item.isRead).length;
  const dangerAlerts = alerts.filter(item => !item.isRead && item.severity === 'DANGER').length;
  const didTrainToday = (summary?.todaySessions || 0) > 0;
  const status = telemetry.isFallDetected || dangerAlerts > 0 ? 'attention' : 'safe';

  const handleEnableNotifications = async () => {
    if (typeof Notification === 'undefined') return;
    const permission = await Notification.requestPermission();
    setNotificationPermission(permission);
  };

  const handleLinkPatient = async () => {
    if (!inviteCode.trim()) {
      setLinkMessage('Vui lòng nhập mã liên kết do người bệnh cung cấp.');
      return;
    }
    setLinking(true);
    setLinkMessage('');
    try {
      const response = await fetch('/api/family/link', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getHeaders() },
        body: JSON.stringify({ inviteCode: inviteCode.trim().toUpperCase() }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || 'Không thể liên kết người bệnh.');
      setLinkMessage(`Đã liên kết với ${data.patient?.fullName || 'người bệnh'}.`);
      setInviteCode('');
      await loadCareData();
    } catch (err: any) {
      setLinkMessage(err?.message || 'Không thể liên kết người bệnh.');
    } finally {
      setLinking(false);
    }
  };

  const joinCoRehab = async () => {
    setJoining(true);
    try {
      const response = await fetch('/api/co-rehab/join', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getHeaders() },
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || 'Không thể xác nhận hỗ trợ.');
      setCorehab(data.session || null);
    } catch (err: any) {
      setLinkMessage(err?.message || 'Không thể xác nhận hỗ trợ.');
    } finally {
      setJoining(false);
    }
  };

  if (!linkedPatient && !loading) {
    return (
      <div className="care-dashboard-v7 max-w-5xl mx-auto">
        <motion.section initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="care-link-v7">
          <div className="care-link-orb" />
          <div className="relative z-10 grid lg:grid-cols-[1fr_390px] gap-8 items-center">
            <div>
              <div className="care-kicker-v7"><HeartHandshake className="w-4 h-4" /> Family Care</div>
              <h1 className="text-3xl sm:text-4xl font-black tracking-[-.035em] text-slate-950 mt-3">Theo dõi đúng người, bằng một mã riêng.</h1>
              <p className="text-sm sm:text-base text-slate-600 leading-7 mt-4 max-w-xl">Người thân không tìm kiếm hồ sơ công khai. Người bệnh chủ động chia sẻ mã của mình để tạo liên kết an toàn.</p>
              <div className="grid sm:grid-cols-3 gap-3 mt-6">
                {[
                  ['01', 'Theo dõi tiến độ'],
                  ['02', 'Nhận cảnh báo an toàn'],
                  ['03', 'Hỗ trợ buổi tập'],
                ].map(([number, text]) => <div key={number} className="care-benefit-v7"><strong>{number}</strong><span>{text}</span></div>)}
              </div>
            </div>
            <div className="care-link-form-v7">
              <div className="w-12 h-12 rounded-2xl bg-sky-100 text-sky-700 flex items-center justify-center"><Link2 className="w-6 h-6" /></div>
              <h2 className="text-lg font-black text-slate-950 mt-4">Nhập mã người bệnh</h2>
              <p className="text-xs text-slate-500 mt-1">Mã có dạng FAM-XXXXXX trong Hồ sơ người bệnh.</p>
              <input value={inviteCode} onChange={e => setInviteCode(e.target.value.toUpperCase())} placeholder="FAM-AB12CD" className="care-code-input-v7" />
              <button onClick={handleLinkPatient} disabled={linking} className="care-primary-v7 w-full mt-3">
                {linking ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
                {linking ? 'Đang liên kết...' : 'Liên kết an toàn'}
              </button>
              {linkMessage && <div className="text-xs text-slate-600 mt-3 text-center">{linkMessage}</div>}
            </div>
          </div>
        </motion.section>
      </div>
    );
  }

  return (
    <div className="care-dashboard-v7 max-w-7xl mx-auto space-y-6">
      <motion.section initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="care-hero-v7">
        <div className="care-hero-orb" />
        <div className="relative z-10 flex flex-col xl:flex-row xl:items-center justify-between gap-6">
          <div className="flex items-center gap-4 min-w-0">
            <div className="care-avatar-v7">{patientName.charAt(0).toUpperCase()}</div>
            <div className="min-w-0">
              <div className="care-kicker-v7"><UsersRound className="w-4 h-4" /> Người bạn đang đồng hành</div>
              <h1 className="text-2xl sm:text-3xl font-black text-slate-950 mt-1 truncate">{patientName}</h1>
              <p className="text-sm text-slate-500 mt-1">{linkedPatient?.condition || 'Theo dõi phục hồi tại nhà'}</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 sm:items-center">
            <div className={`care-health-state-v7 ${status}`}>
              <span className="care-health-pulse" />
              <div><small>Trạng thái hiện tại</small><strong>{status === 'safe' ? 'Đang ổn' : 'Cần chú ý'}</strong></div>
            </div>
            <div className="flex gap-2">
              {patientPhone && <a href={`tel:${patientPhone}`} className="care-icon-action-v7"><Phone className="w-5 h-5" /><span>Gọi</span></a>}
              <button onClick={onOpenChat} className="care-icon-action-v7"><MessageSquare className="w-5 h-5" /><span>Nhắn</span></button>
              <button onClick={onOpenPassport} className="care-icon-action-v7"><FileText className="w-5 h-5" /><span>Tiến độ</span></button>
            </div>
          </div>
        </div>
      </motion.section>

      <section className="grid lg:grid-cols-[1.12fr_.88fr] gap-5">
        <div className="care-panel-v7 care-today-v7">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="care-kicker-v7"><CalendarDays className="w-4 h-4" /> Hôm nay của {patientName.split(' ').pop()}</div>
              <h2 className="care-title-v7">Một cái nhìn đủ để biết có cần gọi hỏi thăm hay không.</h2>
            </div>
            <span className={`care-day-pill ${didTrainToday ? 'done' : ''}`}>{didTrainToday ? 'Đã tập hôm nay' : 'Chưa có buổi tập'}</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6">
            {[
              { label: 'Ngày phục hồi', value: summary?.recoveryDay ? `Ngày ${summary.recoveryDay}` : 'Chưa đặt' },
              { label: 'Thời gian tập', value: `${summary?.todayMinutes || 0} phút` },
              { label: 'Bài đã tập', value: `${completedToday.size}/${exercises.length}` },
              { label: 'Mức đau', value: summary?.latestPainLevel === null || summary?.latestPainLevel === undefined ? 'Chưa có' : `${summary.latestPainLevel}/10` },
            ].map(item => <div key={item.label} className="care-stat-v7"><span>{item.label}</span><strong>{item.value}</strong></div>)}
          </div>

          <div className="mt-6 care-timeline-v7">
            <div className={`care-timeline-item ${didTrainToday ? 'done' : ''}`}><i /><div><strong>{didTrainToday ? 'Đã ghi nhận buổi tập hôm nay' : 'Chưa có buổi tập được lưu hôm nay'}</strong><span>{didTrainToday ? `${summary?.todayMinutes || 0} phút • ${summary?.todaySessions || 0} buổi` : 'Ứng dụng sẽ cập nhật khi người bệnh lưu buổi tập.'}</span></div></div>
            <div className="care-timeline-item"><i /><div><strong>Buổi gần nhất</strong><span>{formatDateTime(summary?.lastSessionAt)}</span></div></div>
            <div className="care-timeline-item"><i /><div><strong>Dữ liệu chuyển động</strong><span>{telemetry.isConnected ? 'Thiết bị đang gửi dữ liệu thật.' : 'Chưa có thiết bị đang hoạt động.'}</span></div></div>
          </div>
        </div>

        <div className="care-panel-v7 care-help-v7">
          <div className="care-kicker-v7"><HeartHandshake className="w-4 h-4" /> Tôi có thể giúp gì?</div>
          <h2 className="care-title-v7">Biến theo dõi thành hành động hữu ích.</h2>

          {corehab?.status === 'REQUESTED' ? (
            <div className="care-corehab-v7 waiting mt-5">
              <div className="flex items-start gap-3"><div className="care-corehab-icon"><UserRoundCheck className="w-5 h-5" /></div><div><strong>{patientName} đang chờ người thân hỗ trợ tập</strong><p>Bạn có thể xác nhận rằng mình đang ở cạnh người bệnh.</p></div></div>
              <button onClick={joinCoRehab} disabled={joining} className="care-primary-v7 w-full mt-4">{joining ? <RefreshCw className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}{joining ? 'Đang xác nhận...' : 'Tôi đang ở cạnh người bệnh'}</button>
            </div>
          ) : corehab?.status === 'SUPPORTED' ? (
            <div className="care-corehab-v7 supported mt-5"><div className="flex items-start gap-3"><div className="care-corehab-icon"><ShieldCheck className="w-5 h-5" /></div><div><strong>Phiên tập đang có người thân hỗ trợ</strong><p>{corehab.caregiverName || userProfile.fullName} đã xác nhận có mặt.</p></div></div></div>
          ) : (
            <div className="care-corehab-v7 mt-5"><div className="flex items-start gap-3"><div className="care-corehab-icon"><HeartPulse className="w-5 h-5" /></div><div><strong>Hiện không có phiên nào đang chờ</strong><p>Khi người bệnh bắt đầu phiên có người thân hỗ trợ, bạn sẽ thấy lời mời tại đây.</p></div></div></div>
          )}

          <div className="grid grid-cols-2 gap-2 mt-3">
            <button onClick={onOpenChat} className="care-soft-action-v7"><MessageSquare className="w-4 h-4" /> Gửi lời nhắn</button>
            <button onClick={handleEnableNotifications} className="care-soft-action-v7"><Bell className="w-4 h-4" /> {notificationPermission === 'granted' ? 'Đã bật cảnh báo' : 'Bật cảnh báo'}</button>
          </div>
        </div>
      </section>

      <section className="grid lg:grid-cols-[.85fr_1.15fr] gap-5">
        <div className="care-panel-v7">
          <div className="flex items-center justify-between gap-3">
            <div><div className="care-kicker-v7"><TrendingUp className="w-4 h-4" /> Nhịp tập 7 ngày</div><h2 className="care-title-v7">Nhìn xu hướng, không soi từng con số.</h2></div>
            <div className="care-week-score"><strong>{summary?.activeDaysLast7 || 0}</strong><span>/7 ngày</span></div>
          </div>
          <div className="care-bars-v7 mt-6">
            {(summary?.sevenDay || []).map(item => {
              const height = item.sessions ? Math.min(100, Math.max(18, item.sessions * 34)) : 5;
              return <div key={item.date}><span>{item.sessions || 0}</span><i><b style={{ height: `${height}%` }} /></i><small>{item.label}</small></div>;
            })}
          </div>
        </div>

        <div className="care-panel-v7">
          <div className="flex items-center justify-between gap-3">
            <div><div className="care-kicker-v7"><ShieldAlert className="w-4 h-4" /> Cảnh báo cần biết</div><h2 className="care-title-v7">Chỉ nổi bật việc thực sự cần chú ý.</h2></div>
            {unreadAlerts > 0 && <span className="care-alert-count-v7">{unreadAlerts} mới</span>}
          </div>
          <div className="space-y-2.5 mt-5">
            {alerts.length ? alerts.slice(0, 4).map(alert => (
              <button key={alert.id} onClick={() => onMarkAlertRead(alert.id)} className={`care-alert-row-v7 ${alert.severity === 'DANGER' ? 'danger' : ''}`}>
                <div className="care-alert-icon-v7"><ShieldAlert className="w-5 h-5" /></div>
                <div className="text-left min-w-0"><strong>{alert.title}</strong><p>{alert.message}</p><small>{alert.timestamp}</small></div>
                <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
              </button>
            )) : <div className="care-safe-empty-v7"><ShieldCheck className="w-5 h-5" /><div><strong>Không có cảnh báo mới</strong><span>Chưa ghi nhận sự kiện an toàn cần xử lý.</span></div></div>}
          </div>
        </div>
      </section>

      <section className="care-location-v7">
        <div className="flex items-start gap-3 min-w-0"><div className="care-location-icon"><MapPin className="w-5 h-5" /></div><div className="min-w-0"><strong>Vị trí được người bệnh cho phép chia sẻ</strong><p className="truncate">{patientLocation?.formattedAddress || 'Chưa có vị trí được chia sẻ.'}</p>{patientLocation?.updatedAt && <small>Cập nhật {formatDateTime(patientLocation.updatedAt)}</small>}</div></div>
        <div className="care-privacy-v7"><ShieldCheck className="w-4 h-4" /> Chỉ hiển thị theo quyền người bệnh</div>
      </section>

      {loading && <div className="text-center text-xs text-slate-400 py-2">Đang đồng bộ thông tin người thân...</div>}
      {linkMessage && linkedPatient && <div className="text-center text-xs text-slate-500">{linkMessage}</div>}
    </div>
  );
};
