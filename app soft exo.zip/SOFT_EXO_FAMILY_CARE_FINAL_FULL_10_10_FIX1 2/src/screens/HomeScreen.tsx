import React, { useEffect, useMemo, useState } from 'react';
import { motion } from 'motion/react';
import {
  ArrowRight,
  BatteryCharging,
  CalendarDays,
  CheckCircle2,
  ChevronRight,
  Circle,
  Clock3,
  FileText,
  HeartPulse,
  MapPin,
  MessageCircleHeart,
  Navigation,
  Play,
  Radio,
  ShieldCheck,
  Sparkles,
  Target,
  TrendingUp,
  UserRoundCheck,
} from 'lucide-react';
import {
  UserProfile,
  RehabExercise,
  SensorTelemetry,
  GeoLocationData,
  LocationPermissionStatus,
  NearbyMedicalCenter,
  PatientProgressSummary,
} from '../types';

interface HomeScreenProps {
  userProfile: UserProfile;
  telemetry: SensorTelemetry;
  exercises: RehabExercise[];
  location?: GeoLocationData | null;
  permissionStatus?: LocationPermissionStatus;
  nearbyHospitals?: NearbyMedicalCenter[];
  onOpenGpsModal?: () => void;
  onRequestLocation?: () => void;
  onNavigateToExercise: (exerciseId?: string) => void;
  onNavigateTo3DTwin: () => void;
  onNavigateToDevice: () => void;
  onOpenPassport: () => void;
  onSimulateAngle: (angle: number) => void;
}

const authHeaders = () => {
  const token = localStorage.getItem('soft_exo_session_token') || '';
  return token ? { Authorization: `Bearer ${token}` } : {};
};

const vnDayKey = (value: Date | string) => {
  const d = value instanceof Date ? value : new Date(value);
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Ho_Chi_Minh',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(d);
};

const greeting = () => {
  const hour = Number(new Intl.DateTimeFormat('en-US', {
    timeZone: 'Asia/Ho_Chi_Minh', hour: '2-digit', hour12: false,
  }).format(new Date()));
  if (hour < 11) return 'Chào buổi sáng';
  if (hour < 18) return 'Chào buổi chiều';
  return 'Chào buổi tối';
};

export const HomeScreen: React.FC<HomeScreenProps> = ({
  userProfile,
  telemetry,
  exercises,
  location,
  permissionStatus,
  nearbyHospitals,
  onOpenGpsModal,
  onRequestLocation,
  onNavigateToExercise,
  onNavigateTo3DTwin,
  onNavigateToDevice,
  onOpenPassport,
}) => {
  const [summary, setSummary] = useState<PatientProgressSummary | null>(null);
  const [loading, setLoading] = useState(true);

  const loadSummary = async () => {
    try {
      const response = await fetch('/api/progress/summary', { headers: authHeaders() });
      const data = await response.json().catch(() => ({}));
      if (response.ok && data.summary) setSummary(data.summary);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSummary();
    const timer = window.setInterval(loadSummary, 30000);
    return () => window.clearInterval(timer);
  }, [exercises]);

  const today = summary?.todayDate || vnDayKey(new Date());
  const completedIds = useMemo(() => new Set(
    (summary?.recentSessions || [])
      .filter(item => vnDayKey(item.createdAt) === today)
      .map(item => item.exerciseId)
  ), [summary, today]);

  const completed = completedIds.size;
  const dailyPercent = exercises.length ? Math.min(100, Math.round((completed / exercises.length) * 100)) : 0;
  const bestAngle = summary?.maxAngle || 0;
  const targetAngle = Number(userProfile.targetRomAngle || 0);
  const targetPercent = bestAngle > 0 && targetAngle > 0 ? Math.min(100, Math.round((bestAngle / targetAngle) * 100)) : 0;
  const firstPending = exercises.find(item => !completedIds.has(item.id));
  const deviceConnected = Boolean(telemetry.isConnected);
  const liveAngle = deviceConnected ? Math.round(telemetry.kneeAngle || 0) : 0;
  const liveBattery = deviceConnected ? Math.round(telemetry.batteryLevel || 0) : 0;
  const patientFirstName = userProfile.fullName?.trim().split(/\s+/).pop() || 'bạn';

  const safetyLabel = telemetry.isFallDetected
    ? 'Cần kiểm tra ngay'
    : deviceConnected
    ? 'Đang theo dõi an toàn'
    : 'Sẵn sàng khi bạn bắt đầu';

  return (
    <div className="patient-dashboard-v7 max-w-7xl mx-auto space-y-6">
      <motion.section
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: .42, ease: [0.22, 1, 0.36, 1] }}
        className="patient-hero-v7"
      >
        <div className="patient-hero-glow patient-hero-glow-a" />
        <div className="patient-hero-glow patient-hero-glow-b" />
        <div className="relative z-10 grid lg:grid-cols-[1.35fr_.65fr] gap-7 items-center">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-4">
              <span className="patient-chip-v7"><Sparkles className="w-3.5 h-3.5" /> {greeting()}, {patientFirstName}</span>
              <span className={`patient-status-v7 ${telemetry.isFallDetected ? 'danger' : 'safe'}`}>
                <span className="patient-status-dot" /> {safetyLabel}
              </span>
            </div>
            <h1 className="text-3xl sm:text-4xl lg:text-[46px] leading-[1.08] font-black tracking-[-0.035em] text-slate-950 max-w-3xl">
              Hôm nay, mình tiến thêm một bước nhỏ.
            </h1>
            <p className="mt-4 text-sm sm:text-base leading-7 text-slate-600 max-w-2xl">
              {summary?.recoveryDay ? `Ngày phục hồi thứ ${summary.recoveryDay}` : 'Chưa thiết lập ngày bắt đầu phục hồi'}
              {' • '}{userProfile.affectedLeg || 'Chưa chọn bên chân'}
              {userProfile.condition ? ` • ${userProfile.condition}` : ''}
            </p>
            <div className="mt-6 flex flex-col sm:flex-row gap-3">
              <button
                onClick={() => onNavigateToExercise(firstPending?.id)}
                className="patient-primary-v7"
              >
                <Play className="w-5 h-5 fill-current" />
                {firstPending ? 'Bắt đầu bài tập tiếp theo' : exercises.length ? 'Xem lại kế hoạch hôm nay' : 'Mở bài tập'}
                <ArrowRight className="w-4 h-4" />
              </button>
              <button onClick={onOpenPassport} className="patient-secondary-v7">
                <FileText className="w-4 h-4" /> Hộ chiếu phục hồi
              </button>
            </div>
          </div>

          <div className="patient-daily-ring-card">
            <div className="patient-ring" style={{ '--progress': `${dailyPercent}%` } as React.CSSProperties}>
              <div className="patient-ring-inner">
                <strong>{dailyPercent}%</strong>
                <span>hôm nay</span>
              </div>
            </div>
            <div className="mt-4 text-center">
              <div className="text-sm font-black text-slate-950">{completed}/{exercises.length} bài đã hoàn thành</div>
              <div className="text-xs text-slate-500 mt-1">Chỉ tăng khi buổi tập được lưu thật.</div>
            </div>
          </div>
        </div>
      </motion.section>

      <section className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {[
          { icon: CalendarDays, label: 'Ngày phục hồi', value: summary?.recoveryDay ? `Ngày ${summary.recoveryDay}` : 'Chưa đặt', note: 'Tính từ mốc bạn khai', tone: 'rose' },
          { icon: UserRoundCheck, label: 'Ngày đã tập', value: `${summary?.trainingDay || 0} ngày`, note: `${summary?.activeDaysLast7 || 0}/7 ngày gần đây`, tone: 'amber' },
          { icon: Target, label: 'Mức gập tốt nhất', value: bestAngle ? `${bestAngle}°` : 'Chưa có', note: bestAngle ? `${targetPercent}% mục tiêu cá nhân` : 'Chờ dữ liệu thật', tone: 'emerald' },
          { icon: HeartPulse, label: 'Mức đau gần nhất', value: summary?.latestPainLevel === null || summary?.latestPainLevel === undefined ? 'Chưa có' : `${summary.latestPainLevel}/10`, note: 'Do người bệnh tự khai', tone: 'sky' },
        ].map((item, index) => (
          <motion.div
            key={item.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: .35, delay: .04 * index }}
            className={`patient-metric-v7 ${item.tone}`}
          >
            <div className="patient-metric-icon"><item.icon className="w-5 h-5" /></div>
            <div className="mt-3 text-[11px] font-bold uppercase tracking-[.08em] text-slate-500">{item.label}</div>
            <div className="mt-1 text-xl sm:text-2xl font-black text-slate-950 tracking-tight">{item.value}</div>
            <div className="mt-1 text-[11px] text-slate-500">{item.note}</div>
          </motion.div>
        ))}
      </section>

      <section className="grid lg:grid-cols-[1.45fr_.75fr] gap-5">
        <motion.div
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          className="patient-panel-v7"
        >
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="patient-section-kicker"><Clock3 className="w-4 h-4" /> Kế hoạch hôm nay</div>
              <h2 className="patient-section-title">Tập đúng phần cần thiết, không chạy theo con số.</h2>
            </div>
            <span className="patient-count-pill">{completed}/{exercises.length}</span>
          </div>
          <div className="mt-5 space-y-2.5">
            {exercises.slice(0, 5).map((exercise, index) => {
              const done = completedIds.has(exercise.id);
              return (
                <button
                  key={exercise.id}
                  onClick={() => onNavigateToExercise(exercise.id)}
                  className={`patient-exercise-row ${done ? 'done' : ''}`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="patient-exercise-index">{done ? <CheckCircle2 className="w-5 h-5" /> : String(index + 1).padStart(2, '0')}</div>
                    <div className="text-left min-w-0">
                      <div className="text-sm font-black text-slate-900 truncate">{exercise.title}</div>
                      <div className="text-xs text-slate-500 mt-1">{exercise.totalReps} lần • hướng dẫn theo khả năng hiện tại</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className={`text-[11px] font-black ${done ? 'text-emerald-600' : 'text-rose-600'}`}>{done ? 'Đã lưu' : 'Tiếp theo'}</span>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </div>
                </button>
              );
            })}
            {!exercises.length && <div className="patient-empty-v7">Chưa có bài tập nào được thiết lập.</div>}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 10 }}
          animate={{ opacity: 1, x: 0 }}
          className="patient-panel-v7 patient-live-card-v7"
        >
          <div className="flex items-center justify-between gap-3">
            <div>
              <div className="patient-section-kicker"><Radio className="w-4 h-4" /> Chuyển động hiện tại</div>
              <h2 className="text-xl font-black text-slate-950 mt-1">{deviceConnected ? `${liveAngle}°` : 'Chưa có dữ liệu'}</h2>
            </div>
            <div className={`patient-device-dot ${deviceConnected ? 'online' : ''}`} />
          </div>
          <div className="patient-live-visual">
            <div className="patient-live-arc" style={{ '--angle': `${deviceConnected ? Math.min(100, liveAngle / 1.5) : 0}%` } as React.CSSProperties} />
            <div className="patient-live-center">
              <span>{deviceConnected ? `${liveBattery}%` : '0%'}</span>
              <small>pin thiết bị</small>
            </div>
          </div>
          <div className="text-xs leading-5 text-slate-500">
            {deviceConnected
              ? 'Số liệu đang được cập nhật từ thiết bị đã liên kết.'
              : 'Không có cảm biến kết nối nên hệ thống giữ các chỉ số chuyển động ở 0.'}
          </div>
          <div className="mt-4 grid grid-cols-2 gap-2">
            <button onClick={onNavigateTo3DTwin} className="patient-mini-action"><TrendingUp className="w-4 h-4" /> Xem chuyển động</button>
            <button onClick={onNavigateToDevice} className="patient-mini-action"><BatteryCharging className="w-4 h-4" /> Thiết bị</button>
          </div>
        </motion.div>
      </section>

      <section className="grid lg:grid-cols-[1.05fr_.95fr] gap-5">
        <div className="patient-panel-v7">
          <div className="flex items-center justify-between gap-3">
            <div>
              <div className="patient-section-kicker"><TrendingUp className="w-4 h-4" /> Nhịp tập 7 ngày</div>
              <h2 className="patient-section-title">Thói quen quan trọng hơn một ngày cố quá sức.</h2>
            </div>
            <div className="text-right"><div className="text-xl font-black text-slate-950">{summary?.activeDaysLast7 || 0}/7</div><div className="text-[10px] text-slate-500">ngày có tập</div></div>
          </div>
          <div className="patient-week-chart mt-6">
            {(summary?.sevenDay || []).map(item => {
              const height = item.sessions ? Math.min(100, Math.max(16, item.sessions * 34)) : 4;
              return <div key={item.date} className="patient-week-col"><span>{item.sessions || 0}</span><div><i style={{ height: `${height}%` }} /></div><small>{item.label}</small></div>;
            })}
            {!summary?.sevenDay?.length && <div className="patient-empty-v7 w-full">Chưa có lịch sử 7 ngày.</div>}
          </div>
        </div>

        <div className="patient-support-v7">
          <div>
            <div className="patient-section-kicker"><ShieldCheck className="w-4 h-4" /> An toàn & hỗ trợ</div>
            <h2 className="patient-section-title">Khi cần giúp đỡ, đừng phải tìm quá nhiều nút.</h2>
          </div>
          <div className="mt-5 space-y-3">
            <button
              onClick={permissionStatus === 'granted' && location ? onOpenGpsModal : onRequestLocation}
              className="patient-support-row"
            >
              <div className="patient-support-icon"><MapPin className="w-5 h-5" /></div>
              <div className="min-w-0 text-left">
                <div className="text-sm font-black text-slate-900">Vị trí khi cần hỗ trợ</div>
                <div className="text-xs text-slate-500 mt-1 truncate">
                  {permissionStatus === 'granted' && location ? location.formattedAddress : 'Chưa bật chia sẻ vị trí'}
                </div>
              </div>
              <Navigation className="w-4 h-4 text-slate-400 shrink-0" />
            </button>
            <button onClick={onOpenPassport} className="patient-support-row">
              <div className="patient-support-icon"><MessageCircleHeart className="w-5 h-5" /></div>
              <div className="min-w-0 text-left">
                <div className="text-sm font-black text-slate-900">Thông tin để người thân & bác sĩ hiểu nhanh</div>
                <div className="text-xs text-slate-500 mt-1">Hộ chiếu phục hồi chỉ dùng dữ liệu đã được ghi nhận.</div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
            </button>
          </div>
          {permissionStatus === 'granted' && nearbyHospitals?.[0] && (
            <div className="mt-4 patient-nearby-v7">
              <span>Cơ sở y tế gần vị trí hiện tại</span>
              <strong>{nearbyHospitals[0].name} • ~{nearbyHospitals[0].distanceKm} km</strong>
            </div>
          )}
        </div>
      </section>

      {loading && <div className="text-center text-xs text-slate-400 py-2">Đang đồng bộ dữ liệu phục hồi...</div>}
    </div>
  );
};
