import React, { useEffect, useMemo, useState } from 'react';
import { motion } from 'motion/react';
import {
  Activity,
  AlertTriangle,
  ArrowUpRight,
  CheckCircle2,
  Copy,
  Cpu,
  Download,
  ExternalLink,
  Eye,
  Fingerprint,
  HeartHandshake,
  KeyRound,
  Link2,
  Mail,
  MessageSquare,
  Plus,
  QrCode,
  RefreshCw,
  Search,
  Send,
  Server,
  ShieldCheck,
  Sparkles,
  Stethoscope,
  Trash2,
  UserRoundCheck,
  Users,
  Wifi,
  X,
} from 'lucide-react';
import { RegisteredUserRecord, UserRole, USER_ROLE_INFO, OtpAuditItem } from '../types';
import { QRCodeSVG } from 'qrcode.react';

interface AdminPortalScreenProps {
  users: RegisteredUserRecord[];
  currentAdminUser?: any;
  onSelectUserForLogin: (user: RegisteredUserRecord) => void;
  onDeleteUser: (userId: string) => void;
  onRegisterNewUser?: (newUser: RegisteredUserRecord) => void;
  onOpenChatWithUser?: (userId: string) => void;
}

type AdminTab = 'overview' | 'accounts' | 'links' | 'security' | 'share';

const roleMeta = {
  [UserRole.PATIENT]: { label: 'Người bệnh', icon: UserRoundCheck, className: 'patient' },
  [UserRole.CAREGIVER]: { label: 'Người thân', icon: HeartHandshake, className: 'caregiver' },
  [UserRole.DOCTOR]: { label: 'Bác sĩ', icon: Stethoscope, className: 'doctor' },
  [UserRole.ADMIN]: { label: 'Admin', icon: ShieldCheck, className: 'admin' },
};

const safeDate = (value?: string) => {
  if (!value) return 'Chưa có';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString('vi-VN', { dateStyle: 'short', timeStyle: 'short', timeZone: 'Asia/Ho_Chi_Minh' });
};

export const AdminPortalScreen: React.FC<AdminPortalScreenProps> = ({
  users,
  onDeleteUser,
  onOpenChatWithUser,
}) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [adminOverview, setAdminOverview] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<'ALL' | UserRole>('ALL');
  const [selectedUser, setSelectedUser] = useState<RegisteredUserRecord | null>(null);

  const [newAccountRole, setNewAccountRole] = useState<UserRole.DOCTOR | UserRole.CAREGIVER>(UserRole.DOCTOR);
  const [newAccountName, setNewAccountName] = useState('');
  const [newAccountEmail, setNewAccountEmail] = useState('');
  const [newAccountPhone, setNewAccountPhone] = useState('');
  const [newAccountPassword, setNewAccountPassword] = useState('');
  const [accountBusy, setAccountBusy] = useState(false);
  const [accountMessage, setAccountMessage] = useState('');

  const [linkPatientId, setLinkPatientId] = useState('');
  const [linkDoctorId, setLinkDoctorId] = useState('');
  const [linkCaregiverId, setLinkCaregiverId] = useState('');
  const [linkBusy, setLinkBusy] = useState(false);
  const [linkMessage, setLinkMessage] = useState('');

  const [emailSettings, setEmailSettings] = useState({ configured: false, apiKeyMasked: '', senderEmail: '', senderName: 'SOFT-EXO Family Care', provider: 'Brevo Transactional Email' });
  const [brevoApiKey, setBrevoApiKey] = useState('');
  const [testEmail, setTestEmail] = useState('');
  const [securityBusy, setSecurityBusy] = useState(false);
  const [securityMessage, setSecurityMessage] = useState<{ type: 'ok' | 'error'; text: string } | null>(null);
  const [otpLogs, setOtpLogs] = useState<OtpAuditItem[]>([]);
  const [copied, setCopied] = useState(false);

  const shareUrl = typeof window !== 'undefined' ? window.location.origin : '';

  const authHeaders = () => ({ Authorization: `Bearer ${localStorage.getItem('soft_exo_session_token') || ''}` });

  const fetchOverview = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/admin/overview', { headers: authHeaders() });
      const data = await response.json().catch(() => ({}));
      if (response.ok) {
        setAdminOverview(data);
        setOtpLogs(Array.isArray(data.otpAuditTrail) ? data.otpAuditTrail : []);
      }
    } finally {
      setLoading(false);
    }
  };

  const fetchEmailSettings = async () => {
    try {
      const response = await fetch('/api/admin/email-otp/settings', { headers: authHeaders() });
      const data = await response.json().catch(() => ({}));
      if (response.ok) setEmailSettings(prev => ({ ...prev, ...data }));
    } catch {}
  };

  useEffect(() => {
    fetchOverview();
    fetchEmailSettings();
    const timer = window.setInterval(fetchOverview, 15000);
    return () => window.clearInterval(timer);
  }, []);

  const effectiveUsers: RegisteredUserRecord[] = Array.isArray(adminOverview?.users) ? adminOverview.users : users;
  const patients = effectiveUsers.filter(user => user.role === UserRole.PATIENT);
  const doctors = effectiveUsers.filter(user => user.role === UserRole.DOCTOR);
  const caregivers = effectiveUsers.filter(user => user.role === UserRole.CAREGIVER);
  const admins = effectiveUsers.filter(user => user.role === UserRole.ADMIN);
  const linkedPatientIds = new Set(caregivers.map(item => item.linkedPatientId).filter(Boolean));
  const linkedPatients = patients.filter(patient => linkedPatientIds.has(patient.id) || Boolean(patient.caregiverName));
  const deviceLinkedPatients = patients.filter(patient => Boolean(patient.hardwareDeviceId));
  const verifiedOtp = otpLogs.filter(item => item.status === 'verified').length;
  const sentOtp = otpLogs.length;
  const otpRate = sentOtp ? Math.round((verifiedOtp / sentOtp) * 100) : 0;
  const liveDevice = Boolean(adminOverview?.liveTelemetry?.isConnected);
  const activeAlert = Boolean(adminOverview?.liveTelemetry?.isFallDetected);

  const readinessItems = [
    { label: 'Email OTP', ok: emailSettings.configured },
    { label: 'Có tài khoản người bệnh', ok: patients.length > 0 },
    { label: 'Có bác sĩ được xác minh', ok: doctors.length > 0 },
    { label: 'Có người thân được liên kết', ok: linkedPatients.length > 0 },
  ];
  const readinessScore = Math.round((readinessItems.filter(item => item.ok).length / readinessItems.length) * 100);

  const filteredUsers = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return effectiveUsers.filter(user => {
      const roleMatch = roleFilter === 'ALL' || user.role === roleFilter;
      const searchMatch = !q || [user.fullName, user.email, user.phone, user.condition].some(value => String(value || '').toLowerCase().includes(q));
      return roleMatch && searchMatch;
    });
  }, [effectiveUsers, searchQuery, roleFilter]);

  const createManagedAccount = async () => {
    setAccountBusy(true);
    setAccountMessage('');
    try {
      const response = await fetch('/api/admin/accounts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders() },
        body: JSON.stringify({ role: newAccountRole, fullName: newAccountName.trim(), email: newAccountEmail.trim(), phone: newAccountPhone.trim(), password: newAccountPassword }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || 'Không thể tạo tài khoản.');
      setAccountMessage(`Đã tạo ${newAccountRole === UserRole.DOCTOR ? 'tài khoản bác sĩ' : 'tài khoản người thân'} thành công.`);
      setNewAccountName(''); setNewAccountEmail(''); setNewAccountPhone(''); setNewAccountPassword('');
      await fetchOverview();
    } catch (err: any) {
      setAccountMessage(err?.message || 'Không thể tạo tài khoản.');
    } finally {
      setAccountBusy(false);
    }
  };

  const saveLinks = async () => {
    if (!linkPatientId) { setLinkMessage('Chọn người bệnh trước.'); return; }
    setLinkBusy(true); setLinkMessage('');
    try {
      const response = await fetch(`/api/admin/patients/${encodeURIComponent(linkPatientId)}/links`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', ...authHeaders() },
        body: JSON.stringify({ doctorId: linkDoctorId, caregiverId: linkCaregiverId }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || 'Không thể lưu liên kết.');
      setLinkMessage('Đã cập nhật nhóm chăm sóc của người bệnh.');
      await fetchOverview();
    } catch (err: any) {
      setLinkMessage(err?.message || 'Không thể lưu liên kết.');
    } finally {
      setLinkBusy(false);
    }
  };

  const selectPatientForLink = (patientId: string) => {
    setLinkPatientId(patientId);
    const patient = patients.find(item => item.id === patientId);
    const caregiver = caregivers.find(item => item.linkedPatientId === patientId);
    const doctor = doctors.find(item => item.fullName === patient?.doctorName);
    setLinkCaregiverId(caregiver?.id || '');
    setLinkDoctorId(doctor?.id || '');
    setLinkMessage('');
  };

  const saveEmailSettings = async () => {
    setSecurityBusy(true); setSecurityMessage(null);
    try {
      const response = await fetch('/api/admin/email-otp/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders() },
        body: JSON.stringify({ apiKey: brevoApiKey.trim(), senderEmail: emailSettings.senderEmail, senderName: emailSettings.senderName }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || 'Không thể lưu cấu hình Email OTP.');
      setEmailSettings(prev => ({ ...prev, ...data }));
      setBrevoApiKey('');
      setSecurityMessage({ type: 'ok', text: data.message || 'Đã lưu cấu hình Email OTP.' });
    } catch (err: any) {
      setSecurityMessage({ type: 'error', text: err?.message || 'Lưu cấu hình thất bại.' });
    } finally { setSecurityBusy(false); }
  };

  const sendOtpTest = async () => {
    setSecurityBusy(true); setSecurityMessage(null);
    try {
      const response = await fetch('/api/admin/email-otp/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders() },
        body: JSON.stringify({ target: testEmail.trim() }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || 'Không gửi được OTP thử.');
      setSecurityMessage({ type: 'ok', text: data.message || 'Đã gửi OTP thử.' });
      await fetchOverview();
    } catch (err: any) {
      setSecurityMessage({ type: 'error', text: err?.message || 'Gửi OTP thử thất bại.' });
    } finally { setSecurityBusy(false); }
  };

  const copyShareUrl = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1500);
    } catch {}
  };

  const exportData = () => {
    const payload = {
      exportedAt: new Date().toISOString(),
      metrics: adminOverview?.metrics || {},
      users: effectiveUsers,
      otpAudit: otpLogs.map(({ code, ...item }) => item),
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `soft-exo-admin-${new Date().toISOString().slice(0, 10)}.json`;
    anchor.click();
    URL.revokeObjectURL(url);
  };

  const SelectedUserIcon = selectedUser ? roleMeta[selectedUser.role].icon : ShieldCheck;

  const tabs: { id: AdminTab; label: string; icon: React.ElementType }[] = [
    { id: 'overview', label: 'Command Center', icon: Activity },
    { id: 'accounts', label: 'Tài khoản', icon: Users },
    { id: 'links', label: 'Nhóm chăm sóc', icon: Link2 },
    { id: 'security', label: 'Xác thực & bảo mật', icon: Fingerprint },
    { id: 'share', label: 'Phân phối app', icon: QrCode },
  ];

  return (
    <div className="admin-v7 max-w-[1480px] mx-auto space-y-5">
      <motion.section initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="admin-command-hero-v7">
        <div className="admin-grid-glow" />
        <div className="relative z-10 flex flex-col xl:flex-row xl:items-center justify-between gap-6">
          <div>
            <div className="admin-eyebrow-v7"><Sparkles className="w-4 h-4" /> SOFT-EXO Operations</div>
            <h1 className="text-3xl sm:text-4xl font-black tracking-[-.04em] text-white mt-3">Command Center</h1>
            <p className="text-sm text-slate-400 mt-2 max-w-2xl leading-6">Theo dõi tài khoản, nhóm chăm sóc, xác thực, thiết bị và trạng thái vận hành bằng dữ liệu thật của hệ thống.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button onClick={fetchOverview} disabled={loading} className="admin-ghost-btn-v7"><RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /> Đồng bộ</button>
            <button onClick={exportData} className="admin-primary-btn-v7"><Download className="w-4 h-4" /> Xuất dữ liệu</button>
          </div>
        </div>
        <div className="relative z-10 admin-pulse-strip-v7 mt-7">
          <div><span className={`pulse-dot ${activeAlert ? 'danger' : 'ok'}`} /><strong>{activeAlert ? 'Có cảnh báo an toàn' : 'Không có SOS đang hoạt động'}</strong></div>
          <div><span className={`pulse-dot ${liveDevice ? 'ok' : 'idle'}`} /><strong>{liveDevice ? 'Thiết bị đang online' : 'Chưa có thiết bị online'}</strong></div>
          <div><span className={`pulse-dot ${emailSettings.configured ? 'ok' : 'warning'}`} /><strong>{emailSettings.configured ? 'Email OTP sẵn sàng' : 'Email OTP chưa cấu hình'}</strong></div>
          <div className="text-slate-500">Cập nhật {safeDate(adminOverview?.serverTimestamp)}</div>
        </div>
      </motion.section>

      <nav className="admin-tabs-v7">
        {tabs.map(tab => <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={activeTab === tab.id ? 'active' : ''}><tab.icon className="w-4 h-4" /> {tab.label}</button>)}
      </nav>

      {activeTab === 'overview' && (
        <div className="space-y-5">
          <section className="grid grid-cols-2 xl:grid-cols-5 gap-3">
            {[
              { label: 'Tổng tài khoản', value: effectiveUsers.length, note: 'Toàn hệ thống', icon: Users, tone: 'violet' },
              { label: 'Người bệnh', value: patients.length, note: `${linkedPatients.length} đã có người thân`, icon: UserRoundCheck, tone: 'rose' },
              { label: 'Bác sĩ', value: doctors.length, note: 'Tài khoản kiểm soát', icon: Stethoscope, tone: 'emerald' },
              { label: 'Người thân', value: caregivers.length, note: `${linkedPatientIds.size} liên kết`, icon: HeartHandshake, tone: 'sky' },
              { label: 'Thiết bị online', value: liveDevice ? 1 : 0, note: `${deviceLinkedPatients.length} hồ sơ có mã thiết bị`, icon: Cpu, tone: 'amber' },
            ].map((item, index) => <motion.div key={item.label} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * .04 }} className={`admin-kpi-v7 ${item.tone}`}><div className="admin-kpi-icon"><item.icon className="w-5 h-5" /></div><span>{item.label}</span><strong>{item.value}</strong><small>{item.note}</small></motion.div>)}
          </section>

          <section className="grid xl:grid-cols-[1.15fr_.85fr] gap-5">
            <div className="admin-panel-v7">
              <div className="admin-panel-head-v7"><div><span>Hệ sinh thái người dùng</span><h2>Phân bổ vai trò đang hoạt động</h2></div><ShieldCheck className="w-5 h-5 text-violet-300" /></div>
              <div className="space-y-4 mt-6">
                {[
                  { label: 'Người bệnh', value: patients.length, total: Math.max(1, effectiveUsers.length), className: 'patient' },
                  { label: 'Người thân', value: caregivers.length, total: Math.max(1, effectiveUsers.length), className: 'caregiver' },
                  { label: 'Bác sĩ', value: doctors.length, total: Math.max(1, effectiveUsers.length), className: 'doctor' },
                  { label: 'Admin', value: admins.length, total: Math.max(1, effectiveUsers.length), className: 'admin' },
                ].map(row => <div key={row.label} className="admin-role-bar-v7"><div><span>{row.label}</span><strong>{row.value}</strong></div><i><b className={row.className} style={{ width: `${Math.round((row.value / row.total) * 100)}%` }} /></i></div>)}
              </div>
              <div className="grid sm:grid-cols-3 gap-3 mt-6">
                <div className="admin-mini-stat-v7"><span>Liên kết gia đình</span><strong>{patients.length ? Math.round((linkedPatients.length / patients.length) * 100) : 0}%</strong><small>{linkedPatients.length}/{patients.length} người bệnh</small></div>
                <div className="admin-mini-stat-v7"><span>OTP xác minh</span><strong>{otpRate}%</strong><small>{verifiedOtp}/{sentOtp} log gần đây</small></div>
                <div className="admin-mini-stat-v7"><span>Hồ sơ có thiết bị</span><strong>{patients.length ? Math.round((deviceLinkedPatients.length / patients.length) * 100) : 0}%</strong><small>{deviceLinkedPatients.length}/{patients.length} người bệnh</small></div>
              </div>
            </div>

            <div className="admin-panel-v7 admin-readiness-v7">
              <div className="admin-panel-head-v7"><div><span>Readiness</span><h2>Mức sẵn sàng vận hành</h2></div><div className="admin-score-ring-v7" style={{ '--score': `${readinessScore}%` } as React.CSSProperties}><strong>{readinessScore}%</strong></div></div>
              <div className="space-y-2.5 mt-6">
                {readinessItems.map(item => <div key={item.label} className={`admin-check-row-v7 ${item.ok ? 'ok' : ''}`}>{item.ok ? <CheckCircle2 className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}<span>{item.label}</span><strong>{item.ok ? 'Sẵn sàng' : 'Cần thiết lập'}</strong></div>)}
              </div>
              <div className="admin-data-note-v7 mt-4"><ShieldCheck className="w-4 h-4" /> Điểm này chỉ phản ánh cấu hình hiện có, không phải dữ liệu mô phỏng.</div>
            </div>
          </section>

          <section className="grid lg:grid-cols-3 gap-4">
            <button onClick={() => setActiveTab('accounts')} className="admin-jump-v7"><div className="admin-jump-icon"><Users className="w-5 h-5" /></div><div><strong>Quản lý tài khoản</strong><span>Tìm kiếm, kiểm tra, tạo bác sĩ/người thân.</span></div><ArrowUpRight className="w-4 h-4" /></button>
            <button onClick={() => setActiveTab('links')} className="admin-jump-v7"><div className="admin-jump-icon"><Link2 className="w-5 h-5" /></div><div><strong>Nhóm chăm sóc</strong><span>Ghép người bệnh với bác sĩ và người thân.</span></div><ArrowUpRight className="w-4 h-4" /></button>
            <button onClick={() => setActiveTab('security')} className="admin-jump-v7"><div className="admin-jump-icon"><Fingerprint className="w-5 h-5" /></div><div><strong>Xác thực & bảo mật</strong><span>Email OTP và nhật ký xác minh.</span></div><ArrowUpRight className="w-4 h-4" /></button>
          </section>
        </div>
      )}

      {activeTab === 'accounts' && (
        <section className="admin-panel-v7">
          <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4">
            <div className="admin-panel-head-v7"><div><span>Identity</span><h2>Tài khoản & vai trò</h2></div></div>
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="admin-search-v7"><Search className="w-4 h-4" /><input value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Tên, email, số điện thoại..." /></div>
              <select value={roleFilter} onChange={e => setRoleFilter(e.target.value as any)} className="admin-select-v7"><option value="ALL">Tất cả vai trò</option><option value={UserRole.PATIENT}>Người bệnh</option><option value={UserRole.CAREGIVER}>Người thân</option><option value={UserRole.DOCTOR}>Bác sĩ</option><option value={UserRole.ADMIN}>Admin</option></select>
            </div>
          </div>

          <div className="admin-user-table-v7 mt-5">
            <div className="admin-user-table-head"><span>Người dùng</span><span>Vai trò</span><span>Liên kết</span><span>Trạng thái</span><span /></div>
            {filteredUsers.map(user => {
              const meta = roleMeta[user.role];
              const Icon = meta.icon;
              const linkLabel = user.role === UserRole.CAREGIVER ? (user.linkedPatientId ? 'Đã liên kết người bệnh' : 'Chưa liên kết') : user.role === UserRole.PATIENT ? (user.caregiverName || user.doctorName ? 'Có nhóm chăm sóc' : 'Chưa có nhóm') : 'Theo phân quyền';
              return <div key={user.id} className="admin-user-row-v7"><div className="admin-user-main"><div className={`admin-role-avatar ${meta.className}`}><Icon className="w-4 h-4" /></div><div className="min-w-0"><strong className="truncate">{user.fullName}</strong><span className="truncate">{user.email || user.phone}</span></div></div><div><span className={`admin-role-pill ${meta.className}`}>{meta.label}</span></div><div className="text-xs text-slate-400">{linkLabel}</div><div><span className="admin-status-pill">{user.status || 'Đã kích hoạt'}</span></div><div className="flex justify-end gap-1"><button onClick={() => setSelectedUser(user)} className="admin-table-action"><Eye className="w-4 h-4" /></button>{onOpenChatWithUser && user.role !== UserRole.ADMIN && <button onClick={() => onOpenChatWithUser(user.id)} className="admin-table-action"><MessageSquare className="w-4 h-4" /></button>}{user.role !== UserRole.ADMIN && <button onClick={() => { if (window.confirm(`Xóa tài khoản ${user.fullName}?`)) onDeleteUser(user.id); }} className="admin-table-action danger"><Trash2 className="w-4 h-4" /></button>}</div></div>;
            })}
            {!filteredUsers.length && <div className="admin-empty-v7">Không tìm thấy tài khoản phù hợp.</div>}
          </div>

          <div className="admin-create-card-v7 mt-6">
            <div className="flex items-center gap-3"><div className="admin-jump-icon"><Plus className="w-5 h-5" /></div><div><strong>Tạo tài khoản được kiểm soát</strong><span>Bác sĩ và người thân có thể được Admin tạo khi cần hỗ trợ onboarding.</span></div></div>
            <div className="grid md:grid-cols-2 xl:grid-cols-5 gap-2.5 mt-4">
              <select value={newAccountRole} onChange={e => setNewAccountRole(e.target.value as UserRole.DOCTOR | UserRole.CAREGIVER)} className="admin-input-v7"><option value={UserRole.DOCTOR}>Bác sĩ</option><option value={UserRole.CAREGIVER}>Người thân</option></select>
              <input value={newAccountName} onChange={e => setNewAccountName(e.target.value)} placeholder="Họ và tên" className="admin-input-v7" />
              <input value={newAccountEmail} onChange={e => setNewAccountEmail(e.target.value)} placeholder="Email" className="admin-input-v7" />
              <input value={newAccountPhone} onChange={e => setNewAccountPhone(e.target.value)} placeholder="Số điện thoại" className="admin-input-v7" />
              <input value={newAccountPassword} onChange={e => setNewAccountPassword(e.target.value)} type="password" placeholder="Mật khẩu ban đầu" className="admin-input-v7" />
            </div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mt-3"><span className="text-xs text-slate-400">{accountMessage}</span><button onClick={createManagedAccount} disabled={accountBusy} className="admin-primary-btn-v7"><Plus className="w-4 h-4" />{accountBusy ? 'Đang tạo...' : 'Tạo tài khoản'}</button></div>
          </div>
        </section>
      )}

      {activeTab === 'links' && (
        <section className="grid xl:grid-cols-[.82fr_1.18fr] gap-5">
          <div className="admin-panel-v7">
            <div className="admin-panel-head-v7"><div><span>Care Network</span><h2>Thiết lập nhóm chăm sóc</h2></div><Link2 className="w-5 h-5 text-violet-300" /></div>
            <div className="space-y-3 mt-5">
              <label className="admin-field-v7"><span>Người bệnh</span><select value={linkPatientId} onChange={e => selectPatientForLink(e.target.value)}><option value="">Chọn người bệnh</option>{patients.map(item => <option key={item.id} value={item.id}>{item.fullName}</option>)}</select></label>
              <label className="admin-field-v7"><span>Bác sĩ phụ trách</span><select value={linkDoctorId} onChange={e => setLinkDoctorId(e.target.value)}><option value="">Chưa gán bác sĩ</option>{doctors.map(item => <option key={item.id} value={item.id}>{item.fullName}</option>)}</select></label>
              <label className="admin-field-v7"><span>Người thân</span><select value={linkCaregiverId} onChange={e => setLinkCaregiverId(e.target.value)}><option value="">Chưa gán người thân</option>{caregivers.map(item => <option key={item.id} value={item.id}>{item.fullName}</option>)}</select></label>
              <button onClick={saveLinks} disabled={linkBusy} className="admin-primary-btn-v7 w-full"><ShieldCheck className="w-4 h-4" />{linkBusy ? 'Đang lưu...' : 'Lưu nhóm chăm sóc'}</button>
              {linkMessage && <div className="text-xs text-slate-400 text-center">{linkMessage}</div>}
            </div>
          </div>
          <div className="admin-panel-v7">
            <div className="admin-panel-head-v7"><div><span>Coverage</span><h2>Tình trạng liên kết người bệnh</h2></div></div>
            <div className="space-y-2.5 mt-5">
              {patients.map(patient => {
                const caregiver = caregivers.find(item => item.linkedPatientId === patient.id);
                return <button key={patient.id} onClick={() => selectPatientForLink(patient.id)} className="admin-care-row-v7"><div className="admin-user-main"><div className="admin-role-avatar patient"><UserRoundCheck className="w-4 h-4" /></div><div><strong>{patient.fullName}</strong><span>{patient.condition || 'Phục hồi tại nhà'}</span></div></div><div className="admin-care-links"><span className={patient.doctorName ? 'ok' : ''}><Stethoscope className="w-3.5 h-3.5" />{patient.doctorName || 'Chưa có bác sĩ'}</span><span className={caregiver ? 'ok' : ''}><HeartHandshake className="w-3.5 h-3.5" />{caregiver?.fullName || patient.caregiverName || 'Chưa có người thân'}</span></div><ChevronRightIcon /></button>;
              })}
              {!patients.length && <div className="admin-empty-v7">Chưa có người bệnh.</div>}
            </div>
          </div>
        </section>
      )}

      {activeTab === 'security' && (
        <section className="grid xl:grid-cols-[.9fr_1.1fr] gap-5">
          <div className="admin-panel-v7">
            <div className="admin-panel-head-v7"><div><span>Authentication</span><h2>Email OTP thật</h2></div><Mail className="w-5 h-5 text-violet-300" /></div>
            <div className={`admin-security-status-v7 mt-5 ${emailSettings.configured ? 'ok' : ''}`}><div>{emailSettings.configured ? <CheckCircle2 className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}<strong>{emailSettings.configured ? 'Đã cấu hình' : 'Chưa cấu hình'}</strong></div><span>{emailSettings.provider}</span></div>
            <div className="space-y-3 mt-4">
              <label className="admin-field-v7"><span>Sender email</span><input value={emailSettings.senderEmail} onChange={e => setEmailSettings(prev => ({ ...prev, senderEmail: e.target.value }))} placeholder="sender@example.com" /></label>
              <label className="admin-field-v7"><span>Tên người gửi</span><input value={emailSettings.senderName} onChange={e => setEmailSettings(prev => ({ ...prev, senderName: e.target.value }))} /></label>
              <label className="admin-field-v7"><span>Brevo API Key</span><input value={brevoApiKey} onChange={e => setBrevoApiKey(e.target.value)} type="password" placeholder={emailSettings.apiKeyMasked || 'Nhập key mới để cập nhật'} /></label>
              <button onClick={saveEmailSettings} disabled={securityBusy} className="admin-primary-btn-v7 w-full"><KeyRound className="w-4 h-4" /> Lưu & xác thực cấu hình</button>
              <div className="admin-test-row-v7"><input value={testEmail} onChange={e => setTestEmail(e.target.value)} placeholder="Email nhận OTP thử" /><button onClick={sendOtpTest} disabled={securityBusy}><Send className="w-4 h-4" /> Gửi thử</button></div>
              {securityMessage && <div className={`admin-message-v7 ${securityMessage.type}`}>{securityMessage.text}</div>}
            </div>
          </div>
          <div className="admin-panel-v7">
            <div className="admin-panel-head-v7"><div><span>Audit</span><h2>Nhật ký OTP gần đây</h2></div><Fingerprint className="w-5 h-5 text-violet-300" /></div>
            <div className="space-y-2 mt-5">
              {otpLogs.slice(0, 12).map(item => <div key={item.id} className="admin-audit-row-v7"><div><strong>{item.target}</strong><span>{safeDate(item.createdAt)}</span></div><span className={`admin-audit-status ${item.status}`}>{item.status === 'verified' ? 'Đã xác minh' : item.status === 'sent' ? 'Đã gửi' : 'Hết hạn'}</span></div>)}
              {!otpLogs.length && <div className="admin-empty-v7">Chưa có nhật ký OTP.</div>}
            </div>
          </div>
        </section>
      )}

      {activeTab === 'share' && (
        <section className="admin-panel-v7 admin-share-v7">
          <div className="grid lg:grid-cols-[.75fr_1.25fr] gap-8 items-center">
            <div className="admin-qr-v7"><QRCodeSVG value={shareUrl || 'https://soft-exo.app'} size={220} level="H" bgColor="#ffffff" fgColor="#0f172a" includeMargin /></div>
            <div>
              <div className="admin-eyebrow-v7"><QrCode className="w-4 h-4" /> App access</div>
              <h2 className="text-3xl font-black text-white tracking-[-.03em] mt-3">Một QR để mở đúng ứng dụng.</h2>
              <p className="text-sm text-slate-400 leading-6 mt-3 max-w-xl">QR này chỉ dùng để mở SOFT-EXO. QR sản phẩm/thiết bị là loại khác và được quét trong tài khoản người bệnh.</p>
              <div className="admin-url-box-v7 mt-5"><code>{shareUrl}</code><button onClick={copyShareUrl}><Copy className="w-4 h-4" />{copied ? 'Đã sao chép' : 'Sao chép'}</button></div>
              <a href={shareUrl} target="_blank" rel="noreferrer" className="admin-ghost-btn-v7 inline-flex mt-3"><ExternalLink className="w-4 h-4" /> Mở ứng dụng</a>
            </div>
          </div>
        </section>
      )}

      {selectedUser && (
        <div className="admin-modal-backdrop-v7" onClick={() => setSelectedUser(null)}>
          <motion.div initial={{ opacity: 0, scale: .97, y: 8 }} animate={{ opacity: 1, scale: 1, y: 0 }} className="admin-user-modal-v7" onClick={event => event.stopPropagation()}>
            <button onClick={() => setSelectedUser(null)} className="admin-modal-close-v7"><X className="w-5 h-5" /></button>
            <div className="admin-user-main"><div className={`admin-role-avatar ${roleMeta[selectedUser.role].className}`}><SelectedUserIcon className="w-5 h-5" /></div><div><h3>{selectedUser.fullName}</h3><span>{roleMeta[selectedUser.role].label}</span></div></div>
            <div className="admin-detail-grid-v7 mt-5"><div><span>Email</span><strong>{selectedUser.email || 'Chưa có'}</strong></div><div><span>Điện thoại</span><strong>{selectedUser.phone || 'Chưa có'}</strong></div><div><span>Tình trạng</span><strong>{selectedUser.condition || 'Chưa cập nhật'}</strong></div><div><span>Thiết bị</span><strong>{selectedUser.hardwareDeviceId || 'Chưa liên kết'}</strong></div><div><span>Đăng ký</span><strong>{selectedUser.registrationTimestamp || 'Chưa có'}</strong></div><div><span>Trạng thái</span><strong>{selectedUser.status || 'Đã kích hoạt'}</strong></div></div>
          </motion.div>
        </div>
      )}
    </div>
  );
};

const ChevronRightIcon = () => <ArrowUpRight className="w-4 h-4 text-slate-500 shrink-0" />;
