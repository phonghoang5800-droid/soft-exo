# HOTFIX WEB PUSH / NODE 24

Đã sửa lỗi khởi động:

`TypeError: webpush.generateVAPIDKeys is not a function`

Nguyên nhân: hình dạng export của package `web-push` khác nhau giữa CommonJS/ESM runtime.
Server nay chuẩn hóa cả hai dạng trước khi gọi `generateVAPIDKeys`, `setVapidDetails` và `sendNotification`.

Sau khi giải nén:

```bash
npm install
npm run dev
```
