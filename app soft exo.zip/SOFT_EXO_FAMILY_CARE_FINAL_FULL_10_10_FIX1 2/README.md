# SOFT-EXO Family Care — Final Email OTP + Light Tech UI

Bản này giữ các màn hình/chức năng chính của dự án SOFT-EXO và nâng cấp hai phần quan trọng:

- **Email OTP thật** qua Brevo Transactional Email. Không trả OTP về frontend, không dùng mã mặc định, không auto-fill giả.
- **Giao diện Light Tech** sáng, rõ, responsive hơn cho Mac/iPhone, vẫn giữ Digital Twin, bài tập, bác sĩ, người thân, chat, thiết bị, GPS, SOS và Admin Portal.

## Chạy nhanh trên Mac

Double-click:

`RUN_SOFT_EXO_MAC.command`

Hoặc Terminal:

```bash
npm install
npm run dev
```

Mở:

```text
http://localhost:3012
```

## Cấu hình Email OTP thật một lần

1. Đăng nhập Admin bằng tài khoản Admin hiện có của dự án.
2. Vào **Cổng quản trị → Cấu Hình Email OTP**.
3. Nhập:
   - Brevo API Key (`xkeysib-...`)
   - Email người gửi đã xác minh trên Brevo
   - Tên người gửi, ví dụ `SOFT-EXO Family Care`
4. Bấm **Lưu & xác thực**.
5. Nhập email nhận thử → **Gửi OTP thử**.

Cấu hình được lưu cục bộ trên máy chạy server và API key được mã hóa trước khi ghi xuống đĩa. Không cần mở `.env` để cấu hình OTP.

## Luồng OTP

```text
Người dùng nhập email riêng
→ Backend sinh 6 số ngẫu nhiên
→ Brevo gửi email thật
→ Người dùng nhập mã
→ Backend kiểm tra hash
→ đúng mới cho tạo tài khoản / đặt lại mật khẩu
```

- Mã hiệu lực: 5 phút.
- Mỗi lần yêu cầu tạo mã mới.
- Mỗi mã chỉ dùng một lần.
- Tối đa 5 lần nhập sai.
- Giới hạn gửi lại 30 giây.
- SMS OTP đã được loại khỏi luồng đăng ký để hệ thống gọn và ổn định.

## Tài khoản và phân quyền

- Đăng ký công khai chỉ tạo **Người sử dụng / Patient**.
- Doctor / Caregiver / Admin không thể tự chọn từ form đăng ký công khai.
- Tài khoản mới được lưu ở backend (`data/users.json`) để thiết bị khác đăng nhập được, thay vì chỉ nằm trong localStorage của một trình duyệt.
- Password backend được băm bằng `scrypt`.
- Các endpoint quản trị và cấu hình Brevo yêu cầu phiên Admin.

## Dùng trên điện thoại cùng Wi‑Fi

Web có endpoint tự tìm IP LAN và nút QR dùng IP của Mac thay vì `localhost`.

Ví dụ:

```text
http://192.168.x.x:3012
```

Mac phải tiếp tục chạy `npm run dev`.

## Phần cứng

Các phần Digital Twin / thiết bị / IMU hiện có được giữ nguyên để tiếp tục đồng bộ ESP32-S3 + MPU6050 sau. Việc thay hệ thống OTP không buộc thay firmware cảm biến.

Xem thêm: `START_HERE_VI.md`.

## Chạy 24/7 trên Internet

Xem `RAILWAY_24_7_VI.md` để deploy lên Railway. Khi deploy xong, người dùng có thể mở app hoặc quét QR bất cứ lúc nào mà không cần Mac bật.
