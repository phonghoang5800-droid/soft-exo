import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import fs from 'fs';
import crypto from 'crypto';
import os from 'os';
import dgram from 'dgram';
import * as webpushModule from 'web-push';

// web-push 3.6.x may be exposed as CommonJS default or ESM named exports
// depending on the installed package/runtime. Normalize both shapes once.
const webpush: any = (webpushModule as any).default ?? webpushModule;

const app = express();
const PORT = Number(process.env.PORT || 3012);

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// -----------------------------------------------------------------------------
// REAL EMAIL OTP CONFIGURATION (Brevo Transactional Email)
// Stored locally on the Mac. The API key is encrypted at rest with a local key.
// -----------------------------------------------------------------------------
const DATA_DIR = process.env.RAILWAY_VOLUME_MOUNT_PATH || process.env.DATA_DIR || path.join(process.cwd(), 'data');
const OTP_SETTINGS_FILE = path.join(DATA_DIR, 'email-otp-settings.json');
const LOCAL_SECRET_FILE = path.join(DATA_DIR, '.soft-exo-local-secret');
const VAPID_FILE = path.join(DATA_DIR, 'web-push-vapid.json');
const PUSH_SUBSCRIPTIONS_FILE = path.join(DATA_DIR, 'push-subscriptions.json');
const DEVICE_API_KEY_FILE = path.join(DATA_DIR, 'device-api-key.txt');
const DEVICE_LINKS_FILE = path.join(DATA_DIR, 'device-links.json');

interface EmailOtpSettings {
  apiKeyEncrypted?: string;
  senderEmail: string;
  senderName: string;
}

interface ActiveOtpSecret {
  target: string;
  purpose: 'register' | 'forgot_password' | 'login' | 'test';
  salt: string;
  hash: string;
  createdAt: number;
  expiresAt: number;
  attempts: number;
  verified: boolean;
}

type KneeSide = 'LEFT' | 'RIGHT' | 'BOTH' | 'UNKNOWN';

interface DeviceLinkRecord {
  userId: string;
  productCode: string;
  kneeSide: KneeSide;
  linkedAt: string;
}

function normalizeKneeSide(value: unknown): KneeSide {
  const raw = String(value || '').trim().toUpperCase();
  if (['LEFT', 'L', 'TRAI', 'TRÁI', 'GOI_TRAI', 'GỐI TRÁI'].includes(raw)) return 'LEFT';
  if (['RIGHT', 'R', 'PHAI', 'PHẢI', 'GOI_PHAI', 'GỐI PHẢI'].includes(raw)) return 'RIGHT';
  if (['BOTH', 'B', 'DUAL', '2', 'TWO', 'HAI', 'CA_HAI', 'CẢ HAI', '2_GOI', '2 GỐI'].includes(raw)) return 'BOTH';
  return 'UNKNOWN';
}

function parseSoftExoProductPayload(rawInput: unknown): { productCode: string; kneeSide: KneeSide } {
  const raw = String(rawInput || '').trim();
  if (!raw) return { productCode: '', kneeSide: 'UNKNOWN' };

  // Preferred production QR payload: JSON with code + side.
  // Example: {"productCode":"SE-2026-0001","kneeSide":"LEFT"}
  try {
    if (raw.startsWith('{')) {
      const obj = JSON.parse(raw);
      const code = String(obj.productCode || obj.code || obj.serial || '').trim();
      const side = normalizeKneeSide(obj.kneeSide || obj.side || obj.placement);
      if (code) return { productCode: code, kneeSide: side };
    }
  } catch {}

  // Deep-link QR format: softexo://device?code=SE-2026-0001&side=LEFT
  if (/^softexo:\/\//i.test(raw)) {
    try {
      const url = new URL(raw);
      const code = String(url.searchParams.get('code') || url.searchParams.get('serial') || '').trim();
      const side = normalizeKneeSide(url.searchParams.get('side') || url.searchParams.get('placement'));
      if (code) return { productCode: code, kneeSide: side };
    } catch {}
  }

  // Compact QR/barcode format: SOFTEXO|CODE=SE-2026-0001|SIDE=LEFT
  if (/^SOFTEXO\|/i.test(raw)) {
    const parts = raw.split('|').slice(1);
    const kv: Record<string, string> = {};
    for (const part of parts) {
      const [key, ...rest] = part.split('=');
      if (key && rest.length) kv[key.trim().toUpperCase()] = rest.join('=').trim();
    }
    const code = String(kv.CODE || kv.SERIAL || '').trim();
    const side = normalizeKneeSide(kv.SIDE || kv.PLACEMENT);
    if (code) return { productCode: code, kneeSide: side };
  }

  // Bare serial fallback. New product labels can encode side in the serial:
  // SE-L-xxxx, SE-R-xxxx, SE-B-xxxx or suffix -L/-R/-B.
  const upper = raw.toUpperCase();
  let kneeSide: KneeSide = 'UNKNOWN';
  if (/(^|[-_])L(EFT)?([-_]|$)/.test(upper)) kneeSide = 'LEFT';
  else if (/(^|[-_])R(IGHT)?([-_]|$)/.test(upper)) kneeSide = 'RIGHT';
  else if (/(^|[-_])(B|BOTH|DUAL)([-_]|$)/.test(upper)) kneeSide = 'BOTH';
  return { productCode: raw, kneeSide };
}

fs.mkdirSync(DATA_DIR, { recursive: true });

function loadDeviceLinks(): DeviceLinkRecord[] {
  try {
    if (fs.existsSync(DEVICE_LINKS_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(DEVICE_LINKS_FILE, 'utf8'));
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (err) {
    console.warn('[DEVICE LINK] Could not read saved product links:', err);
  }
  return [];
}

let deviceLinks: DeviceLinkRecord[] = loadDeviceLinks();
function saveDeviceLinks() {
  fs.writeFileSync(DEVICE_LINKS_FILE, JSON.stringify(deviceLinks, null, 2));
}

// -----------------------------------------------------------------------------
// WEB PUSH FOR EMERGENCY ALERTS
// Enables caregiver/doctor/admin devices to receive SOS notifications even when
// the app is not the active tab. On iPhone/iPad, Web Push requires the web app
// to be added to the Home Screen and notification permission to be granted.
// -----------------------------------------------------------------------------
interface StoredPushSubscription {
  endpoint: string;
  expirationTime?: number | null;
  keys: { p256dh: string; auth: string };
  role?: string;
  userId?: string;
  createdAt: string;
}

function loadOrCreateVapidKeys(): { publicKey: string; privateKey: string } {
  try {
    if (fs.existsSync(VAPID_FILE)) {
      const saved = JSON.parse(fs.readFileSync(VAPID_FILE, 'utf8'));
      if (saved.publicKey && saved.privateKey) return saved;
    }
  } catch (err) {
    console.warn('[WEB PUSH] Could not read saved VAPID keys:', err);
  }
  const keys = webpush.generateVAPIDKeys();
  fs.writeFileSync(VAPID_FILE, JSON.stringify(keys, null, 2), { mode: 0o600 });
  return keys;
}

function loadPushSubscriptions(): StoredPushSubscription[] {
  try {
    if (fs.existsSync(PUSH_SUBSCRIPTIONS_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(PUSH_SUBSCRIPTIONS_FILE, 'utf8'));
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (err) {
    console.warn('[WEB PUSH] Could not read subscriptions:', err);
  }
  return [];
}

const vapidKeys = loadOrCreateVapidKeys();
let pushSubscriptions = loadPushSubscriptions();
webpush.setVapidDetails('mailto:notifications@softexo.vn', vapidKeys.publicKey, vapidKeys.privateKey);

function savePushSubscriptions() {
  fs.writeFileSync(PUSH_SUBSCRIPTIONS_FILE, JSON.stringify(pushSubscriptions, null, 2));
}

async function sendSafetyWebPush(alert: any) {
  const targets = pushSubscriptions.filter(subscription => {
    const role = String(subscription.role || '').toUpperCase();
    if (role === 'ADMIN' || role === 'DOCTOR') return true;
    if (role !== 'CAREGIVER') return false;
    if (!alert.patientId) return true;
    const caregiver = masterUsers.find(user => user.id === subscription.userId);
    return caregiver?.linkedPatientId === alert.patientId;
  });
  if (!targets.length) return;

  const patientLabel = alert.patientName ? `${alert.patientName}: ` : '';
  const locationLabel = alert.location ? ` • ${alert.location}` : '';
  const payload = JSON.stringify({
    title: alert.title || 'SOFT-EXO • Cảnh báo an toàn',
    body: `${patientLabel}${alert.message || 'Phát hiện tình huống cần kiểm tra ngay.'}${locationLabel}`,
    alertId: alert.id,
    severity: alert.severity,
    patientName: alert.patientName,
    location: alert.location,
    url: '/',
    timestamp: alert.timestamp || new Date().toISOString(),
  });

  const invalid = new Set<string>();
  await Promise.allSettled(targets.map(async (subscription) => {
    try {
      await webpush.sendNotification(
        { endpoint: subscription.endpoint, expirationTime: subscription.expirationTime ?? null, keys: subscription.keys },
        payload,
        { TTL: 120, urgency: 'high', topic: 'soft-exo-sos' }
      );
    } catch (err: any) {
      if (err?.statusCode === 404 || err?.statusCode === 410) invalid.add(subscription.endpoint);
      else console.warn('[WEB PUSH] Delivery notice:', err?.statusCode || err?.message || err);
    }
  }));

  if (invalid.size) {
    pushSubscriptions = pushSubscriptions.filter(s => !invalid.has(s.endpoint));
    savePushSubscriptions();
  }
}

function getLocalEncryptionKey(): Buffer {
  if (!fs.existsSync(LOCAL_SECRET_FILE)) {
    fs.writeFileSync(LOCAL_SECRET_FILE, crypto.randomBytes(32).toString('hex'), { mode: 0o600 });
  }
  const raw = fs.readFileSync(LOCAL_SECRET_FILE, 'utf8').trim();
  return Buffer.from(raw, 'hex');
}

function getDeviceApiKey(): string {
  if (!fs.existsSync(DEVICE_API_KEY_FILE)) {
    fs.writeFileSync(DEVICE_API_KEY_FILE, crypto.randomBytes(24).toString('hex'), { mode: 0o600 });
  }
  return fs.readFileSync(DEVICE_API_KEY_FILE, 'utf8').trim();
}

const DEVICE_API_KEY = getDeviceApiKey();

function requireDeviceApiKey(req: any, res: any, next: any) {
  const supplied = String(req.headers['x-soft-exo-device-key'] || '').trim();
  const expected = DEVICE_API_KEY;
  if (!supplied || supplied.length !== expected.length) {
    return res.status(401).json({ error: 'Device API key không hợp lệ.' });
  }
  const a = Buffer.from(supplied);
  const b = Buffer.from(expected);
  if (!crypto.timingSafeEqual(a, b)) return res.status(401).json({ error: 'Device API key không hợp lệ.' });
  next();
}

function encryptLocalSecret(value: string): string {
  const key = getLocalEncryptionKey();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(value, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `${iv.toString('hex')}.${tag.toString('hex')}.${encrypted.toString('hex')}`;
}

function decryptLocalSecret(value?: string): string {
  if (!value) return '';
  try {
    const [ivHex, tagHex, encryptedHex] = value.split('.');
    const decipher = crypto.createDecipheriv('aes-256-gcm', getLocalEncryptionKey(), Buffer.from(ivHex, 'hex'));
    decipher.setAuthTag(Buffer.from(tagHex, 'hex'));
    return Buffer.concat([decipher.update(Buffer.from(encryptedHex, 'hex')), decipher.final()]).toString('utf8');
  } catch {
    return '';
  }
}

function loadEmailOtpSettings(): EmailOtpSettings {
  try {
    if (fs.existsSync(OTP_SETTINGS_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(OTP_SETTINGS_FILE, 'utf8'));
      return {
        apiKeyEncrypted: parsed.apiKeyEncrypted || '',
        senderEmail: parsed.senderEmail || '',
        senderName: parsed.senderName || 'SOFT-EXO Family Care',
      };
    }
  } catch (err) {
    console.warn('[OTP SETTINGS] Could not read saved settings:', err);
  }
  return { apiKeyEncrypted: '', senderEmail: '', senderName: 'SOFT-EXO Family Care' };
}

let emailOtpSettings = loadEmailOtpSettings();
const activeOtpSecrets = new Map<string, ActiveOtpSecret>();

interface SessionPayload {
  userId: string;
  role: string;
  expiresAt: number;
}

function createSessionToken(userId: string, role: string, ttlMs = 24 * 60 * 60 * 1000): string {
  const payload: SessionPayload = { userId, role, expiresAt: Date.now() + ttlMs };
  const encoded = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const signature = crypto.createHmac('sha256', getLocalEncryptionKey()).update(encoded).digest('base64url');
  return `${encoded}.${signature}`;
}

function verifySessionToken(token: string): SessionPayload | null {
  try {
    const [encoded, signature] = token.split('.');
    if (!encoded || !signature) return null;
    const expected = crypto.createHmac('sha256', getLocalEncryptionKey()).update(encoded).digest('base64url');
    const a = Buffer.from(signature);
    const b = Buffer.from(expected);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
    const payload = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as SessionPayload;
    if (!payload.userId || !payload.role || payload.expiresAt < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}

const requireAdmin = (req: any, res: any, next: any) => {
  const auth = String(req.headers.authorization || '');
  const token = auth.startsWith('Bearer ') ? auth.slice(7).trim() : '';
  const session = token ? verifySessionToken(token) : null;
  if (!session || session.role !== 'ADMIN') {
    return res.status(401).json({ error: 'Phiên quản trị không hợp lệ hoặc đã hết hạn.' });
  }
  next();
};

const requireAuth = (req: any, res: any, next: any) => {
  const auth = String(req.headers.authorization || '');
  const token = auth.startsWith('Bearer ') ? auth.slice(7).trim() : '';
  const session = token ? verifySessionToken(token) : null;
  if (!session) return res.status(401).json({ error: 'Phiên đăng nhập không hợp lệ hoặc đã hết hạn.' });
  req.session = session;
  next();
};

const requireStreamAuth = (req: any, res: any, next: any) => {
  const token = String(req.query?.token || '').trim();
  const session = token ? verifySessionToken(token) : null;
  if (!session) return res.status(401).end();
  req.session = session;
  next();
};
const otpLastSentAt = new Map<string, number>();

function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

function isValidEmailAddress(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizeEmail(email));
}

function otpKey(target: string, purpose: string): string {
  return `${purpose}:${normalizeEmail(target)}`;
}

function hashOtp(code: string, salt: string): string {
  return crypto.createHash('sha256').update(`${salt}:${code}`).digest('hex');
}

function maskApiKey(key: string): string {
  if (!key) return '';
  if (key.length <= 10) return '••••••••';
  return `${key.slice(0, 7)}••••••••${key.slice(-4)}`;
}

async function validateBrevoApiKey(apiKey: string): Promise<void> {
  const response = await fetch('https://api.brevo.com/v3/account', {
    headers: { accept: 'application/json', 'api-key': apiKey },
  });
  if (!response.ok) {
    const body = await response.text();
    throw new Error(`Brevo từ chối API key (${response.status}): ${body.slice(0, 180)}`);
  }
}

async function sendBrevoOtpEmail(target: string, code: string, purpose: string, fullName?: string): Promise<void> {
  const apiKey = decryptLocalSecret(emailOtpSettings.apiKeyEncrypted);
  if (!apiKey || !emailOtpSettings.senderEmail) {
    throw new Error('Email OTP chưa được cấu hình. Admin cần nhập Brevo API Key và email người gửi một lần.');
  }

  const actionText = purpose === 'forgot_password' ? 'khôi phục mật khẩu' : purpose === 'login' ? 'đăng nhập' : 'xác minh tài khoản';
  const safeName = (fullName || 'bạn').replace(/[<>]/g, '');
  const htmlContent = `
  <div style="font-family:Inter,Arial,sans-serif;background:#f5f9ff;padding:32px;color:#0f172a">
    <div style="max-width:560px;margin:0 auto;background:#fff;border:1px solid #dbeafe;border-radius:22px;overflow:hidden;box-shadow:0 18px 45px rgba(37,99,235,.10)">
      <div style="padding:24px 28px;background:linear-gradient(135deg,#0f4c81,#2563eb 55%,#06b6d4);color:#fff">
        <div style="font-size:12px;font-weight:800;letter-spacing:1.6px;opacity:.86">SOFT-EXO FAMILY CARE</div>
        <div style="font-size:23px;font-weight:900;margin-top:6px">Mã xác thực OTP</div>
      </div>
      <div style="padding:28px">
        <p style="font-size:15px;line-height:1.7;margin:0 0 16px">Xin chào <strong>${safeName}</strong>,</p>
        <p style="font-size:14px;line-height:1.7;color:#475569">Bạn vừa yêu cầu ${actionText}. Mã OTP của bạn là:</p>
        <div style="margin:22px 0;text-align:center">
          <span style="display:inline-block;padding:14px 22px;border-radius:16px;background:#eff6ff;border:1px solid #bfdbfe;color:#1d4ed8;font-size:32px;font-weight:900;letter-spacing:9px">${code}</span>
        </div>
        <p style="font-size:13px;line-height:1.7;color:#64748b">Mã có hiệu lực trong <strong>5 phút</strong> và chỉ dùng một lần. Không chia sẻ mã này cho bất kỳ ai.</p>
      </div>
    </div>
  </div>`;

  const response = await fetch('https://api.brevo.com/v3/smtp/email', {
    method: 'POST',
    headers: {
      accept: 'application/json',
      'api-key': apiKey,
      'content-type': 'application/json',
    },
    body: JSON.stringify({
      sender: { email: emailOtpSettings.senderEmail, name: emailOtpSettings.senderName || 'SOFT-EXO Family Care' },
      to: [{ email: normalizeEmail(target), name: fullName || undefined }],
      subject: `SOFT-EXO • Mã OTP ${code}`,
      htmlContent,
    }),
  });

  if (!response.ok) {
    const body = await response.text();
    throw new Error(`Brevo gửi email thất bại (${response.status}): ${body.slice(0, 220)}`);
  }
}


// In-Memory persistent master store on backend
interface StoredUser {
  id: string;
  fullName: string;
  phone: string;
  email: string;
  role: string;
  password?: string;
  passwordHash?: string;
  passwordSalt?: string;
  age: number;
  condition: string;
  affectedLeg: string;
  packageTier: string;
  registeredFeatures: string[];
  hardwareDeviceId: string;
  registrationTimestamp: string;
  status: string;
  notes?: string;
  linkedPatientId?: string;
  doctorId?: string;
  dateOfBirth?: string;
  gender?: string;
  address?: string;
  surgeryDate?: string;
  recoveryStartDate?: string;
  doctorName?: string;
  doctorHospital?: string;
  caregiverName?: string;
  caregiverPhone?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  medicalHistory?: string;
  allergies?: string;
  medications?: string;
  privacyConsentAt?: string;
  shareWithDoctor?: boolean;
  shareWithCaregiver?: boolean;
  shareLocationOnSos?: boolean;
  adminApprovedAt?: string;
  // Multi-facility / hospital-ready profile fields
  facilityName?: string;
  facilityCode?: string;
  department?: string;
  medicalRecordCode?: string;
  familyInviteCode?: string;
  relationship?: string;
  linkedAt?: string;
  location?: {
    latitude: number;
    longitude: number;
    accuracy: number;
    formattedAddress: string;
    city?: string;
    district?: string;
    updatedAt: string;
  };
}

interface OtpLog {
  id: string;
  target: string;
  channel: 'sms' | 'email';
  code: string;
  carrier?: string;
  status: 'sent' | 'verified' | 'expired';
  createdAt: string;
  verifiedAt?: string;
}

interface ChatMsg {
  id: string;
  threadId: string;
  senderName: string;
  senderRole: string;
  content: string;
  timestamp: string;
  isDoctor?: boolean;
  photoUrl?: string;
  photoMime?: string;
  audioUrl?: string;
  isAi?: boolean;
}

// Bootstrap database. Production starts with only the system administrator.
// Patient, caregiver and doctor accounts must come from real registration/admin flows.
const masterUsers: StoredUser[] = [
  {
    id: 'usr_admin_01',
    fullName: 'SOFT-EXO Administrator',
    phone: '0367973655',
    email: 'quynhtrang1011td@gmail.com',
    role: 'ADMIN',
    password: 'Quynh Trang',
    age: 0,
    condition: 'Quản trị hệ thống SOFT-EXO',
    affectedLeg: 'Cả hai chân',
    packageTier: 'SOFT-EXO Admin',
    registeredFeatures: ['Quản lý tài khoản', 'Liên kết chăm sóc', 'Cấu hình xác thực', 'Theo dõi trạng thái hệ thống'],
    hardwareDeviceId: '',
    registrationTimestamp: '15/08/2026, 08:00:00',
    status: 'Đã kích hoạt',
    notes: 'Tài khoản quản trị hệ thống',
  },
];

// Shared local user database so registrations from another phone/browser are
// visible to Admin and can be used to log in from any device on this server.
const USERS_FILE = path.join(DATA_DIR, 'users.json');

function hashPassword(password: string, salt = crypto.randomBytes(16).toString('hex')) {
  const passwordHash = crypto.scryptSync(password, salt, 64).toString('hex');
  return { passwordHash, passwordSalt: salt };
}

function verifyPassword(user: StoredUser, password: string): boolean {
  if (!user.passwordHash || !user.passwordSalt) return false;
  const derived = crypto.scryptSync(password, user.passwordSalt, 64);
  const stored = Buffer.from(user.passwordHash, 'hex');
  return stored.length === derived.length && crypto.timingSafeEqual(stored, derived);
}

function sanitizeUser(user: StoredUser) {
  const { password, passwordHash, passwordSalt, ...safe } = user;
  return safe;
}

function saveUsers() {
  try {
    fs.writeFileSync(USERS_FILE, JSON.stringify(masterUsers, null, 2), { mode: 0o600 });
  } catch (err) {
    console.warn('[USER DB] Could not save users:', err);
  }
}

function createFamilyInviteCode() {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let out = 'FAM-';
  for (let i = 0; i < 6; i += 1) out += alphabet[crypto.randomInt(0, alphabet.length)];
  return out;
}

function ensureUniqueFamilyInviteCode(user: StoredUser) {
  if (user.role !== 'PATIENT') return;
  if (user.familyInviteCode && !masterUsers.some(other => other.id !== user.id && other.familyInviteCode === user.familyInviteCode)) return;
  let code = createFamilyInviteCode();
  while (masterUsers.some(other => other.familyInviteCode === code)) code = createFamilyInviteCode();
  user.familyInviteCode = code;
}

function initializeUsers() {
  try {
    if (fs.existsSync(USERS_FILE)) {
      const saved = JSON.parse(fs.readFileSync(USERS_FILE, 'utf8')) as StoredUser[];
      if (Array.isArray(saved) && saved.length) {
        masterUsers.splice(0, masterUsers.length, ...saved);
      }
    }
  } catch (err) {
    console.warn('[USER DB] Could not load users, using seed data:', err);
  }

  // V7 production migration: remove legacy demo patient/doctor/caregiver accounts.
  // Real Railway data created by users is preserved. The bootstrap admin remains.
  const demoSeedIds = new Set(['user_01', 'doc_01', 'care_01']);
  const beforeDemoCleanup = masterUsers.length;
  for (let index = masterUsers.length - 1; index >= 0; index -= 1) {
    if (demoSeedIds.has(masterUsers[index].id)) masterUsers.splice(index, 1);
  }

  let changed = masterUsers.length !== beforeDemoCleanup;
  // Repair accounts created by the older V6 registration bug where a selected
  // caregiver was accidentally posted to the backend as PATIENT.
  for (const user of masterUsers) {
    const looksLikeLegacyCaregiver = user.role === 'PATIENT' && (
      user.packageTier === 'SOFT-EXO Family Care' ||
      user.condition === 'Người thân hỗ trợ phục hồi'
    );
    if (looksLikeLegacyCaregiver) {
      user.role = 'CAREGIVER';
      user.condition = 'Người thân hỗ trợ phục hồi';
      user.affectedLeg = 'Cả hai chân';
      user.hardwareDeviceId = '';
      user.familyInviteCode = undefined;
      changed = true;
    }
  }

  const bootstrapAdmin = masterUsers.find(user => user.id === 'usr_admin_01' && user.role === 'ADMIN');
  if (bootstrapAdmin) {
    if (bootstrapAdmin.hardwareDeviceId) { bootstrapAdmin.hardwareDeviceId = ''; changed = true; }
    if (bootstrapAdmin.location) { bootstrapAdmin.location = undefined; changed = true; }
    if (bootstrapAdmin.condition !== 'Quản trị hệ thống SOFT-EXO') { bootstrapAdmin.condition = 'Quản trị hệ thống SOFT-EXO'; changed = true; }
    if (bootstrapAdmin.packageTier !== 'SOFT-EXO Admin') { bootstrapAdmin.packageTier = 'SOFT-EXO Admin'; changed = true; }
    if (bootstrapAdmin.notes !== 'Tài khoản quản trị hệ thống') { bootstrapAdmin.notes = 'Tài khoản quản trị hệ thống'; changed = true; }
    bootstrapAdmin.registeredFeatures = ['Quản lý tài khoản', 'Liên kết chăm sóc', 'Cấu hình xác thực', 'Theo dõi trạng thái hệ thống'];
  }
  for (const user of masterUsers) {
    if (user.role === 'PATIENT' && !user.familyInviteCode) {
      ensureUniqueFamilyInviteCode(user);
      changed = true;
    }
    if (!user.passwordHash || !user.passwordSalt) {
      const originalPassword = user.password || 'password123';
      const secured = hashPassword(originalPassword);
      user.passwordHash = secured.passwordHash;
      user.passwordSalt = secured.passwordSalt;
      delete user.password;
      changed = true;
    }
  }
  if (changed || !fs.existsSync(USERS_FILE)) saveUsers();
}

initializeUsers();

// -----------------------------------------------------------------------------
// PERSISTENT TRAINING HISTORY
// Real progress is created only when a patient explicitly saves a training
// session. No demo session is generated automatically.
// -----------------------------------------------------------------------------
interface TrainingSessionRecord {
  id: string;
  userId: string;
  exerciseId: string;
  exerciseTitle: string;
  completedReps: number;
  targetReps: number;
  maxAngleAchieved: number;
  painLevel: number;
  durationSeconds: number;
  notes: string;
  createdAt: string;
  // V6 provenance metadata: makes every clinical-looking metric traceable.
  angleSource?: 'SENSOR' | 'NONE';
  painSource?: 'PATIENT_REPORTED';
  sensorCapturedAt?: string;
}

const TRAINING_SESSIONS_FILE = path.join(DATA_DIR, 'training-sessions.json');
function loadTrainingSessions(): TrainingSessionRecord[] {
  try {
    if (fs.existsSync(TRAINING_SESSIONS_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(TRAINING_SESSIONS_FILE, 'utf8'));
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (err) {
    console.warn('[PROGRESS] Could not load training sessions:', err);
  }
  return [];
}
let trainingSessions: TrainingSessionRecord[] = loadTrainingSessions();
function saveTrainingSessions() {
  fs.writeFileSync(TRAINING_SESSIONS_FILE, JSON.stringify(trainingSessions, null, 2), { mode: 0o600 });
}

// -----------------------------------------------------------------------------
// V6 FAMILY CO-REHAB
// A caregiver can explicitly confirm that they are physically present for a
// home exercise session. This is support context, not a clinical judgement.
// ----------------------------------------------------------------------------
interface CoRehabRecord {
  id: string;
  patientId: string;
  requestedByUserId: string;
  caregiverId?: string;
  caregiverName?: string;
  status: 'REQUESTED' | 'SUPPORTED' | 'COMPLETED' | 'CANCELLED';
  startedAt: string;
  joinedAt?: string;
  endedAt?: string;
  checklist?: { safeSpace?: boolean; deviceReady?: boolean; waterReady?: boolean };
  note?: string;
}

const CO_REHAB_FILE = path.join(DATA_DIR, 'co-rehab-sessions.json');
function loadCoRehabRecords(): CoRehabRecord[] {
  try {
    if (fs.existsSync(CO_REHAB_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(CO_REHAB_FILE, 'utf8'));
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (err) {
    console.warn('[CO-REHAB] Could not load sessions:', err);
  }
  return [];
}
let coRehabRecords: CoRehabRecord[] = loadCoRehabRecords();
function saveCoRehabRecords() {
  fs.writeFileSync(CO_REHAB_FILE, JSON.stringify(coRehabRecords, null, 2), { mode: 0o600 });
}

const APP_TIME_ZONE = 'Asia/Ho_Chi_Minh';

function dateKey(d: Date): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: APP_TIME_ZONE,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(d);
  const values = Object.fromEntries(parts.map(part => [part.type, part.value]));
  return `${values.year}-${values.month}-${values.day}`;
}

function dateKeyToUtcMidday(key: string): Date | null {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(key);
  if (!match) return null;
  return new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3]), 12, 0, 0));
}

function normalizedDateOnlyKey(value?: string): string | null {
  if (!value) return null;
  const exact = /^(\d{4})-(\d{2})-(\d{2})/.exec(value);
  if (exact) return `${exact[1]}-${exact[2]}-${exact[3]}`;
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : dateKey(parsed);
}

function addCalendarDays(key: string, amount: number): string {
  const base = dateKeyToUtcMidday(key);
  if (!base) return key;
  base.setUTCDate(base.getUTCDate() + amount);
  return base.toISOString().slice(0, 10);
}

function calendarDayDiff(fromKey: string, toKey: string): number {
  const from = dateKeyToUtcMidday(fromKey);
  const to = dateKeyToUtcMidday(toKey);
  if (!from || !to) return 0;
  return Math.floor((to.getTime() - from.getTime()) / 86400000);
}

function buildProgressSummary(patient: StoredUser) {
  const sessions = trainingSessions
    .filter(item => item.userId === patient.id)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const todayKey = dateKey(new Date());
  const startKey = normalizedDateOnlyKey(patient.recoveryStartDate || patient.surgeryDate);
  const recoveryDay = startKey
    ? Math.max(1, calendarDayDiff(startKey, todayKey) + 1)
    : 0;

  const uniqueTrainingDays = new Set(sessions.map(item => dateKey(new Date(item.createdAt))));
  const todaySessions = sessions.filter(item => dateKey(new Date(item.createdAt)) === todayKey);

  const sevenDay = Array.from({ length: 7 }, (_, idx) => {
    const key = addCalendarDays(todayKey, -(6 - idx));
    const labelDate = dateKeyToUtcMidday(key) || new Date();
    const items = sessions.filter(item => dateKey(new Date(item.createdAt)) === key);
    return {
      date: key,
      label: labelDate.toLocaleDateString('vi-VN', { weekday: 'short', timeZone: APP_TIME_ZONE }),
      maxAngle: items.length ? Math.max(...items.map(item => Number(item.maxAngleAchieved) || 0)) : 0,
      sessions: items.length,
      reps: items.reduce((sum, item) => sum + (Number(item.completedReps) || 0), 0),
      durationMinutes: Math.round(items.reduce((sum, item) => sum + (Number(item.durationSeconds) || 0), 0) / 60),
      painLevel: items.length ? items[0].painLevel : null,
    };
  });

  const totalDurationSeconds = sessions.reduce((sum, item) => sum + (Number(item.durationSeconds) || 0), 0);
  const todayDurationSeconds = todaySessions.reduce((sum, item) => sum + (Number(item.durationSeconds) || 0), 0);

  return {
    patient: sanitizeUser(patient),
    todayDate: todayKey,
    recoveryDay,
    trainingDay: uniqueTrainingDays.size,
    totalSessions: sessions.length,
    totalReps: sessions.reduce((sum, item) => sum + (Number(item.completedReps) || 0), 0),
    totalMinutes: Math.round(totalDurationSeconds / 60),
    todaySessions: todaySessions.length,
    todayExercises: new Set(todaySessions.map(item => item.exerciseId)).size,
    todayMinutes: Math.round(todayDurationSeconds / 60),
    activeDaysLast7: sevenDay.filter(item => item.sessions > 0).length,
    lastSessionAt: sessions[0]?.createdAt || null,
    maxAngle: sessions.length ? Math.max(...sessions.map(item => Number(item.maxAngleAchieved) || 0)) : 0,
    latestPainLevel: sessions.length ? sessions[0].painLevel : null,
    sevenDay,
    recentSessions: sessions.slice(0, 12),
  };
}

function resolveProgressPatient(session: SessionPayload, requestedPatientId?: string): StoredUser | null {
  const actor = masterUsers.find(user => user.id === session.userId);
  if (!actor) return null;
  if (actor.role === 'PATIENT') return actor;
  if (actor.role === 'CAREGIVER') {
    return actor.linkedPatientId ? masterUsers.find(user => user.id === actor.linkedPatientId && user.role === 'PATIENT' && user.shareWithCaregiver === true) || null : null;
  }
  if (actor.role === 'DOCTOR') {
    const id = requestedPatientId || '';
    return masterUsers.find(user => user.id === id && user.role === 'PATIENT' && user.doctorId === actor.id && user.shareWithDoctor === true) || null;
  }
  if (actor.role === 'ADMIN') {
    const id = requestedPatientId || '';
    return masterUsers.find(user => user.id === id && user.role === 'PATIENT') || null;
  }
  return null;
}

// OTP Audit logs contain only real delivery attempts made during this server session.
const otpLogs: OtpLog[] = [];

// Active Telemetry state
let liveTelemetry = {
  // No device packet = no measurement. Keep every sensor-facing value at 0
  // until the backend receives real telemetry from ESP32/MPU6050.
  kneeAngle: 0,
  thighPitch: 0,
  shinPitch: 0,
  roll: 0,
  yaw: 0,
  accelX: 0,
  accelY: 0,
  accelZ: 0,
  gForceMagnitude: 0,
  isCalibrated: false,
  isFallDetected: false,
  fallImpactG: 0,
  activityState: 'Chưa kết nối thiết bị',
  batteryLevel: 0,
  signalRssi: 0,
  samplingRateHz: 0,
  isConnected: false,
  source: 'waiting',
  deviceCode: '',
  lastUpdated: new Date().toISOString(),
};

// -----------------------------------------------------------------------------
// REAL-TIME HARDWARE BRIDGE
// ESP32-S3 + MPU6050 -> UDP :5005 -> server -> SSE -> every open app.
// Supported UDP examples:
//   IMU,X,45.2,Y,1.4
//   Goc_Goi:45.2,Pitch:12.0,Roll:1.4,G:1.02,Bat:88
//   {"kneeAngle":45.2,"roll":1.4,"gForceMagnitude":1.02,"batteryLevel":88}
// -----------------------------------------------------------------------------
const UDP_PORT = 5005;
const udpSocket = dgram.createSocket('udp4');
let lastHardwarePacketAt = 0;
let lastEsp32Remote: { address: string; port: number } | null = null;
let previousSafetySample = { angle: 0, at: Date.now() };
let lastSafetyAlertAt = 0;

const telemetrySseClients = new Set<any>();
const alertSseClients = new Set<any>();
const sosHistory: any[] = [];

function sendSse(client: any, event: string, data: any) {
  try {
    client.write(`event: ${event}\n`);
    client.write(`data: ${JSON.stringify(data)}\n\n`);
  } catch {}
}

function broadcastSse(clients: Set<any>, event: string, data: any) {
  for (const client of clients) sendSse(client, event, data);
}

function clampNumber(value: any, min: number, max: number, fallback: number) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.max(min, Math.min(max, n)) : fallback;
}

function normalizeKey(key: string) {
  return key.trim().toLowerCase().replace(/[\s_-]+/g, '');
}

function parseHardwarePacket(raw: string): Record<string, any> | null {
  const text = raw.trim();
  if (!text) return null;

  // JSON packet
  if (text.startsWith('{')) {
    try { return JSON.parse(text); } catch {}
  }

  // IMU,X,45.2,Y,1.4 style
  const csv = text.split(',').map(v => v.trim());
  if (csv.length >= 3 && csv[0].toUpperCase() === 'IMU') {
    const out: Record<string, any> = {};
    for (let i = 1; i + 1 < csv.length; i += 2) out[csv[i]] = csv[i + 1];
    return out;
  }

  // key:value comma-separated packets
  const out: Record<string, any> = {};
  for (const part of text.split(/[;,]/)) {
    const idx = part.indexOf(':');
    if (idx > 0) out[part.slice(0, idx).trim()] = part.slice(idx + 1).trim().replace(/[^0-9+-.]/g, '');
  }
  return Object.keys(out).length ? out : null;
}

function findField(obj: Record<string, any>, aliases: string[]) {
  const normalized = new Map(Object.entries(obj).map(([k, v]) => [normalizeKey(k), v]));
  for (const alias of aliases) {
    const value = normalized.get(normalizeKey(alias));
    if (value !== undefined) return value;
  }
  return undefined;
}

function commandEsp32(command: string) {
  if (!lastEsp32Remote) return;
  const payload = Buffer.from(command);
  udpSocket.send(payload, lastEsp32Remote.port, lastEsp32Remote.address, () => {});
}

function raiseSafetyAlert(reason: string, severity: 'warning' | 'danger', impactG: number) {
  const now = Date.now();
  if (now - lastSafetyAlertAt < 8000 && liveTelemetry.isFallDetected) return;
  lastSafetyAlertAt = now;
  liveTelemetry.isFallDetected = true;
  liveTelemetry.fallImpactG = impactG;
  liveTelemetry.activityState = reason;

  const activeDeviceCode = String((liveTelemetry as any).deviceCode || '').trim();
  const deviceLink = activeDeviceCode ? deviceLinks.find(link => link.productCode === activeDeviceCode) : null;
  const patient = deviceLink ? masterUsers.find(user => user.id === deviceLink.userId) : masterUsers.find(user => user.role === 'PATIENT');
  const patientLocation = patient?.location?.formattedAddress || patient?.location?.city || 'Đang cập nhật vị trí';

  const alert = {
    id: `sos_${now}`,
    type: severity === 'danger' ? 'FALL_DETECTED' : 'UNSAFE_MOVEMENT',
    severity: severity === 'danger' ? 'DANGER' : 'WARNING',
    title: severity === 'danger' ? 'Cảnh báo va đập / té ngã' : 'Cảnh báo chuyển động chưa an toàn',
    message: reason,
    impactG,
    kneeAngle: liveTelemetry.kneeAngle,
    deviceCode: activeDeviceCode || undefined,
    patientId: patient?.id || undefined,
    patientName: patient?.fullName || 'Người bệnh SOFT-EXO',
    location: patientLocation,
    timestamp: new Date().toISOString(),
    status: 'ACTIVE',
  };
  sosHistory.unshift(alert);
  if (sosHistory.length > 100) sosHistory.length = 100;

  // Optional ESP32 buzzer/haptic command. Firmware can listen for this UDP command.
  commandEsp32(severity === 'danger' ? 'ALARM,ON,DANGER' : 'ALARM,ON,WARNING');
  broadcastSse(alertSseClients, 'sos', alert);
  broadcastSse(telemetrySseClients, 'telemetry', liveTelemetry);
  void sendSafetyWebPush(alert);
  console.log(`[SOS] ${alert.title}: ${reason}`);
}

function evaluateHardwareSafety() {
  const now = Date.now();
  const dt = Math.max(1, now - previousSafetySample.at);
  const deltaAngle = Math.abs(liveTelemetry.kneeAngle - previousSafetySample.angle);
  const fastAngleChange = dt < 350 && deltaAngle > 55;
  previousSafetySample = { angle: liveTelemetry.kneeAngle, at: now };

  if (liveTelemetry.gForceMagnitude >= 2.5) {
    raiseSafetyAlert(`Phát hiện va đập mạnh ${liveTelemetry.gForceMagnitude.toFixed(2)}G. Đã gửi cảnh báo tới người thân.`, 'danger', liveTelemetry.gForceMagnitude);
  } else if (liveTelemetry.kneeAngle > 138 || fastAngleChange) {
    raiseSafetyAlert('Phát hiện chuyển động vượt ngưỡng an toàn. Vui lòng dừng lại và kiểm tra tư thế.', 'warning', liveTelemetry.gForceMagnitude);
  }
}

function applyHardwareTelemetry(packet: Record<string, any>, raw: string) {
  const x = findField(packet, ['X', 'angleX']);
  const thigh = findField(packet, ['thighPitch', 'thigh', 'upperPitch']);
  const shin = findField(packet, ['shinPitch', 'shin', 'lowerPitch', 'Pitch']);
  const explicitAngle = findField(packet, ['kneeAngle', 'angle', 'Goc_Goi', 'gocgoi']);

  let computedAngle: number;
  if (explicitAngle !== undefined) {
    computedAngle = Math.abs(Number(explicitAngle));
  } else if (thigh !== undefined && shin !== undefined) {
    computedAngle = Math.abs(Number(thigh) - Number(shin));
  } else if (x !== undefined) {
    computedAngle = Math.abs(Number(x));
  } else {
    computedAngle = liveTelemetry.kneeAngle;
  }

  const ax = findField(packet, ['accelX', 'ax']);
  const ay = findField(packet, ['accelY', 'ay']);
  const az = findField(packet, ['accelZ', 'az']);
  let gForce = findField(packet, ['gForceMagnitude', 'gForce', 'G']);
  if (gForce === undefined && ax !== undefined && ay !== undefined && az !== undefined) {
    gForce = Math.sqrt(Number(ax) ** 2 + Number(ay) ** 2 + Number(az) ** 2);
  }

  liveTelemetry = {
    ...liveTelemetry,
    kneeAngle: clampNumber(computedAngle, 0, 150, liveTelemetry.kneeAngle),
    thighPitch: clampNumber(thigh, -180, 180, liveTelemetry.thighPitch),
    shinPitch: clampNumber(shin ?? x, -180, 180, liveTelemetry.shinPitch),
    roll: clampNumber(findField(packet, ['roll', 'Y']), -180, 180, liveTelemetry.roll),
    yaw: clampNumber(findField(packet, ['yaw', 'Z']), -180, 180, liveTelemetry.yaw),
    accelX: clampNumber(ax, -20, 20, liveTelemetry.accelX),
    accelY: clampNumber(ay, -20, 20, liveTelemetry.accelY),
    accelZ: clampNumber(az, -20, 20, liveTelemetry.accelZ),
    gForceMagnitude: clampNumber(gForce, 0, 20, liveTelemetry.gForceMagnitude),
    batteryLevel: clampNumber(findField(packet, ['batteryLevel', 'battery', 'Bat']), 0, 100, liveTelemetry.batteryLevel),
    signalRssi: clampNumber(findField(packet, ['signalRssi', 'rssi']), -120, 0, liveTelemetry.signalRssi),
    samplingRateHz: clampNumber(findField(packet, ['samplingRateHz', 'hz']), 1, 200, liveTelemetry.samplingRateHz),
    isConnected: true,
    source: 'ESP32-S3 + MPU6050',
    deviceCode: String(findField(packet, ['deviceCode', 'deviceId', 'productCode']) || (liveTelemetry as any).deviceCode || ''),
    activityState: 'Đang đồng bộ chuyển động thật từ thiết bị',
    rawPacket: raw,
    lastUpdated: new Date().toISOString(),
  } as any;

  lastHardwarePacketAt = Date.now();
  evaluateHardwareSafety();
  broadcastSse(telemetrySseClients, 'telemetry', liveTelemetry);
}

udpSocket.on('message', (msg, rinfo) => {
  lastEsp32Remote = { address: rinfo.address, port: rinfo.port };
  const raw = msg.toString('utf8').trim();
  const parsed = parseHardwarePacket(raw);
  if (parsed) applyHardwareTelemetry(parsed, raw);
});
udpSocket.on('error', err => console.warn('[UDP 5005]', err.message));
udpSocket.bind(UDP_PORT, '0.0.0.0', () => {
  console.log(`ESP32/MPU6050 UDP receiver listening on 0.0.0.0:${UDP_PORT}`);
});

setInterval(() => {
  if (liveTelemetry.isConnected && Date.now() - lastHardwarePacketAt > 3500) {
    // Hardware stream stopped: clear stale measurements immediately so the UI
    // never keeps showing an old angle/battery/signal value as if it were live.
    liveTelemetry = {
      ...liveTelemetry,
      kneeAngle: 0,
      thighPitch: 0,
      shinPitch: 0,
      roll: 0,
      yaw: 0,
      accelX: 0,
      accelY: 0,
      accelZ: 0,
      gForceMagnitude: 0,
      isCalibrated: false,
      isFallDetected: false,
      fallImpactG: 0,
      batteryLevel: 0,
      signalRssi: 0,
      samplingRateHz: 0,
      isConnected: false,
      source: 'offline',
      activityState: 'Chưa kết nối thiết bị',
      rawPacket: '',
      lastUpdated: new Date().toISOString(),
    } as any;
    previousSafetySample = { angle: 0, at: Date.now() };
    broadcastSse(telemetrySseClients, 'telemetry', liveTelemetry);
  }
}, 1000);

// Lazy-initialized Gemini AI Client
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  }
  return aiClient;
}

// -----------------------------------------------------------------------------
// REST API ROUTES
// -----------------------------------------------------------------------------

// 1. Health check & System Info
app.get('/api/network-info', (req, res) => {
  const interfaces = os.networkInterfaces() as Record<string, Array<{ family: string; internal: boolean; address: string }> | undefined>;
  let lanIp = '';
  for (const entries of Object.values(interfaces)) {
    for (const entry of entries || []) {
      if (entry.family === 'IPv4' && !entry.internal) {
        lanIp = entry.address;
        break;
      }
    }
    if (lanIp) break;
  }

  const forwardedProto = String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim();
  const protocol = forwardedProto || req.protocol || 'http';
  const host = req.get('host');
  const requestPublicUrl = host ? `${protocol}://${host}` : '';
  const publicUrl = String(process.env.PUBLIC_URL || requestPublicUrl).replace(/\/$/, '');
  const localUrl = `http://localhost:${PORT}`;

  res.json({
    port: PORT,
    lanIp,
    publicUrl,
    networkUrl: publicUrl || (lanIp ? `http://${lanIp}:${PORT}` : localUrl),
    localUrl,
  });
});

app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    system: 'SOFT-EXO AI & Digital Twin Full-Stack Server',
    timestamp: new Date().toISOString(),
    geminiConfigured: Boolean(process.env.GEMINI_API_KEY),
    emailOtpConfigured: Boolean(decryptLocalSecret(emailOtpSettings.apiKeyEncrypted) && emailOtpSettings.senderEmail),
    totalUsers: masterUsers.length,
    onlineDevices: liveTelemetry.isConnected ? 1 : 0,
    activeAlerts: liveTelemetry.isFallDetected ? 1 : 0
  });
});

// 2. Administrator Overview (Dashboard Data)
app.get('/api/admin/overview', requireAdmin, (req, res) => {
  res.json({
    metrics: {
      totalRegisteredUsers: masterUsers.length,
      patientsCount: masterUsers.filter(u => u.role === 'PATIENT').length,
      doctorsCount: masterUsers.filter(u => u.role === 'DOCTOR').length,
      caregiversCount: masterUsers.filter(u => u.role === 'CAREGIVER').length,
      adminCount: masterUsers.filter(u => u.role === 'ADMIN').length,
      activeDevices: liveTelemetry.isConnected ? 1 : 0,
      totalOtpDispatched: otpLogs.length,
      successfulVerifications: otpLogs.filter(o => o.status === 'verified').length,
      linkedPatientsCount: masterUsers.filter(u => u.role === 'PATIENT' && (Boolean(u.caregiverName) || masterUsers.some(c => c.role === 'CAREGIVER' && c.linkedPatientId === u.id))).length,
      deviceLinkedPatients: masterUsers.filter(u => u.role === 'PATIENT' && Boolean(u.hardwareDeviceId)).length,
      activeAlerts: liveTelemetry.isFallDetected ? 1 : 0,
    },
    users: masterUsers.map(sanitizeUser),
    otpAuditTrail: otpLogs.slice(-20).reverse(),
    liveTelemetry,
    serverTimestamp: new Date().toISOString()
  });
});

// 3. Get / Manage All Users
app.get('/api/users', requireAdmin, (req, res) => {
  res.json({
    success: true,
    count: masterUsers.length,
    users: masterUsers.map(sanitizeUser)
  });
});

app.post('/api/users', (req, res) => {
  const phone = (req.body.phone || '').trim();
  const email = (req.body.email || '').trim().toLowerCase();
  const cleanPhone = phone.replace(/[\s.-]/g, '');

  const registrationOtp = activeOtpSecrets.get(otpKey(email, 'register'));
  if (!email || !registrationOtp || !registrationOtp.verified || Date.now() > registrationOtp.expiresAt + 10 * 60 * 1000) {
    return res.status(403).json({ error: 'Cần xác thực Email OTP hợp lệ trước khi tạo tài khoản.' });
  }

  const isPhoneTaken = cleanPhone && masterUsers.some(u => u.phone && u.phone.replace(/[\s.-]/g, '') === cleanPhone);
  const isEmailTaken = email && masterUsers.some(u => u.email && u.email.toLowerCase() === email);

  if (isPhoneTaken) {
    return res.status(400).json({
      error: 'Số điện thoại này đã được đăng ký trên hệ thống. Vui lòng đăng nhập hoặc chọn Quên mật khẩu.'
    });
  }
  if (isEmailTaken) {
    return res.status(400).json({
      error: 'Địa chỉ Gmail này đã được đăng ký trên hệ thống. Vui lòng đăng nhập hoặc chọn Quên mật khẩu.'
    });
  }

  const rawPassword = String(req.body.password || '');
  if (rawPassword.length < 6) {
    return res.status(400).json({ error: 'Mật khẩu phải có tối thiểu 6 ký tự.' });
  }
  const securedPassword = hashPassword(rawPassword);

  const requestedRole = String(req.body.role || 'PATIENT').toUpperCase();
  const publicRole = requestedRole === 'CAREGIVER' ? 'CAREGIVER' : 'PATIENT';
  const newUser: StoredUser = {
    id: req.body.id || `usr_${Date.now()}`,
    fullName: req.body.fullName || 'Người dùng mới',
    phone: phone,
    email: email,
    // Public self-registration is limited to the two consumer roles.
    // Doctor/Admin accounts remain approval-controlled.
    role: publicRole,
    passwordHash: securedPassword.passwordHash,
    passwordSalt: securedPassword.passwordSalt,
    age: Number(req.body.age) || 0,
    condition: publicRole === 'PATIENT' ? (req.body.condition || 'Phục hồi chức năng khớp gối') : 'Người thân hỗ trợ phục hồi',
    affectedLeg: publicRole === 'PATIENT' ? (req.body.affectedLeg || 'Chân Phải') : 'Cả hai chân',
    packageTier: publicRole === 'PATIENT' ? (req.body.packageTier || 'SOFT-EXO Patient') : 'SOFT-EXO Family Care',
    registeredFeatures: req.body.registeredFeatures || (publicRole === 'PATIENT'
      ? ['Theo dõi phục hồi', 'Bài tập tại nhà', 'Cảnh báo an toàn']
      : ['Theo dõi người thân', 'Tiến độ tập luyện', 'Cảnh báo SOS']),
    hardwareDeviceId: publicRole === 'PATIENT' ? String(req.body.hardwareDeviceId || '') : '',
    registrationTimestamp: req.body.registrationTimestamp || new Date().toLocaleString('vi-VN'),
    status: 'Đã kích hoạt',
    notes: req.body.notes || 'Đăng ký qua Email OTP thật',
    facilityName: String(req.body.facilityName || req.body.doctorHospital || '').trim(),
    facilityCode: String(req.body.facilityCode || '').trim().toUpperCase(),
    department: String(req.body.department || '').trim(),
    medicalRecordCode: String(req.body.medicalRecordCode || '').trim(),
    relationship: publicRole === 'CAREGIVER' ? String(req.body.relationship || 'Người thân').trim() : undefined,
    shareWithDoctor: publicRole === 'PATIENT' ? Boolean(req.body.shareWithDoctor) : undefined,
    shareWithCaregiver: publicRole === 'PATIENT' ? true : undefined,
    shareLocationOnSos: publicRole === 'PATIENT' ? Boolean(req.body.shareLocationOnSos) : undefined,
    location: req.body.location
  };

  if (newUser.role === 'PATIENT') ensureUniqueFamilyInviteCode(newUser);

  // A caregiver can optionally link during registration using the patient's invite code.
  const requestedInviteCode = String(req.body.patientInviteCode || '').trim().toUpperCase();
  if (newUser.role === 'CAREGIVER' && requestedInviteCode) {
    const patient = masterUsers.find(u => u.role === 'PATIENT' && String(u.familyInviteCode || '').toUpperCase() === requestedInviteCode);
    if (patient) {
      newUser.linkedPatientId = patient.id;
      newUser.linkedAt = new Date().toISOString();
      patient.caregiverName = newUser.fullName;
      patient.caregiverPhone = newUser.phone;
      patient.shareWithCaregiver = true;
    }
  }

  masterUsers.push(newUser);
  activeOtpSecrets.delete(otpKey(email, 'register'));
  saveUsers();
  const token = createSessionToken(newUser.id, newUser.role);
  res.status(201).json({ success: true, user: sanitizeUser(newUser), token, expiresInSeconds: 24 * 60 * 60 });
});

app.post('/api/admin/accounts', requireAdmin, (req, res) => {
  const role = String(req.body.role || '').toUpperCase();
  if (!['DOCTOR', 'CAREGIVER'].includes(role)) {
    return res.status(400).json({ error: 'Admin chỉ có thể tạo tài khoản Bác sĩ hoặc Người thân tại đây.' });
  }

  const fullName = String(req.body.fullName || '').trim();
  const email = normalizeEmail(String(req.body.email || ''));
  const phone = String(req.body.phone || '').trim();
  const cleanPhone = phone.replace(/[\s.-]/g, '');
  const password = String(req.body.password || '');
  if (fullName.length < 3) return res.status(400).json({ error: 'Họ tên phải có ít nhất 3 ký tự.' });
  if (!isValidEmailAddress(email)) return res.status(400).json({ error: 'Email không hợp lệ.' });
  if (cleanPhone.length < 9) return res.status(400).json({ error: 'Số điện thoại không hợp lệ.' });
  if (password.length < 8) return res.status(400).json({ error: 'Mật khẩu ban đầu phải có ít nhất 8 ký tự.' });
  if (masterUsers.some(user => normalizeEmail(user.email) === email)) return res.status(409).json({ error: 'Email này đã có tài khoản.' });
  if (masterUsers.some(user => String(user.phone || '').replace(/[\s.-]/g, '') === cleanPhone)) return res.status(409).json({ error: 'Số điện thoại này đã có tài khoản.' });

  const secured = hashPassword(password);
  const account: StoredUser = {
    id: `${role === 'DOCTOR' ? 'doc' : 'care'}_${Date.now()}_${crypto.randomBytes(2).toString('hex')}`,
    fullName,
    phone,
    email,
    role,
    passwordHash: secured.passwordHash,
    passwordSalt: secured.passwordSalt,
    age: 0,
    condition: role === 'DOCTOR' ? 'Tài khoản bác sĩ đã được Admin phê duyệt' : 'Tài khoản người thân đã được Admin phê duyệt',
    affectedLeg: 'Cả hai chân',
    packageTier: role === 'DOCTOR' ? 'Doctor' : 'Family Care',
    registeredFeatures: [],
    hardwareDeviceId: '',
    registrationTimestamp: new Date().toISOString(),
    status: 'Đã kích hoạt',
    notes: 'Tài khoản được tạo thủ công bởi Admin',
    adminApprovedAt: new Date().toISOString(),
  };
  masterUsers.push(account);
  saveUsers();
  return res.status(201).json({ success: true, user: sanitizeUser(account), users: masterUsers.map(sanitizeUser) });
});

app.patch('/api/admin/patients/:id/links', requireAdmin, (req, res) => {
  const patient = masterUsers.find(user => user.id === req.params.id && user.role === 'PATIENT');
  if (!patient) return res.status(404).json({ error: 'Không tìm thấy người bệnh.' });

  if (Object.prototype.hasOwnProperty.call(req.body, 'doctorId')) {
    const doctorId = String(req.body.doctorId || '').trim();
    if (doctorId) {
      const doctor = masterUsers.find(user => user.id === doctorId && user.role === 'DOCTOR');
      if (!doctor) return res.status(400).json({ error: 'Tài khoản bác sĩ không hợp lệ.' });
      patient.doctorId = doctor.id;
      patient.doctorName = doctor.fullName;
    } else {
      patient.doctorId = undefined;
      patient.doctorName = '';
    }
  }

  if (Object.prototype.hasOwnProperty.call(req.body, 'caregiverId')) {
    const caregiverId = String(req.body.caregiverId || '').trim();
    for (const caregiver of masterUsers.filter(user => user.role === 'CAREGIVER' && user.linkedPatientId === patient.id)) {
      caregiver.linkedPatientId = undefined;
    }
    if (caregiverId) {
      const caregiver = masterUsers.find(user => user.id === caregiverId && user.role === 'CAREGIVER');
      if (!caregiver) return res.status(400).json({ error: 'Tài khoản người thân không hợp lệ.' });
      caregiver.linkedPatientId = patient.id;
      patient.caregiverName = caregiver.fullName;
      patient.caregiverPhone = caregiver.phone;
    } else {
      patient.caregiverName = '';
      patient.caregiverPhone = '';
    }
  }

  saveUsers();
  return res.json({ success: true, patient: sanitizeUser(patient), users: masterUsers.map(sanitizeUser) });
});

app.delete('/api/users/:id', requireAdmin, (req, res) => {
  const { id } = req.params;
  const index = masterUsers.findIndex(u => u.id === id);
  if (index !== -1) {
    const deleted = masterUsers.splice(index, 1);
    saveUsers();
    return res.json({ success: true, deletedUser: sanitizeUser(deleted[0]) });
  }
  return res.status(404).json({ error: 'User not found' });
});

// 4. Email OTP configuration for Admin (Brevo)
app.get('/api/admin/email-otp/settings', requireAdmin, (req, res) => {
  const apiKey = decryptLocalSecret(emailOtpSettings.apiKeyEncrypted);
  res.json({
    configured: Boolean(apiKey && emailOtpSettings.senderEmail),
    apiKeyMasked: maskApiKey(apiKey),
    senderEmail: emailOtpSettings.senderEmail,
    senderName: emailOtpSettings.senderName || 'SOFT-EXO Family Care',
    provider: 'Brevo Transactional Email',
  });
});

app.post('/api/admin/email-otp/settings', requireAdmin, async (req, res) => {
  try {
    const apiKey = String(req.body.apiKey || '').trim();
    const senderEmail = normalizeEmail(String(req.body.senderEmail || ''));
    const senderName = String(req.body.senderName || 'SOFT-EXO Family Care').trim();

    if (!senderEmail || !isValidEmailAddress(senderEmail)) {
      return res.status(400).json({ error: 'Email người gửi không hợp lệ.' });
    }

    const currentApiKey = decryptLocalSecret(emailOtpSettings.apiKeyEncrypted);
    const effectiveApiKey = apiKey || currentApiKey;
    if (!effectiveApiKey) {
      return res.status(400).json({ error: 'Vui lòng nhập Brevo API Key.' });
    }

    await validateBrevoApiKey(effectiveApiKey);
    emailOtpSettings = {
      apiKeyEncrypted: encryptLocalSecret(effectiveApiKey),
      senderEmail,
      senderName: senderName || 'SOFT-EXO Family Care',
    };
    fs.writeFileSync(OTP_SETTINGS_FILE, JSON.stringify(emailOtpSettings, null, 2), { mode: 0o600 });

    return res.json({
      success: true,
      configured: true,
      apiKeyMasked: maskApiKey(effectiveApiKey),
      senderEmail,
      senderName: emailOtpSettings.senderName,
      message: 'Đã lưu và xác thực Brevo API Key thành công.',
    });
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Không thể xác thực cấu hình Brevo.' });
  }
});

app.post('/api/admin/email-otp/test', requireAdmin, async (req, res) => {
  const target = normalizeEmail(String(req.body.target || ''));
  if (!isValidEmailAddress(target)) {
    return res.status(400).json({ error: 'Email nhận thử không hợp lệ.' });
  }
  try {
    const code = crypto.randomInt(100000, 1000000).toString();
    await sendBrevoOtpEmail(target, code, 'test', 'Admin Test');
    return res.json({ success: true, message: `Đã gửi OTP thử tới ${target}. Hãy kiểm tra Inbox/Spam.` });
  } catch (err: any) {
    return res.status(502).json({ error: err?.message || 'Gửi email thử thất bại.' });
  }
});

app.get('/api/auth/otp-status', (req, res) => {
  const apiKey = decryptLocalSecret(emailOtpSettings.apiKeyEncrypted);
  res.json({ email: Boolean(apiKey && emailOtpSettings.senderEmail), sms: false, provider: 'Brevo' });
});

// 5. Send REAL OTP by Email. SMS is intentionally disabled in this build.
app.post('/api/auth/send-otp', async (req, res) => {
  const target = normalizeEmail(String(req.body.target || ''));
  const purpose = (req.body.purpose || 'register') as 'register' | 'forgot_password' | 'login';
  const fullName = String(req.body.fullName || '').trim();
  const channel = String(req.body.channel || 'email');

  if (channel !== 'email') {
    return res.status(400).json({ error: 'Bản này sử dụng Email OTP thật. SMS OTP đã được tắt.' });
  }
  if (!isValidEmailAddress(target)) {
    return res.status(400).json({ error: 'Địa chỉ email nhận OTP không hợp lệ.' });
  }

  if (purpose === 'register') {
    const duplicate = masterUsers.some(u => u.email && u.email.toLowerCase() === target);
    if (duplicate) {
      return res.status(409).json({ error: 'Email này đã có tài khoản. Vui lòng đăng nhập hoặc dùng email khác.' });
    }
  }
  if (purpose === 'forgot_password') {
    const existing = masterUsers.some(u => u.email && u.email.toLowerCase() === target);
    if (!existing) {
      return res.status(404).json({ error: 'Không tìm thấy tài khoản gắn với email này.' });
    }
  }

  const apiKey = decryptLocalSecret(emailOtpSettings.apiKeyEncrypted);
  if (!apiKey || !emailOtpSettings.senderEmail) {
    return res.status(503).json({
      error: 'Email OTP thật chưa được cấu hình. Admin vào Cổng quản trị → Email OTP để nhập Brevo API Key và email người gửi.'
    });
  }

  const key = otpKey(target, purpose);
  const now = Date.now();
  const lastSent = otpLastSentAt.get(key) || 0;
  if (now - lastSent < 30000) {
    const wait = Math.ceil((30000 - (now - lastSent)) / 1000);
    return res.status(429).json({ error: `Vui lòng chờ ${wait} giây trước khi yêu cầu mã mới.` });
  }

  const code = crypto.randomInt(100000, 1000000).toString();
  const salt = crypto.randomBytes(16).toString('hex');
  try {
    await sendBrevoOtpEmail(target, code, purpose, fullName);
  } catch (err: any) {
    console.error('[REAL EMAIL OTP SEND ERROR]', err);
    return res.status(502).json({ error: err?.message || 'Không thể gửi OTP qua email.' });
  }

  activeOtpSecrets.set(key, {
    target,
    purpose,
    salt,
    hash: hashOtp(code, salt),
    createdAt: now,
    expiresAt: now + 5 * 60 * 1000,
    attempts: 0,
    verified: false,
  });
  otpLastSentAt.set(key, now);

  const logEntry: OtpLog = {
    id: `otp_${Date.now()}`,
    target,
    channel: 'email',
    code: '••••••',
    carrier: 'Brevo Transactional Email',
    status: 'sent',
    createdAt: new Date().toISOString(),
  };
  otpLogs.push(logEntry);

  console.log(`[REAL EMAIL OTP] ${purpose} -> ${target} via Brevo`);
  return res.json({
    success: true,
    message: `Đã gửi mã OTP thật tới ${target}. Hãy kiểm tra Inbox hoặc Spam.`,
    target,
    channel: 'email',
    validForSeconds: 300,
    carrier: 'Brevo Transactional Email',
  });
});

// 6. Verify REAL one-time OTP
app.post('/api/auth/verify-otp', (req, res) => {
  const target = normalizeEmail(String(req.body.target || ''));
  const code = String(req.body.code || '').trim();
  const requestedPurpose = String(req.body.purpose || 'register');

  if (!isValidEmailAddress(target) || !/^\d{6}$/.test(code)) {
    return res.status(400).json({ success: false, verified: false, error: 'Email hoặc mã OTP không hợp lệ.' });
  }

  let key = otpKey(target, requestedPurpose);
  let record = activeOtpSecrets.get(key);
  if (!record) {
    for (const purpose of ['register', 'forgot_password', 'login'] as const) {
      const candidateKey = otpKey(target, purpose);
      const candidate = activeOtpSecrets.get(candidateKey);
      if (candidate) {
        key = candidateKey;
        record = candidate;
        break;
      }
    }
  }

  if (!record) {
    return res.status(400).json({ success: false, verified: false, error: 'Không tìm thấy yêu cầu OTP còn hiệu lực. Vui lòng gửi mã mới.' });
  }
  if (record.verified) {
    return res.status(400).json({ success: false, verified: false, error: 'Mã OTP này đã được sử dụng.' });
  }
  if (Date.now() > record.expiresAt) {
    return res.status(400).json({ success: false, verified: false, error: 'Mã OTP đã hết hạn. Vui lòng gửi mã mới.' });
  }
  if (record.attempts >= 5) {
    return res.status(429).json({ success: false, verified: false, error: 'Bạn đã nhập sai quá số lần cho phép. Vui lòng gửi mã mới.' });
  }

  record.attempts += 1;
  const candidateHash = hashOtp(code, record.salt);
  const a = Buffer.from(candidateHash, 'hex');
  const b = Buffer.from(record.hash, 'hex');
  const ok = a.length === b.length && crypto.timingSafeEqual(a, b);
  if (!ok) {
    return res.status(400).json({ success: false, verified: false, error: `Mã OTP không chính xác. Còn ${Math.max(0, 5 - record.attempts)} lần thử.` });
  }

  record.verified = true;
  const matchedLog = otpLogs.slice().reverse().find(l => normalizeEmail(l.target) === target && l.status === 'sent');
  if (matchedLog) {
    matchedLog.status = 'verified';
    matchedLog.verifiedAt = new Date().toISOString();
  }

  return res.json({ success: true, verified: true, message: `Xác thực email ${target} thành công.` });
});

// 5b. Reset Password API (For Forgot Password Workflow)
app.post('/api/auth/reset-password', (req, res) => {
  const { target, code, newPassword } = req.body;
  if (!target || !newPassword) {
    return res.status(400).json({ error: 'Target and newPassword are required' });
  }

  if (newPassword.length < 6) {
    return res.status(400).json({ error: 'Mật khẩu mới phải có tối thiểu 6 ký tự.' });
  }

  const cleanTarget = normalizeEmail(String(target));

  // Password reset is allowed only after a successful real email OTP verification.
  const resetOtp = activeOtpSecrets.get(otpKey(cleanTarget, 'forgot_password'));
  if (!resetOtp || !resetOtp.verified || Date.now() > resetOtp.expiresAt + 10 * 60 * 1000) {
    return res.status(403).json({ error: 'Bạn cần xác thực Email OTP hợp lệ trước khi đặt lại mật khẩu.' });
  }

  // Find user
  const user = masterUsers.find(u => {
    const uEmail = u.email ? normalizeEmail(u.email) : '';
    return uEmail === cleanTarget;
  });

  if (user) {
    const secured = hashPassword(newPassword);
    user.passwordHash = secured.passwordHash;
    user.passwordSalt = secured.passwordSalt;
    delete user.password;
    activeOtpSecrets.delete(otpKey(cleanTarget, 'forgot_password'));
    saveUsers();
    console.log(`[PASSWORD RESET SUCCESS] Password updated for user ${user.fullName} (${target})`);
    return res.json({
      success: true,
      message: 'Đặt lại mật khẩu mới thành công! Bạn có thể đăng nhập bằng mật khẩu mới ngay bây giờ.',
      user
    });
  }



  return res.status(404).json({ error: 'Không tìm thấy tài khoản tương ứng với số điện thoại hoặc Email này.' });
});

// 7. User Login API
app.post('/api/auth/login', (req, res) => {
  const identifier = String(req.body.identifier || '').trim();
  const password = String(req.body.password || '');
  if (!identifier || !password) {
    return res.status(400).json({ error: 'Vui lòng nhập tài khoản và mật khẩu.' });
  }

  const isEmailIdentifier = identifier.includes('@');
  const normalizedEmailIdentifier = isEmailIdentifier ? normalizeEmail(identifier) : '';
  const normalizedPhoneIdentifier = isEmailIdentifier ? '' : identifier.replace(/[\s.-]/g, '');

  const user = masterUsers.find(u => {
    const uPhone = u.phone ? u.phone.replace(/[\s.-]/g, '') : '';
    const uEmail = u.email ? normalizeEmail(u.email) : '';
    return isEmailIdentifier
      ? uEmail === normalizedEmailIdentifier
      : uPhone === normalizedPhoneIdentifier;
  });

  if (!user || !verifyPassword(user, password)) {
    return res.status(401).json({ error: 'Tài khoản hoặc mật khẩu không chính xác.' });
  }

  const token = createSessionToken(user.id, user.role);

  return res.json({
    success: true,
    user: sanitizeUser(user),
    token,
    expiresInSeconds: 24 * 60 * 60,
  });
});

// 8. Profile & real progress APIs
app.get('/api/profile/me', requireAuth, (req: any, res) => {
  const user = masterUsers.find(item => item.id === req.session.userId);
  if (!user) return res.status(404).json({ error: 'Không tìm thấy hồ sơ người dùng.' });
  return res.json({ success: true, user: sanitizeUser(user) });
});

app.patch('/api/profile/me', requireAuth, (req: any, res) => {
  const user = masterUsers.find(item => item.id === req.session.userId);
  if (!user) return res.status(404).json({ error: 'Không tìm thấy hồ sơ người dùng.' });

  const allowedFields = [
    'fullName', 'phone', 'age', 'condition', 'affectedLeg', 'dateOfBirth', 'gender', 'address',
    'surgeryDate', 'recoveryStartDate', 'doctorName', 'doctorHospital', 'caregiverName', 'caregiverPhone',
    'emergencyContactName', 'emergencyContactPhone', 'medicalHistory', 'allergies', 'medications',
    'facilityName', 'facilityCode', 'department', 'medicalRecordCode', 'relationship',
    'shareWithDoctor', 'shareWithCaregiver', 'shareLocationOnSos'
  ];
  for (const field of allowedFields) {
    if (Object.prototype.hasOwnProperty.call(req.body, field)) (user as any)[field] = req.body[field];
  }
  if (req.body.privacyConsent === true && !user.privacyConsentAt) user.privacyConsentAt = new Date().toISOString();
  if (typeof user.age !== 'number') user.age = Number(user.age) || 0;
  saveUsers();
  return res.json({ success: true, user: sanitizeUser(user) });
});

// Family linking: invite codes let a patient explicitly connect a relative without exposing a public patient directory.
app.get('/api/family/invite', requireAuth, (req: any, res) => {
  const user = masterUsers.find(item => item.id === req.session.userId);
  if (!user || user.role !== 'PATIENT') return res.status(403).json({ error: 'Chỉ người bệnh mới có mã liên kết người thân.' });
  ensureUniqueFamilyInviteCode(user);
  saveUsers();
  return res.json({ success: true, inviteCode: user.familyInviteCode });
});

app.post('/api/family/invite/regenerate', requireAuth, (req: any, res) => {
  const user = masterUsers.find(item => item.id === req.session.userId);
  if (!user || user.role !== 'PATIENT') return res.status(403).json({ error: 'Chỉ người bệnh mới có thể tạo lại mã liên kết.' });
  user.familyInviteCode = '';
  ensureUniqueFamilyInviteCode(user);
  saveUsers();
  return res.json({ success: true, inviteCode: user.familyInviteCode });
});

app.post('/api/family/link', requireAuth, (req: any, res) => {
  const caregiver = masterUsers.find(item => item.id === req.session.userId);
  if (!caregiver || caregiver.role !== 'CAREGIVER') return res.status(403).json({ error: 'Chỉ tài khoản Người thân được dùng chức năng này.' });
  const inviteCode = String(req.body.inviteCode || '').trim().toUpperCase();
  if (!inviteCode) return res.status(400).json({ error: 'Vui lòng nhập mã liên kết của người bệnh.' });
  const patient = masterUsers.find(item => item.role === 'PATIENT' && String(item.familyInviteCode || '').toUpperCase() === inviteCode);
  if (!patient) return res.status(404).json({ error: 'Mã liên kết không đúng hoặc đã được thay đổi.' });

  caregiver.linkedPatientId = patient.id;
  caregiver.linkedAt = new Date().toISOString();
  patient.caregiverName = caregiver.fullName;
  patient.caregiverPhone = caregiver.phone;
  patient.shareWithCaregiver = true;
  saveUsers();
  return res.json({ success: true, caregiver: sanitizeUser(caregiver), patient: sanitizeUser(patient) });
});

app.delete('/api/family/link', requireAuth, (req: any, res) => {
  const caregiver = masterUsers.find(item => item.id === req.session.userId);
  if (!caregiver || caregiver.role !== 'CAREGIVER') return res.status(403).json({ error: 'Chỉ tài khoản Người thân được dùng chức năng này.' });
  const patient = caregiver.linkedPatientId ? masterUsers.find(item => item.id === caregiver.linkedPatientId) : undefined;
  if (patient && patient.caregiverPhone === caregiver.phone) {
    patient.caregiverName = '';
    patient.caregiverPhone = '';
  }
  caregiver.linkedPatientId = undefined;
  caregiver.linkedAt = undefined;
  saveUsers();
  return res.json({ success: true });
});

app.get('/api/facilities', requireAuth, (_req: any, res) => {
  const map = new Map<string, { code: string; name: string; departments: string[] }>();
  for (const user of masterUsers) {
    const name = String(user.facilityName || user.doctorHospital || '').trim();
    if (!name) continue;
    const code = String(user.facilityCode || '').trim().toUpperCase();
    const key = code || name.toLowerCase();
    const existing = map.get(key) || { code, name, departments: [] };
    if (user.department && !existing.departments.includes(user.department)) existing.departments.push(user.department);
    map.set(key, existing);
  }
  return res.json({ success: true, facilities: Array.from(map.values()).sort((a, b) => a.name.localeCompare(b.name, 'vi')) });
});

app.post('/api/progress/session', requireAuth, (req: any, res) => {
  const user = masterUsers.find(item => item.id === req.session.userId);
  if (!user || user.role !== 'PATIENT') return res.status(403).json({ error: 'Chỉ người bệnh mới có thể lưu buổi tập.' });

  const completedReps = Math.max(0, Number(req.body.completedReps) || 0);
  const targetReps = Math.max(0, Number(req.body.targetReps) || 0);
  const maxAngleAchieved = Math.max(0, Number(req.body.maxAngleAchieved) || 0);
  const painLevel = Math.min(10, Math.max(0, Number(req.body.painLevel) || 0));
  const durationSeconds = Math.max(0, Number(req.body.durationSeconds) || 0);

  if (!req.body.exerciseId || !req.body.exerciseTitle) {
    return res.status(400).json({ error: 'Thiếu thông tin bài tập.' });
  }
  if (!liveTelemetry.isConnected && maxAngleAchieved > 0) {
    return res.status(400).json({ error: 'Chưa có dữ liệu thiết bị thật. Không thể lưu góc đo giả.' });
  }

  const record: TrainingSessionRecord = {
    id: `session_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`,
    userId: user.id,
    exerciseId: String(req.body.exerciseId),
    exerciseTitle: String(req.body.exerciseTitle),
    completedReps,
    targetReps,
    maxAngleAchieved: liveTelemetry.isConnected ? maxAngleAchieved : 0,
    painLevel,
    durationSeconds,
    notes: String(req.body.notes || '').slice(0, 1000),
    createdAt: new Date().toISOString(),
    angleSource: liveTelemetry.isConnected && maxAngleAchieved > 0 ? 'SENSOR' : 'NONE',
    painSource: 'PATIENT_REPORTED',
    sensorCapturedAt: liveTelemetry.isConnected ? String(liveTelemetry.lastUpdated || new Date().toISOString()) : undefined,
  };
  trainingSessions.push(record);
  saveTrainingSessions();
  return res.status(201).json({ success: true, session: record, summary: buildProgressSummary(user) });
});

app.get('/api/progress/summary', requireAuth, (req: any, res) => {
  const patientId = String(req.query.patientId || '').trim();
  const patient = resolveProgressPatient(req.session, patientId);
  if (!patient) return res.status(403).json({ error: 'Bạn chưa được cấp quyền xem hồ sơ tiến độ này.' });
  return res.json({ success: true, summary: buildProgressSummary(patient) });
});

// V6 Recovery Passport + Family Co-Rehab endpoints.
app.get('/api/co-rehab', requireAuth, (req: any, res) => {
  const requestedPatientId = String(req.query.patientId || '').trim();
  const patient = resolveProgressPatient(req.session, requestedPatientId);
  if (!patient) return res.status(403).json({ error: 'Bạn chưa được cấp quyền xem phiên hỗ trợ này.' });
  const records = coRehabRecords
    .filter(item => item.patientId === patient.id)
    .sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime());
  const active = records.find(item => item.status === 'REQUESTED' || item.status === 'SUPPORTED') || null;
  return res.json({ success: true, active, recent: records.slice(0, 8) });
});

app.post('/api/co-rehab/start', requireAuth, (req: any, res) => {
  const actor = masterUsers.find(item => item.id === req.session.userId);
  if (!actor || actor.role !== 'PATIENT') return res.status(403).json({ error: 'Chỉ người bệnh mới có thể bắt đầu phiên tập có người thân hỗ trợ.' });
  const existing = coRehabRecords.find(item => item.patientId === actor.id && (item.status === 'REQUESTED' || item.status === 'SUPPORTED'));
  if (existing) return res.json({ success: true, session: existing });
  const record: CoRehabRecord = {
    id: `corehab_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`,
    patientId: actor.id,
    requestedByUserId: actor.id,
    status: 'REQUESTED',
    startedAt: new Date().toISOString(),
    checklist: {
      safeSpace: Boolean(req.body?.checklist?.safeSpace),
      deviceReady: Boolean(req.body?.checklist?.deviceReady),
      waterReady: Boolean(req.body?.checklist?.waterReady),
    },
    note: String(req.body.note || '').slice(0, 500),
  };
  coRehabRecords.push(record);
  saveCoRehabRecords();
  return res.status(201).json({ success: true, session: record });
});

app.post('/api/co-rehab/join', requireAuth, (req: any, res) => {
  const caregiver = masterUsers.find(item => item.id === req.session.userId);
  if (!caregiver || caregiver.role !== 'CAREGIVER' || !caregiver.linkedPatientId) {
    return res.status(403).json({ error: 'Tài khoản Người thân chưa được liên kết với người bệnh.' });
  }
  const record = coRehabRecords
    .filter(item => item.patientId === caregiver.linkedPatientId && (item.status === 'REQUESTED' || item.status === 'SUPPORTED'))
    .sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime())[0];
  if (!record) return res.status(404).json({ error: 'Hiện không có phiên tập nào đang chờ người thân hỗ trợ.' });
  record.status = 'SUPPORTED';
  record.caregiverId = caregiver.id;
  record.caregiverName = caregiver.fullName;
  record.joinedAt = record.joinedAt || new Date().toISOString();
  saveCoRehabRecords();
  return res.json({ success: true, session: record });
});

app.post('/api/co-rehab/complete', requireAuth, (req: any, res) => {
  const actor = masterUsers.find(item => item.id === req.session.userId);
  if (!actor) return res.status(401).json({ error: 'Phiên đăng nhập không hợp lệ.' });
  const patientId = actor.role === 'PATIENT' ? actor.id : actor.role === 'CAREGIVER' ? actor.linkedPatientId : undefined;
  if (!patientId) return res.status(403).json({ error: 'Bạn không có quyền kết thúc phiên hỗ trợ này.' });
  const record = coRehabRecords
    .filter(item => item.patientId === patientId && (item.status === 'REQUESTED' || item.status === 'SUPPORTED'))
    .sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime())[0];
  if (!record) return res.status(404).json({ error: 'Không có phiên hỗ trợ đang hoạt động.' });
  record.status = String(req.body.status || '').toUpperCase() === 'CANCELLED' ? 'CANCELLED' : 'COMPLETED';
  record.endedAt = new Date().toISOString();
  saveCoRehabRecords();
  return res.json({ success: true, session: record });
});

app.get('/api/doctor/patients', requireAuth, (req: any, res) => {
  const doctor = masterUsers.find(user => user.id === req.session.userId);
  if (!doctor || doctor.role !== 'DOCTOR') return res.status(403).json({ error: 'Chỉ tài khoản bác sĩ được truy cập mục này.' });
  const patients = masterUsers
    .filter(user => user.role === 'PATIENT' && user.doctorId === doctor.id && user.shareWithDoctor === true)
    .map(patient => buildProgressSummary(patient));
  return res.json({ success: true, patients });
});

// 9. Update User Location / GPS Coordinates
app.post('/api/location/update', requireAuth, (req: any, res) => {
  const { latitude, longitude, accuracy, formattedAddress, district, city } = req.body;
  const userId = req.session.userId;
  
  if (latitude === undefined || longitude === undefined) {
    return res.status(400).json({ error: 'Latitude and longitude are required' });
  }

  const locationData = {
    latitude: Number(latitude),
    longitude: Number(longitude),
    accuracy: Number(accuracy) || 10,
    formattedAddress: formattedAddress || 'Vị trí GPS thời gian thực',
    district: district || '',
    city: city || 'Việt Nam',
    updatedAt: new Date().toISOString()
  };

  // Find user and update
  if (userId) {
    const u = masterUsers.find(user => user.id === userId);
    if (u) {
      u.location = locationData;
      saveUsers();
    }
  }

  res.json({
    success: true,
    savedLocation: locationData,
    serverTimestamp: new Date().toISOString()
  });
});

// 8. Get All Live Locations
app.get('/api/location/all', requireAdmin, (req, res) => {
  const activeLocations = masterUsers
    .filter(u => u.location)
    .map(u => ({
      userId: u.id,
      fullName: u.fullName,
      role: u.role,
      phone: u.phone,
      location: u.location,
      hardwareDeviceId: u.hardwareDeviceId
    }));

  res.json({
    success: true,
    count: activeLocations.length,
    locations: activeLocations
  });
});

// 9A. Web Push subscription endpoints for emergency alerts
app.get('/api/push/public-key', (req, res) => {
  res.json({ publicKey: vapidKeys.publicKey, supported: true });
});

app.post('/api/push/subscribe', requireAuth, (req: any, res) => {
  const { subscription, role, userId } = req.body || {};
  if (!subscription?.endpoint || !subscription?.keys?.p256dh || !subscription?.keys?.auth) {
    return res.status(400).json({ error: 'Push subscription không hợp lệ.' });
  }
  const record: StoredPushSubscription = {
    endpoint: String(subscription.endpoint),
    expirationTime: subscription.expirationTime ?? null,
    keys: { p256dh: String(subscription.keys.p256dh), auth: String(subscription.keys.auth) },
    role: String(req.session?.role || role || 'CAREGIVER').toUpperCase(),
    userId: String(req.session?.userId || userId || ''),
    createdAt: new Date().toISOString(),
  };
  pushSubscriptions = pushSubscriptions.filter(s => s.endpoint !== record.endpoint);
  pushSubscriptions.push(record);
  savePushSubscriptions();
  res.json({ success: true, role: record.role });
});

app.post('/api/push/unsubscribe', requireAuth, (req, res) => {
  const endpoint = String(req.body?.endpoint || '');
  pushSubscriptions = pushSubscriptions.filter(s => s.endpoint !== endpoint);
  savePushSubscriptions();
  res.json({ success: true });
});

// 9B. Realtime telemetry / SOS streams (Server-Sent Events)
app.get('/api/realtime/telemetry', requireStreamAuth, (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();
  telemetrySseClients.add(res);
  sendSse(res, 'telemetry', liveTelemetry);
  const keepAlive = setInterval(() => res.write(': keep-alive\n\n'), 15000);
  req.on('close', () => { clearInterval(keepAlive); telemetrySseClients.delete(res); });
});

app.get('/api/realtime/alerts', requireStreamAuth, (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();
  alertSseClients.add(res);
  sendSse(res, 'ready', { ok: true, latest: sosHistory[0] || null });
  const keepAlive = setInterval(() => res.write(': keep-alive\n\n'), 15000);
  req.on('close', () => { clearInterval(keepAlive); alertSseClients.delete(res); });
});

app.get('/api/sos/history', requireAuth, (req, res) => res.json({ success: true, alerts: sosHistory }));

app.post('/api/sos/ack', requireAuth, (req: any, res) => {
  const { alertId, note } = req.body || {};
  const target = sosHistory.find(a => a.id === alertId) || sosHistory.find(a => a.status === 'ACTIVE');
  if (target) {
    target.status = 'ACKNOWLEDGED';
    target.acknowledgedAt = new Date().toISOString();
    target.note = note || 'Người bệnh xác nhận an toàn.';
  }
  liveTelemetry.isFallDetected = false;
  liveTelemetry.fallImpactG = 0;
  liveTelemetry.activityState = liveTelemetry.isConnected ? 'Đang đồng bộ chuyển động thật từ thiết bị' : 'Đang chờ dữ liệu từ thiết bị';
  commandEsp32('ALARM,OFF');
  broadcastSse(alertSseClients, 'sos-cleared', { alertId: target?.id || null, timestamp: new Date().toISOString() });
  broadcastSse(telemetrySseClients, 'telemetry', liveTelemetry);
  res.json({ success: true, alert: target || null });
});

// 9. Device product linking + live telemetry
app.get('/api/devices/linked-product', requireAuth, (req: any, res) => {
  const link = deviceLinks.find(item => item.userId === req.session.userId) || null;
  res.json({ success: true, link });
});

app.post('/api/devices/link-product', requireAuth, (req: any, res) => {
  const decoded = parseSoftExoProductPayload(req.body?.productPayload ?? req.body?.productCode);
  const productCode = decoded.productCode;
  if (productCode.length < 4 || productCode.length > 128) {
    return res.status(400).json({ error: 'Mã sản phẩm không hợp lệ.' });
  }
  if (/^https?:\/\//i.test(productCode)) {
    return res.status(400).json({ error: 'Mã vừa quét là một đường dẫn web, không phải tem thiết bị SOFT-EXO.' });
  }
  const existingOwner = deviceLinks.find(item => item.productCode === productCode && item.userId !== req.session.userId);
  if (existingOwner) {
    return res.status(409).json({ error: 'Mã sản phẩm này đã được liên kết với một tài khoản khác.' });
  }
  deviceLinks = deviceLinks.filter(item => item.userId !== req.session.userId);
  const link: DeviceLinkRecord = {
    userId: req.session.userId,
    productCode,
    kneeSide: decoded.kneeSide,
    linkedAt: new Date().toISOString(),
  };
  deviceLinks.push(link);
  saveDeviceLinks();
  res.json({ success: true, link });
});

app.delete('/api/devices/linked-product', requireAuth, (req: any, res) => {
  deviceLinks = deviceLinks.filter(item => item.userId !== req.session.userId);
  saveDeviceLinks();
  res.json({ success: true });
});

app.get('/api/devices/telemetry', requireAuth, (req, res) => {
  res.json(liveTelemetry);
});

app.post('/api/devices/telemetry', requireDeviceApiKey, (req, res) => {
  liveTelemetry = {
    ...liveTelemetry,
    ...req.body,
    source: req.body.source || 'API',
    lastUpdated: new Date().toISOString()
  };
  evaluateHardwareSafety();
  broadcastSse(telemetrySseClients, 'telemetry', liveTelemetry);
  res.json({ success: true, telemetry: liveTelemetry });
});

// 10. Emergency SOS Alert API
app.post('/api/sos/alert', requireDeviceApiKey, (req, res) => {
  const gForce = Number(req.body.gForce) || 2.85;
  const notes = String(req.body.notes || '').trim();
  liveTelemetry.isFallDetected = true;
  liveTelemetry.fallImpactG = gForce;
  liveTelemetry.activityState = `Cảnh báo va đập mạnh (${gForce.toFixed(2)}G)`;

  raiseSafetyAlert(notes || 'Thiết bị phát hiện tình huống cần kiểm tra ngay.', 'danger', gForce);
  const alert = sosHistory[0];
  const patient = alert?.patientId ? masterUsers.find(user => user.id === alert.patientId) : null;
  const recipients = [
    patient?.doctorName ? `Bác sĩ: ${patient.doctorName}` : null,
    patient?.caregiverName ? `Người thân: ${patient.caregiverName}` : null,
    'Quản trị hệ thống',
  ].filter(Boolean);

  res.json({
    success: true,
    alertId: alert?.id || `sos_${Date.now()}`,
    patientName: alert?.patientName || 'Chưa xác định người bệnh',
    location: alert?.location || 'Chưa có vị trí được chia sẻ',
    dispatchedTo: recipients,
    timestamp: alert?.timestamp || new Date().toISOString(),
  });
});

// Persistent role-aware chat store
const CHAT_MESSAGES_FILE = path.join(DATA_DIR, 'chat-messages.json');
function loadChatMessages(): ChatMsg[] {
  try {
    if (fs.existsSync(CHAT_MESSAGES_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(CHAT_MESSAGES_FILE, 'utf8'));
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (err) {
    console.warn('[CHAT] Could not load saved messages:', err);
  }
  return [];
}
let chatMessages: ChatMsg[] = loadChatMessages();
function saveChatMessages() {
  fs.writeFileSync(CHAT_MESSAGES_FILE, JSON.stringify(chatMessages, null, 2), { mode: 0o600 });
}

function threadPatientId(threadId: string): string {
  const parts = String(threadId || '').split(':');
  return parts.length >= 2 ? parts[1] : '';
}

function canAccessThread(session: SessionPayload, threadId: string): boolean {
  const actor = masterUsers.find(user => user.id === session.userId);
  if (!actor || !threadId) return false;
  if (actor.role === 'ADMIN') return true;
  if (threadId.startsWith('assistant:')) return threadPatientId(threadId) === actor.id;
  const patientId = threadPatientId(threadId);
  const patient = masterUsers.find(user => user.id === patientId && user.role === 'PATIENT');
  if (!patient) return false;
  if (actor.role === 'PATIENT') return actor.id === patientId;
  if (threadId.startsWith('doctor:') && actor.role === 'DOCTOR') return patient.doctorId === actor.id && patient.shareWithDoctor === true;
  if (threadId.startsWith('caregiver:') && actor.role === 'CAREGIVER') return actor.linkedPatientId === patientId && patient.shareWithCaregiver === true;
  return false;
}

// 11. Messages between real linked accounts
app.get('/api/chat/messages', requireAuth, (req: any, res) => {
  const threadId = String(req.query.threadId || '').trim();
  if (!canAccessThread(req.session, threadId)) return res.status(403).json({ error: 'Bạn không có quyền xem cuộc trò chuyện này.' });
  const messages = chatMessages.filter(item => item.threadId === threadId);
  return res.json({ success: true, messages });
});

app.post('/api/chat/send', requireAuth, (req: any, res) => {
  const threadId = String(req.body.threadId || '').trim();
  if (!canAccessThread(req.session, threadId)) return res.status(403).json({ error: 'Bạn không có quyền gửi tin nhắn vào cuộc trò chuyện này.' });
  const actor = masterUsers.find(user => user.id === req.session.userId);
  if (!actor) return res.status(404).json({ error: 'Không tìm thấy tài khoản.' });
  const content = String(req.body.content || '').trim();
  const photoUrl = req.body.photoUrl ? String(req.body.photoUrl) : undefined;
  if (!content && !photoUrl) return res.status(400).json({ error: 'Tin nhắn đang trống.' });

  const newMsg: ChatMsg = {
    id: `msg_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`,
    threadId,
    senderName: actor.fullName,
    senderRole: actor.role,
    content: content || '📷 Hình ảnh đính kèm',
    timestamp: new Date().toISOString(),
    isDoctor: actor.role === 'DOCTOR',
    photoUrl,
    photoMime: req.body.photoMime ? String(req.body.photoMime) : undefined,
    audioUrl: req.body.audioUrl ? String(req.body.audioUrl) : undefined,
    isAi: false,
  };
  chatMessages.push(newMsg);
  saveChatMessages();
  return res.json({ success: true, message: newMsg });
});

// 12. Gemini Clinical AI Chat Route (Multimodal Vision & Deep Context)
app.post('/api/gemini/chat', requireAuth, async (req: any, res) => {
  const { message, image, history, patientContext, threadId } = req.body;
  const aiThreadId = String(threadId || '').trim();

  if (!message && !image) {
    return res.status(400).json({ error: 'Message or image is required' });
  }

  // Patient AI conversations use a private assistant:<patientId> thread.
  // This keeps the restored chatbot separate from doctor/caregiver messages.
  if (aiThreadId) {
    if (!aiThreadId.startsWith('assistant:') || !canAccessThread(req.session, aiThreadId)) {
      return res.status(403).json({ error: 'Bạn không có quyền sử dụng cuộc trò chuyện AI này.' });
    }
  }

  const actor = masterUsers.find(user => user.id === req.session.userId);
  const persistAiExchange = (replyText: string) => {
    if (!aiThreadId || !actor) return;
    const now = Date.now();
    const userMsg: ChatMsg = {
      id: `msg_${now}_${crypto.randomBytes(3).toString('hex')}`,
      threadId: aiThreadId,
      senderName: actor.fullName,
      senderRole: actor.role,
      content: String(message || '').trim() || '📷 Hình ảnh đã gửi cho Trợ lý AI',
      timestamp: new Date(now).toISOString(),
      isAi: false,
    };
    const aiMsg: ChatMsg = {
      id: `msg_${now + 1}_${crypto.randomBytes(3).toString('hex')}`,
      threadId: aiThreadId,
      senderName: 'Trợ lý AI SOFT-EXO',
      senderRole: 'AI',
      content: replyText,
      timestamp: new Date(now + 1).toISOString(),
      isAi: true,
    };
    chatMessages.push(userMsg, aiMsg);
    saveChatMessages();
  };

  try {
    const ai = getGeminiClient();
    if (ai) {
      const systemInstruction = `Bạn là trợ lý hướng dẫn trong ứng dụng SOFT-EXO. Mục tiêu là giúp người dùng hiểu cách sử dụng ứng dụng, cách ghi nhận buổi tập, cách chuẩn bị thông tin để trao đổi với bác sĩ và giải thích các hướng dẫn đã được cung cấp.

QUY TẮC AN TOÀN:
- Không tự chẩn đoán bệnh, không kết luận nhiễm trùng, tổn thương hay tình trạng lâm sàng chỉ từ hình ảnh hoặc dữ liệu ứng dụng.
- Không tự kê thuốc, đổi thuốc, đặt giới hạn vận động hoặc thay đổi kế hoạch điều trị.
- Khi người dùng hỏi về đau tăng, sưng đỏ, sốt, chảy dịch, té ngã, chấn thương hoặc triệu chứng đáng lo, khuyên họ liên hệ bác sĩ/cơ sở y tế phù hợp.
- Nếu có hình ảnh, chỉ mô tả những gì có thể quan sát một cách thận trọng và khuyến khích gửi hình đó cho bác sĩ phụ trách.
- Trả lời bằng tiếng Việt rõ ràng, ngắn gọn, dễ hiểu; tránh thuật ngữ kỹ thuật khi không cần thiết.

Hồ sơ người dùng (chỉ để đặt câu hỏi vào đúng bối cảnh, không dùng để tự chẩn đoán):
- Họ tên: ${patientContext?.fullName || 'Người dùng'}
- Tình trạng đã khai: ${patientContext?.condition || 'Chưa cập nhật'}
- Chân cần phục hồi: ${patientContext?.affectedLeg || 'Chưa cập nhật'}`;

      // Build conversation contents
      const contents: any[] = [];

      if (Array.isArray(history)) {
        for (const item of history.slice(-6)) {
          if (item.text) {
            contents.push({
              role: item.role === 'model' ? 'model' : 'user',
              parts: [{ text: item.text }]
            });
          }
        }
      }

      const userParts: any[] = [];

      // Multimodal Image Processing
      if (image && (image.data || typeof image === 'string')) {
        let rawData = typeof image === 'string' ? image : image.data;
        let mimeType = (typeof image === 'object' && image.mimeType) || 'image/jpeg';

        if (rawData.includes(';base64,')) {
          const splitArr = rawData.split(';base64,');
          const mimeMatch = splitArr[0].match(/data:(.*?)$/);
          if (mimeMatch) mimeType = mimeMatch[1];
          rawData = splitArr[1];
        }

        userParts.push({
          inlineData: {
            mimeType,
            data: rawData
          }
        });
      }

      if (message) {
        userParts.push({ text: message });
      } else if (userParts.length > 0 && !message) {
        userParts.push({ text: 'Hãy mô tả thận trọng những gì có thể quan sát trong hình và cho tôi biết thông tin nào nên gửi cho bác sĩ. Không tự chẩn đoán.' });
      }

      contents.push({
        role: 'user',
        parts: userParts
      });

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents,
        config: {
          systemInstruction,
          temperature: 0.5,
        }
      });

      const replyText = response.text || 'Dịch vụ AI chưa trả về nội dung. Hệ thống không thể kết luận tình trạng y khoa từ dữ liệu hiện tại; vui lòng thử lại hoặc liên hệ bác sĩ phụ trách.';
      persistAiExchange(replyText);
      return res.json({ reply: replyText });
    }
  } catch (err: any) {
    console.error('Gemini API Error:', err);
  }

  // Safe fallback when the AI service is unavailable. Never claim that an
  // image was clinically interpreted when no vision model actually ran.
  let fallbackAdvice = `🩺 **SOFT-EXO • Hỗ trợ phục hồi**\n\n`;
  if (image) {
    fallbackAdvice += `Hiện dịch vụ phân tích hình ảnh đang tạm thời không khả dụng, nên hệ thống **không thể kết luận từ ảnh này**. Bạn có thể thử lại sau hoặc gửi ảnh cho bác sĩ phụ trách trong mục Trao đổi.\n\nNếu có các dấu hiệu như đau tăng nhanh, sưng đỏ nóng rõ, chảy dịch/mủ, sốt, tê yếu chân hoặc khó thở, hãy liên hệ cơ sở y tế ngay.`;
  } else {
    fallbackAdvice += `Hệ thống đã nhận câu hỏi của bạn nhưng dịch vụ tư vấn tự động đang tạm thời không khả dụng. Hãy tiếp tục bài tập đúng phác đồ đã được bác sĩ chỉ định và không cố vượt ngưỡng đau hoặc giới hạn vận động đã đặt trong ứng dụng. Nếu triệu chứng thay đổi rõ hoặc đau tăng, hãy liên hệ bác sĩ phụ trách.`;
  }

  persistAiExchange(fallbackAdvice);
  return res.json({ reply: fallbackAdvice, aiAvailable: false });
});

// Vite middleware setup
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SOFT-EXO Full-Stack Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
