/*
  SOFT-EXO Family Care - ESP32-S3 + 2x MPU6050 (recommended)
  -----------------------------------------------------------
  IMU 1: thigh, IMU 2: shin. The knee angle is the absolute difference between
  the two calibrated segment angles, so the 3D model stays correct even when
  the whole leg changes orientation.

  Required Arduino library: MPU6050_tockn
  Both sensors may stay at address 0x68 because they use TWO ESP32 I2C buses.

  Default example pins:
  - THIGH: SDA=8, SCL=9
  - SHIN : SDA=10, SCL=11
  Change pins if your ESP32-S3 board uses them for another function.
*/

#include <WiFi.h>
#include <WiFiUdp.h>
#include <Wire.h>
#include <MPU6050_tockn.h>

const char* WIFI_SSID = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* MAC_SERVER_IP = "192.168.1.10"; // run on Mac: ipconfig getifaddr en0
const char* DEVICE_CODE = "EXO2026-0415-0012"; // must match barcode/serial linked in app

constexpr int THIGH_SDA = 8;
constexpr int THIGH_SCL = 9;
constexpr int SHIN_SDA = 10;
constexpr int SHIN_SCL = 11;
constexpr uint16_t SERVER_PORT = 5005;
constexpr uint16_t LOCAL_UDP_PORT = 5006;
constexpr int BUZZER_PIN = -1; // set a real GPIO only if an active buzzer is wired
constexpr uint32_t SEND_INTERVAL_MS = 20; // 50 Hz

TwoWire thighBus = TwoWire(0);
TwoWire shinBus = TwoWire(1);
MPU6050 thighImu(thighBus);
MPU6050 shinImu(shinBus);
WiFiUDP udp;

float thighZero = 0.0f;
float shinZero = 0.0f;
uint32_t lastSendMs = 0;
bool alarmOn = false;

void setAlarm(bool on) {
  alarmOn = on;
  if (BUZZER_PIN >= 0) digitalWrite(BUZZER_PIN, on ? HIGH : LOW);
}

void receiveServerCommand() {
  int packetSize = udp.parsePacket();
  if (packetSize <= 0) return;
  char buffer[128];
  int len = udp.read(buffer, sizeof(buffer) - 1);
  if (len <= 0) return;
  buffer[len] = '\0';
  String command(buffer);
  if (command.startsWith("ALARM,ON")) setAlarm(true);
  else if (command.startsWith("ALARM,OFF")) setAlarm(false);
}

void setup() {
  Serial.begin(115200);
  delay(300);

  if (BUZZER_PIN >= 0) {
    pinMode(BUZZER_PIN, OUTPUT);
    digitalWrite(BUZZER_PIN, LOW);
  }

  thighBus.begin(THIGH_SDA, THIGH_SCL, 400000);
  shinBus.begin(SHIN_SDA, SHIN_SCL, 400000);
  thighImu.begin();
  shinImu.begin();

  Serial.println("Calibrating THIGH IMU - keep leg still...");
  thighImu.calcGyroOffsets(true);
  Serial.println("Calibrating SHIN IMU - keep leg still...");
  shinImu.calcGyroOffsets(true);

  // Fully extend the knee and keep still for zero reference.
  for (int i = 0; i < 120; i++) {
    thighImu.update();
    shinImu.update();
    delay(5);
  }
  thighZero = thighImu.getAngleX();
  shinZero = shinImu.getAngleX();

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("Connecting WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(300);
    Serial.print('.');
  }
  Serial.println();
  Serial.print("ESP32 IP: ");
  Serial.println(WiFi.localIP());

  udp.begin(LOCAL_UDP_PORT);
  Serial.printf("2-IMU UDP %u -> Mac %s:%u\n", LOCAL_UDP_PORT, MAC_SERVER_IP, SERVER_PORT);
}

void loop() {
  thighImu.update();
  shinImu.update();
  receiveServerCommand();

  const uint32_t now = millis();
  if (now - lastSendMs < SEND_INTERVAL_MS) return;
  lastSendMs = now;

  const float thighPitch = thighImu.getAngleX() - thighZero;
  const float shinPitch = shinImu.getAngleX() - shinZero;
  float kneeAngle = fabsf(shinPitch - thighPitch);
  if (kneeAngle > 150.0f) kneeAngle = 150.0f;

  const float tax = thighImu.getAccX();
  const float tay = thighImu.getAccY();
  const float taz = thighImu.getAccZ();
  const float sax = shinImu.getAccX();
  const float say = shinImu.getAccY();
  const float saz = shinImu.getAccZ();
  const float thighG = sqrtf(tax * tax + tay * tay + taz * taz);
  const float shinG = sqrtf(sax * sax + say * say + saz * saz);
  const float gMag = max(thighG, shinG);

  // Local safety alarm. The Mac backend independently evaluates the same data
  // and sends the realtime/web-push SOS to family devices.
  if (gMag >= 2.5f || kneeAngle > 138.0f) setAlarm(true);

  String payload = "{";
  payload += "\"deviceCode\":\"" + String(DEVICE_CODE) + "\",";
  payload += "\"kneeAngle\":" + String(kneeAngle, 2) + ",";
  payload += "\"thighPitch\":" + String(thighPitch, 2) + ",";
  payload += "\"shinPitch\":" + String(shinPitch, 2) + ",";
  payload += "\"roll\":" + String(shinImu.getAngleY(), 2) + ",";
  payload += "\"yaw\":" + String(shinImu.getAngleZ(), 2) + ",";
  payload += "\"accelX\":" + String(sax, 3) + ",";
  payload += "\"accelY\":" + String(say, 3) + ",";
  payload += "\"accelZ\":" + String(saz, 3) + ",";
  payload += "\"gForceMagnitude\":" + String(gMag, 3) + ",";
  payload += "\"samplingRateHz\":50";
  payload += "}";

  udp.beginPacket(MAC_SERVER_IP, SERVER_PORT);
  udp.print(payload);
  udp.endPacket();

  Serial.printf("Knee: %.1f | thigh: %.1f | shin: %.1f | G: %.2f | Alarm: %s\n",
                kneeAngle, thighPitch, shinPitch, gMag, alarmOn ? "ON" : "OFF");
}
