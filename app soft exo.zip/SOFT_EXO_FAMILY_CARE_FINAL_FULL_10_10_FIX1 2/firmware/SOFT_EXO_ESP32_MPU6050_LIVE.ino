/*
  SOFT-EXO Family Care - ESP32-S3 + MPU6050 live bridge
  ------------------------------------------------------
  Sends knee movement to the Mac backend via UDP port 5005 at 50 Hz.
  The web app receives it via SSE and bends the 3D knee in real time.

  Required Arduino library: MPU6050_tockn
  IMPORTANT: set WIFI_SSID, WIFI_PASSWORD and MAC_SERVER_IP before upload.

  Optional buzzer:
  - Set BUZZER_PIN to a valid GPIO if an active buzzer is installed.
  - Leave -1 if there is no physical buzzer. The patient/caregiver phone still
    produces visual/audio/vibration alerts in the web app where allowed.
*/

#include <WiFi.h>
#include <WiFiUdp.h>
#include <Wire.h>
#include <MPU6050_tockn.h>

const char* WIFI_SSID = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* MAC_SERVER_IP = "192.168.1.10";  // run: ipconfig getifaddr en0
const char* DEVICE_CODE = "EXO2026-0415-0012"; // must match the barcode/serial linked in the app

constexpr uint16_t SERVER_PORT = 5005;
constexpr uint16_t LOCAL_UDP_PORT = 5006;
constexpr int BUZZER_PIN = -1; // change e.g. to 4 only if a buzzer is wired
constexpr uint32_t SEND_INTERVAL_MS = 20; // 50 Hz

WiFiUDP udp;
MPU6050 mpu6050(Wire);

float zeroAngleX = 0.0f;
uint32_t lastSendMs = 0;
bool alarmOn = false;

void setAlarm(bool on) {
  alarmOn = on;
  if (BUZZER_PIN >= 0) {
    digitalWrite(BUZZER_PIN, on ? HIGH : LOW);
  }
}

void receiveServerCommand() {
  int packetSize = udp.parsePacket();
  if (packetSize <= 0) return;

  char buffer[128];
  int len = udp.read(buffer, sizeof(buffer) - 1);
  if (len <= 0) return;
  buffer[len] = '\0';
  String command(buffer);

  if (command.startsWith("ALARM,ON")) {
    setAlarm(true);
  } else if (command.startsWith("ALARM,OFF")) {
    setAlarm(false);
  }
}

void setup() {
  Serial.begin(115200);
  delay(300);

  if (BUZZER_PIN >= 0) {
    pinMode(BUZZER_PIN, OUTPUT);
    digitalWrite(BUZZER_PIN, LOW);
  }

  Wire.begin(8, 9); // ESP32-S3: SDA=8, SCL=9 (change if your wiring differs)
  mpu6050.begin();
  mpu6050.calcGyroOffsets(true);

  // Zero reference while the knee is fully extended.
  for (int i = 0; i < 100; i++) {
    mpu6050.update();
    delay(5);
  }
  zeroAngleX = mpu6050.getAngleX();

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("Connecting WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(300);
    Serial.print('.');
  }
  Serial.println();
  Serial.print("ESP32 IP: ");
  Serial.println(WiFi.localIP());

  udp.begin(LOCAL_UDP_PORT);
  Serial.printf("UDP local port: %u -> Mac %s:%u\n", LOCAL_UDP_PORT, MAC_SERVER_IP, SERVER_PORT);
}

void loop() {
  mpu6050.update();
  receiveServerCommand();

  const uint32_t now = millis();
  if (now - lastSendMs < SEND_INTERVAL_MS) return;
  lastSendMs = now;

  float kneeAngle = fabs(mpu6050.getAngleX() - zeroAngleX);
  if (kneeAngle > 150.0f) kneeAngle = 150.0f;

  float ax = mpu6050.getAccX();
  float ay = mpu6050.getAccY();
  float az = mpu6050.getAccZ();
  float gMag = sqrtf(ax * ax + ay * ay + az * az);

  // Local fail-safe: if a buzzer is wired, alarm immediately instead of
  // waiting for the round-trip to the Mac/backend. The server will also detect
  // the same event and notify family devices.
  if (gMag >= 2.5f || kneeAngle > 138.0f) {
    setAlarm(true);
  }

  String payload = "{";
  payload += "\"deviceCode\":\"" + String(DEVICE_CODE) + "\",";
  payload += "\"kneeAngle\":" + String(kneeAngle, 2) + ",";
  payload += "\"roll\":" + String(mpu6050.getAngleY(), 2) + ",";
  payload += "\"yaw\":" + String(mpu6050.getAngleZ(), 2) + ",";
  payload += "\"accelX\":" + String(ax, 3) + ",";
  payload += "\"accelY\":" + String(ay, 3) + ",";
  payload += "\"accelZ\":" + String(az, 3) + ",";
  payload += "\"gForceMagnitude\":" + String(gMag, 3) + ",";
  payload += "\"samplingRateHz\":50";
  payload += "}";

  udp.beginPacket(MAC_SERVER_IP, SERVER_PORT);
  udp.print(payload);
  udp.endPacket();

  // Keep the serial output human-readable for bench testing.
  Serial.printf("Knee: %.1f deg | G: %.2f | Alarm: %s\n", kneeAngle, gMag, alarmOn ? "ON" : "OFF");
}
