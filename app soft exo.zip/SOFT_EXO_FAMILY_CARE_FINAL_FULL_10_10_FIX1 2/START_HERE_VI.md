# SOFT-EXO Family Care — Bắt đầu nhanh

## 1. Chạy web trên Mac

Lần đầu có thể double-click `RUN_SOFT_EXO_MAC.command`.

Hoặc Terminal:

```bash
npm install
npm run dev
```

Mở: `http://localhost:3012`

## 2. Cấu hình Email OTP thật một lần

Đăng nhập tài khoản Admin hiện có → **Cổng quản trị → Cấu Hình Email OTP**.

Nhập:
- **Brevo API Key** (`xkeysib-...`)
- **Email người gửi đã xác minh trên Brevo**
- **Tên người gửi**, ví dụ `SOFT-EXO Family Care`

Bấm **Lưu & xác thực**, sau đó nhập một email nhận thử và bấm **Gửi OTP thử**.

Sau bước này, người dùng đăng ký bằng email riêng của họ sẽ nhận mã OTP 6 số thật. Mỗi yêu cầu tạo mã mới, mã hết hạn sau 5 phút và chỉ dùng một lần.

> Không cần mở `.env` để cấu hình OTP. SMS OTP đã được loại khỏi luồng đăng ký để hệ thống gọn và ổn định hơn.

## 3. Cho điện thoại/người khác cùng Wi‑Fi mở web

Trong web bấm QR chia sẻ hoặc gọi:

`http://<IP-Mac>:3012`

Web tự lấy IP LAN của Mac để QR không trỏ nhầm vào `localhost`.

## 4. Phần cứng

Các chức năng Digital Twin, thiết bị, GPS, cảnh báo, bài tập, chat, Admin và các màn hình hiện có được giữ lại. Việc đồng bộ ESP32-S3 + MPU6050 có thể tiếp tục sau mà không phải đổi lại luồng đăng ký Email OTP.
