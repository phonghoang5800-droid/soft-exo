# Những thay đổi trong bản Final

## Email OTP thật
- Dùng Brevo Transactional Email API.
- Mỗi lần gửi sinh OTP 6 số bằng `crypto.randomInt`.
- OTP không trả về frontend và không ghi mã thật vào audit log.
- Backend chỉ lưu hash + salt của OTP.
- Hết hạn sau 5 phút, dùng một lần, tối đa 5 lần nhập sai, resend cooldown 30 giây.
- Đăng ký tài khoản và quên mật khẩu đều xác minh OTP qua backend.
- Cấu hình Brevo một lần trong Admin Portal, API key được mã hóa AES-256-GCM khi lưu cục bộ.
- SMS/auto-fill OTP giả được loại khỏi giao diện đăng ký.

## Tài khoản và Admin
- Public registration luôn tạo role `PATIENT`.
- User mới được lưu vào backend `data/users.json`, đăng nhập được từ điện thoại/trình duyệt khác.
- Password backend dùng scrypt hash + salt.
- Admin overview và cấu hình OTP yêu cầu session Admin.
- Danh sách tài khoản Admin lấy dữ liệu backend thay vì chỉ localStorage.

## Giao diện
- Light Tech theme: nền trắng/xanh, grid công nghệ nhẹ, card sáng, shadow dịu, trạng thái màu rõ.
- Tối ưu input cho iPhone/mobile và giữ CTA nổi bật.
- Branding hiển thị SOFT-EXO Family Care / Digital Twin.
- QR chia sẻ dùng IP LAN của Mac thay vì `localhost`, thuận tiện mở từ điện thoại cùng Wi-Fi.

## Giữ lại
- Digital Twin 3D.
- Bài tập/AI Coach.
- Cổng bác sĩ.
- Cổng người thân.
- Chat.
- Thiết bị/IMU.
- GPS/SOS/cảnh báo.
- Admin Portal và audit OTP.
