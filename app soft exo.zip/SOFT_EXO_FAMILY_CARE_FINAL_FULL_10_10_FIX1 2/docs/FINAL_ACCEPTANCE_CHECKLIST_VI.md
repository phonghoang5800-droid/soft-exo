# Checklist kiểm thử bản FINAL FULL

1. `npm install` hoàn tất không dừng giữa chừng.
2. `npm run dev` hiện Web `3012` và UDP cảm biến `5005`.
3. Mở web: Intro → nút Trang chủ → Login/Đăng ký.
4. Admin: cấu hình Brevo và gửi OTP thật thành công tới một Gmail khác.
5. Đăng ký Patient mới: OTP đúng mới tạo tài khoản; user không tự chọn Admin/Doctor/Caregiver.
6. Thiết bị: Camera đọc mã vạch thật; thử ít nhất EAN/Code128 hoặc QR từ tem thật. Không có nút “nhận diện giả”.
7. Quét mã chỉ chuyển trạng thái **đã liên kết sản phẩm**, không giả trạng thái sensor live.
8. Bật ESP32-S3 gửi UDP: app chuyển sang **đang nhận dữ liệu thật**.
9. Gập MPU6050: số góc và mô hình 3D cùng thay đổi, slider demo bị khóa khi hardware live.
10. 3D: kéo để xoay ngang/dọc, pinch/wheel để zoom, hai ngón/chuột phải để pan, preset nhìn bên/chính diện/góc 3D.
11. Dừng ESP32 > 3.5 giây: app báo mất kết nối và không tiếp tục giả dữ liệu thật.
12. SOS: g-force ≥ ngưỡng hoặc góc/chuyển động bất thường → banner cảnh báo + rung/âm thanh theo khả năng thiết bị + caregiver nhận alert realtime.
13. Nếu có active buzzer được đấu và `BUZZER_PIN` đúng: thiết bị vật lý bật còi khi cảnh báo và tắt khi người bệnh bấm **Tôi ổn**.
14. Caregiver: bấm **Bật cảnh báo khẩn cấp** và xác nhận quyền Notification.
15. iPhone/iPad: thêm SOFT-EXO vào Màn hình chính, mở từ icon, bật cảnh báo; sau đó test Web Push nền từ một SOS mới.
16. Không còn Packet JSON/HEX/terminal/Blender trong giao diện người bệnh.
17. Test giao diện Mac và iPhone, đặc biệt nút disabled/focus/press phải đọc rõ và có phản hồi.
18. Test từ 5G qua Cloudflare Tunnel HTTPS: login, OTP, scanner, 3D, SOS.
