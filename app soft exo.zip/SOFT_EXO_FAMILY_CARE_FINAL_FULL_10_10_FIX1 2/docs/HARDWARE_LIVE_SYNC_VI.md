# SOFT-EXO: Đồng bộ ESP32 + MPU6050 với mô hình 3D thật

## Luồng hoạt động

`MPU6050 -> ESP32-S3 -> Wi-Fi UDP :5005 -> server.ts -> SSE -> trình duyệt -> mô hình 3D`

Khi backend nhận packet từ ESP32, `telemetry.isConnected` chuyển sang `true`. Mô hình 3D khóa thanh mô phỏng và dùng `kneeAngle` từ phần cứng. Nhóm xương cẳng chân trong mô hình được xoay quanh đúng pivot của khớp gối theo góc này.

## Chạy trên Mac

Terminal 1, trong thư mục dự án:

```bash
npm install
npm run dev
```

Khi đúng sẽ có cả hai dòng:

```text
ESP32/MPU6050 UDP receiver listening on 0.0.0.0:5005
SOFT-EXO Full-Stack Server running at http://0.0.0.0:3012
```

Lấy IP Wi-Fi Mac:

```bash
ipconfig getifaddr en0
```

Điền IP đó vào `MAC_SERVER_IP` trong sketch Arduino rồi upload lại ESP32.

## Packet được hỗ trợ

Backend cố tình hỗ trợ nhiều format để không buộc phải viết lại firmware cũ:

```text
IMU,X,45.2,Y,1.4
```

hoặc:

```text
Goc_Goi:45.2,Pitch:12.0,Roll:1.4,G:1.02,Bat:88
```

hoặc JSON:

```json
{"kneeAngle":45.2,"roll":1.4,"gForceMagnitude":1.02,"batteryLevel":88}
```

Nếu sau này dùng **2 MPU6050** (đùi + cẳng chân), gửi `thighPitch` và `shinPitch`; backend sẽ lấy chênh lệch hai góc làm góc gối.


## Khuyến nghị dùng 2 MPU6050 để đo đúng góc gối

Bản final có hai sketch:

- `firmware/SOFT_EXO_ESP32_MPU6050_LIVE.ino`: 1 MPU6050, phù hợp bench/demo khi đùi tương đối ổn định.
- `firmware/SOFT_EXO_ESP32_DUAL_MPU6050_RECOMMENDED.ino`: **2 MPU6050, khuyến nghị cho đeo thật**. Một cảm biến ở đùi và một ở cẳng chân; góc gối = chênh lệch hai góc đoạn chân.

Với bản 2 cảm biến, mỗi MPU dùng một I2C bus của ESP32-S3 nên cả hai có thể giữ địa chỉ mặc định 0x68. Mã `DEVICE_CODE` trong firmware phải trùng với mã vạch/serial đã quét và liên kết trong ứng dụng.

## SOS

- Va đập `>= 2.5G` -> cảnh báo mức nguy hiểm.
- Góc > 138° hoặc thay đổi góc cực nhanh -> cảnh báo chuyển động chưa an toàn.
- Backend phát SOS realtime tới mọi app đang mở qua SSE.
- Người thân có thể bấm **Bật cảnh báo khẩn cấp** để đăng ký Web Push nền.
- Trên iPhone/iPad, Web Push hoạt động khi SOFT-EXO được thêm vào **Màn hình chính** và người dùng cấp quyền thông báo.
- Điện thoại/máy người bệnh và người thân phát cảnh báo âm thanh/rung theo khả năng của hệ điều hành/trình duyệt.
- Nếu ESP32 có buzzer, firmware có fail-safe tại chỗ và backend cũng gửi `ALARM,ON,DANGER` hoặc `ALARM,ON,WARNING`.
- Người bệnh bấm **Tôi ổn • Tắt cảnh báo** -> backend gửi `ALARM,OFF`.


## Lưu ý về độ chính xác góc gối

Với **1 MPU6050**, firmware mẫu zero góc khi chân duỗi và đo thay đổi góc của segment gắn cảm biến. Cách này phù hợp demo và bài tập có đùi tương đối ổn định. Nếu cả đùi và cẳng chân cùng đổi hướng, nên dùng **2 IMU** (một ở đùi, một ở cẳng chân) và gửi `thighPitch` + `shinPitch`; backend sẽ lấy độ chênh làm góc gối tương đối.
