# SOFT-EXO chạy 24/7 trên Railway

Bản này đã được chỉnh để chạy trên Railway mà không cần bật Mac hoặc Cloudflare Quick Tunnel.

## Đã chuẩn bị sẵn

- Server lấy cổng từ `PORT` do Railway cấp.
- Chế độ production phục vụ frontend đã build.
- `/api/network-info` tự nhận URL HTTPS công khai để QR Admin trỏ đúng website.
- Dữ liệu tài khoản, cấu hình Brevo, VAPID và liên kết thiết bị có thể lưu bền vững trên Railway Volume.
- Health check: `/api/health`.
- Node 22 LTS.

## Deploy lần đầu từ Mac

Trong Terminal, vào đúng thư mục dự án rồi chạy:

```bash
brew install railway
railway login
railway init -n soft-exo-family-care
railway up
```

Sau khi deploy thành công:

```bash
railway domain
```

Railway sẽ cấp một URL cố định dạng:

```text
https://<ten-du-an>.up.railway.app
```

URL này không phụ thuộc Mac và dùng được để tạo QR lâu dài.

## Bắt buộc: gắn Volume để tài khoản/OTP không mất sau redeploy

Chạy:

```bash
railway volume add --mount-path /app/data
```

Nếu CLI hỏi service nào, chọn service web SOFT-EXO vừa tạo.

Sau đó redeploy:

```bash
railway up
```

Ứng dụng đang ghi dữ liệu vào `./data`, nên Railway khuyến nghị mount volume tại `/app/data` để dữ liệu tương đối này được giữ qua các lần deploy/restart.

## Brevo OTP

Sau khi URL Railway mở được, đăng nhập Admin và cấu hình Brevo như trước. Vì `/app/data` nằm trên Volume, cấu hình sẽ được giữ lại.

## Domain đẹp sau này

Có thể giữ URL `*.up.railway.app`, hoặc thêm domain riêng trong Railway > Settings > Networking > Custom Domain. Railway tự cấp SSL.

## Phần cứng

Bản này ưu tiên app 24/7. UDP 5005 từ ESP32 sẽ được xử lý ở giai đoạn phần cứng sau. Khi đó nên dùng VPS hoặc một kiến trúc ingest phù hợp cho UDP công khai.
